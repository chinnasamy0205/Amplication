# Scenario: Verify Default UI of Inventory Spoilage Screen

## Metadata
- **Module:** Adjust Inventory - Spoilage
- **Priority:** P1
- **Type:** web
- **Tags:** web, UI-validation, inventory-spoilage, P1
- **Depends On:** None
- **Produces:** None

## Application
- **URL:** {{ENV.BASE_URL}}
- **Credentials:** {{ENV.EMPLOYEE_ID}} / {{ENV.PASSCODE}}

## Preconditions
- The user has valid StoreIQ credentials.
- The user is logged into the StoreIQ application.
- A department is selected successfully.

## Steps
1. Navigate to {{ENV.BASE_URL}}
2. Log in using Employee ID {{ENV.EMPLOYEE_ID}} and Passcode {{ENV.PASSCODE}}
3. Select the `000006 - Long Beach` department
4. VERIFY: The department is selected and the dashboard/home screen is displayed
5. Navigate to the Adjust Inventory menu
6. VERIFY: Adjust Inventory options are displayed
7. Select the Spoilage option
8. VERIFY: The Spoilage screen is opened
9. VERIFY: The title bar displays a Back Arrow button on the left, "Spoilage" text in the center, and a Help (Question Mark) icon on the right
10. VERIFY: The UPC text field is displayed with Scan and Type toggle options
11. VERIFY: Scan is selected by default
12. VERIFY: The UPC field placeholder text is "Scan upc"
13. VERIFY: Shrink and Correction radio buttons are displayed, if i Correction choose Minus (-) controls
14. VERIFY: Shrink is selected by default
15. VERIFY: The quantity text box is displayed
16. VERIFY: Minus (-) controls are displayed along with the quantity field
17. VERIFY: The Submit button is displayed with a Tailwind teal-500 background and remains disabled by default
18. VERIFY: All specified UI elements are displayed and default selections and states match the requirements
19. VERIFY: No UI component is missing or incorrectly displayed or labeled, and no default selection or state differs from the expected behavior

## Test Data
| Field | Value | Notes |
|---|---|---|
| Employee ID | {{ENV.EMPLOYEE_ID}} | Set to the test Employee ID in the environment; source provided a literal value. |
| Passcode | {{ENV.PASSCODE}} | Set to the test passcode in the environment; source provided a literal value. |
| Department | 000006 - Long Beach | Department to select. |

## Detail Level: MEDIUM (Explorer will discover UI specifics)
The test case specifies the page, controls, labels, default selections, and expected disabled state. The Explorer will discover the actual navigation and UI elements in the application.

## Notes
- The source also describes the disabled Submit button background as a "light background" and "Tailwind teal-500 color"; both descriptions are retained in the original text, while the structured expectation retains the explicit Tailwind teal-500 wording.
- Configure the environment values for the URL, Employee ID, and passcode; no actual URL or credential values are embedded in this scenario.

## Notes for Explorer
- Verify all stated controls and default states on the Spoilage screen. Do not perform a submission; the scenario covers the default UI only.
 