# Scenario: Invalid UPC - Theft Inventory Adjustment

## Metadata
- **Module:** Inventory Adjustment
- **Priority:** P1
- **Type:** web
- **Language:** typescript
- **Tags:** web, regression, P1, inventory-adjustment, invalid-upc
- **Depends On:** None
- **Produces:** None

## Application
- **URL:** https://test.storeiq.goodfoodholdings.com/
- **Credentials:** {{ENV.EMPLOYEE_ID}} / {{ENV.PASSCODE}}

## Test Data
| Field | Value | Notes |
|---|---|---|
| candidateUpc | 999999999993 | Synthetic 12-digit UPC-A checksum-shaped candidate; not yet proven invalid. Explorer must verify its status live. |

## Steps
1. Navigate to https://test.storeiq.goodfoodholdings.com/
2. VERIFY: The login page is displayed
3. Log in with Employee ID {{ENV.EMPLOYEE_ID}} and passcode {{ENV.PASSCODE}}
4. VERIFY: The store selection page is displayed
5. Select the store and department `000006 - Long Beach`
6. VERIFY: The selected store and department are active
7. Click the "Adjust Inventory" option
8. VERIFY: The Inventory Adjustment screen is displayed
9. Select "Theft"
10. Switch to "Type Mode"
11. Enter {{candidateUpc}} as the UPC
12. Submit/search for the UPC
13. VERIFY: An error message appears for the UPC
14. VERIFY: No item is loaded
15. VERIFY: The Submit button is disabled
16. SCREENSHOT: invalid-upc-theft-adjustment

## Notes for Explorer
- The UPC is a synthetic checksum-shaped candidate, not a known invalid value. Verify its status against the live application; do not assume arbitrary values are invalid.
- Preserve the negative expectation. If live behavior conflicts with the expected error, no loaded item, or disabled Submit button, report a potential bug or test-data mismatch. Do not silently change the expectation.
- Common navigation/auth/store setup is drawn only from the user-authored `scenarios/web/goodfood-scenario-1.md`. Do not use prior generated artifacts as evidence about Scenario 2 behavior.
- Enrichment did not interact with the application; none of these behaviors has been live-verified.

## Detail Level: HIGH-LEVEL (Explorer will discover specifics)
Navigation and setup follow the user-provided scenario context. The Explorer must discover actual UI details and verify the candidate UPC and negative behavior live.

## Original Description
> Title: Invalid UPC - Theft Inventory Adjustment
> App URL: https://test.storeiq.goodfoodholdings.com/
> Intent: Navigate to the Theft screen, enter a non-existing UPC, submit/search, and verify an error message appears, no item is loaded, and Submit is disabled. Application validates UPCs against its database; arbitrary/random values must not be assumed valid.
> Scenario data: 999999999993 (synthetic 12-digit UPC-A checksum-shaped candidate). It is not yet proven invalid; Explorer MUST verify live. Preserve the negative expectation; if live behavior conflicts, Explorer reports potential bug/test-data mismatch and does not silently change expectation.