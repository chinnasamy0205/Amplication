# Scenario: Verify Default UI of Inventory Spoilage Screen

## Metadata
- **Module:** Adjust Inventory - Spoilage
- **Priority:** P1
- **Type:** web
- **Tags:** web, UI-validation, inventory-spoilage, P1
- **Depends On:** None
- **Produces:** None

## Application
- **URL:** {{ENV.BASE_URL}}
- **Credentials:** {{ENV.EMPLOYEE_ID}} / {{ENV.PASSCODE}}

## Preconditions
- The user has valid StoreIQ credentials.
- The user is logged into the StoreIQ application.
- A department is selected successfully.

## Detail Level: EXPLORER-VERIFIED
Steps verified during live browser exploration on 2026-10-26. Element data was captured from the live accessibility tree and DOM; selector primaries for the Spoilage controls were checked against the live page. ORIGINAL/EXPANDED/DISCOVERED tags show provenance.

## App Behavior: unknown
Only one route-changing transition was observed: Adjust Inventory changed the path to `/adjust-inventory`; selecting Spoilage changed the content in place. Login and store selection remained on the root path, so there were not enough route transitions to classify rendering more specifically.

## Steps

### LoginPage (/)
1. Navigate to {{ENV.BASE_URL}} <!-- ORIGINAL -->
   <!-- LEDGER:END step=1 -->
2. Log in using Employee ID {{ENV.EMPLOYEE_ID}} and Passcode {{ENV.PASSCODE}} <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"LoginPage","key":"employeeIdInput","primary":"role=textbox[name='Employee Id']","fallbacks":["input[name='employeeId']","input[autocomplete='username']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":null}} -->
   <!-- ELEMENT: {"page":"LoginPage","key":"passcodeInput","primary":"role=textbox[name='Passcode']","fallbacks":["input[type='password']","input[autocomplete='current-password']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":null}} -->
   <!-- ELEMENT: {"page":"LoginPage","key":"loginButton","primary":"role=button[name='Log in']","fallbacks":["button[type='submit']","text=Log in"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Log in","cssPath":null}} -->
   <!-- LEDGER:END step=2 -->

### StoreSelectionPage (/)
3. Select the `000006 - Long Beach` department <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"StoreSelectionPage","key":"storeDropdown","primary":"role=combobox","fallbacks":["[role='combobox']","text=Choose Store"],"type":"select","fingerprint":{"tag":null,"id":null,"testId":null,"text":"Choose Store","cssPath":null}} -->
   <!-- ELEMENT: {"page":"StoreSelectionPage","key":"longBeachStoreOption","primary":"role=option[name='000006 - Long Beach']","fallbacks":["text=000006 - Long Beach","[role='option']:has-text('Long Beach')"],"type":"text","fingerprint":{"tag":null,"id":null,"testId":null,"text":"000006 - Long Beach","cssPath":null}} -->
   <!-- DISCOVERED: Store selection is a custom combobox; opening it exposes a listbox with the store options. Selecting Long Beach updates the home content in place. -->
   <!-- LEDGER:END step=3 -->
4. VERIFY: The department is selected and the dashboard/home screen is displayed <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"StoreHomePage","key":"activeStoreDisplay","primary":"text=Long Beach","fallbacks":["span.blink.text-white:has-text('Long Beach')","div:nth-of-type(2) > div > div > div:nth-of-type(1) > div:nth-of-type(1)"],"type":"text","fingerprint":{"tag":null,"id":null,"testId":null,"text":"Long Beach","cssPath":null}} -->
   <!-- LEDGER:END step=4 -->

### StoreHomePage (/)
5. Navigate to the Adjust Inventory menu <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"StoreHomePage","key":"adjustInventoryButton","primary":"role=button[name='Adjust Inventory']","fallbacks":["button:has-text('Adjust Inventory')","text=Adjust Inventory"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Adjust Inventory","cssPath":null}} -->
   <!-- LEDGER:END step=5 -->
6. VERIFY: Adjust Inventory options are displayed <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"AdjustInventoryPage","key":"theftButton","primary":"role=button[name='Theft']","fallbacks":["button:has-text('Theft')","text=Theft"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Theft","cssPath":null}} -->
   <!-- DISCOVERED: The Adjust Inventory view showed Theft, Spoilage, Donation, and Out Of Stock options. The route changed to /adjust-inventory; choosing an option updated the view without changing the URL. -->
   <!-- LEDGER:END step=6 -->
7. Select the Spoilage option <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"AdjustInventoryPage","key":"spoilageButton","primary":"role=button[name='Spoilage']","fallbacks":["text=Spoilage","button:has-text('Spoilage')"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Spoilage","cssPath":null}} -->
   <!-- LEDGER:END step=7 -->

### SpoilagePage (/adjust-inventory)
8. VERIFY: The Spoilage screen is opened <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"spoilageScreenTitle","primary":"text=Spoilage","fallbacks":["[role='heading']:has-text('Spoilage')",".page-title:has-text('Spoilage')"],"type":"text","fingerprint":{"tag":null,"id":null,"testId":null,"text":"Spoilage","cssPath":null}} -->
   <!-- LEDGER:END step=8 -->
9. VERIFY: The title bar displays a Back Arrow button on the left, "Spoilage" text in the center, and a Help (Question Mark) icon on the right <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"backArrowIcon","primary":"svg.lucide-circle-arrow-left","fallbacks":["div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(1) > svg","div.cursor-pointer.pl-2 > svg"],"type":"image","fingerprint":{"tag":"svg","id":null,"testId":null,"text":null,"cssPath":"div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(1) > svg"}} -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"spoilageScreenTitle","primary":"text=Spoilage","fallbacks":["[role='heading']:has-text('Spoilage')",".page-title:has-text('Spoilage')"],"type":"text","fingerprint":{"tag":null,"id":null,"testId":null,"text":"Spoilage","cssPath":null}} -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"helpIcon","primary":"svg.lucide-circle-question-mark","fallbacks":["div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(3) > svg","div.cursor-pointer.pr-2 > svg"],"type":"image","fingerprint":{"tag":"svg","id":null,"testId":null,"text":null,"cssPath":"div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(3) > svg"}} -->
   <!-- LEDGER:END step=9 -->
10. VERIFY: The UPC text field is displayed with Scan and Type toggle options <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"spoilageUpcInput","primary":"#txtupc","fallbacks":["input[placeholder='Scan upc']","input[data-slot='input']"],"type":"input","fingerprint":{"tag":"input","id":"txtupc","testId":null,"text":null,"cssPath":"#txtupc"}} -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"manualModeSwitch","primary":"#manual-mode","fallbacks":["[role='switch']","button[data-slot='switch']"],"type":"checkbox","fingerprint":{"tag":"button","id":"manual-mode","testId":null,"text":null,"cssPath":"#manual-mode"}} -->
   <!-- LEDGER:END step=10 -->
11. VERIFY: Scan is selected by default <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"manualModeSwitch","primary":"#manual-mode","fallbacks":["[role='switch']","button[data-slot='switch']"],"type":"checkbox","fingerprint":{"tag":"button","id":"manual-mode","testId":null,"text":null,"cssPath":"#manual-mode"}} -->
   <!-- DISCOVERED: The switch reports aria-checked=false while the adjacent visible mode labels are Scan and Type; the default state is Scan. -->
   <!-- LEDGER:END step=11 -->
12. VERIFY: The UPC field placeholder text is "Scan UPC/Enter UPC" <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"spoilageUpcInput","primary":"#txtupc","fallbacks":["input[placeholder='Scan upc']","input[data-slot='input']"],"type":"input","fingerprint":{"tag":"input","id":"txtupc","testId":null,"text":null,"cssPath":"#txtupc"}} -->
   <!-- BLOCKED: The live UPC input placeholder is "Scan upc", not the scenario expectation "Scan UPC/Enter UPC". Element is present; expected value mismatch recorded as a potential application defect. -->
13. VERIFY: Shrink and Correction radio buttons are displayed <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"shrinkRadio","primary":"#r1","fallbacks":["button[role='radio'][value='removeInventory']","text=Shrink"],"type":"radio","fingerprint":{"tag":"button","id":"r1","testId":null,"text":null,"cssPath":"#r1"}} -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"correctionRadio","primary":"#r2","fallbacks":["button[role='radio'][value='addInventory']","text=Correction"],"type":"radio","fingerprint":{"tag":"button","id":"r2","testId":null,"text":null,"cssPath":"#r2"}} -->
14. VERIFY: Shrink is selected by default <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"shrinkRadio","primary":"#r1","fallbacks":["button[role='radio'][value='removeInventory']","text=Shrink"],"type":"radio","fingerprint":{"tag":"button","id":"r1","testId":null,"text":null,"cssPath":"#r1"}} -->
   <!-- LEDGER:END step=14 -->
15. VERIFY: The quantity text box is displayed <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"quantityInput","primary":"div:nth-of-type(2) > div > div:nth-of-type(3) > div:nth-of-type(1) > div > div:nth-of-type(3) > input","fallbacks":["input[placeholder='0']","input[data-slot='input'][placeholder='0']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":"div:nth-of-type(2) > div > div:nth-of-type(3) > div:nth-of-type(1) > div > div:nth-of-type(3) > input"}} -->
   <!-- LEDGER:END step=15 -->
16. VERIFY: Minus (-) controls are displayed along with the quantity field <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"quantityMinusLabel","primary":"div:nth-of-type(2) > div > div:nth-of-type(3) > div:nth-of-type(1) > div > div:nth-of-type(3) > label","fallbacks":["label:has-text('(-)')","text=(-)"],"type":"text","fingerprint":{"tag":"label","id":null,"testId":null,"text":"(-)","cssPath":"div:nth-of-type(2) > div > div:nth-of-type(3) > div:nth-of-type(1) > div > div:nth-of-type(3) > label"}} -->
   <!-- DISCOVERED: The visible (-) mark is a label adjacent to the quantity input, not a button or other interactive control. -->
   <!-- LEDGER:END step=16 -->
17. VERIFY: The Submit button is displayed with a Tailwind teal-500 background and remains disabled by default <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"submitButton","primary":"role=button[name='Submit']","fallbacks":["div:nth-of-type(2) > div > div:nth-of-type(3) > div:nth-of-type(1) > div > div:nth-of-type(3) > button","button:has-text('Submit')"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Submit","cssPath":"div:nth-of-type(2) > div > div:nth-of-type(3) > div:nth-of-type(1) > div > div:nth-of-type(3) > button"}} -->
   <!-- DISCOVERED: Submit is disabled and its class includes bg-teal-500; the computed background is the teal Tailwind color (oklch(0.704 0.14 182.503)), not a light/white background. No submission was attempted. -->
   <!-- LEDGER:END step=17 -->
18. VERIFY: All specified UI elements are displayed and default selections and states match the requirements <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"submitButton","primary":"role=button[name='Submit']","fallbacks":["div:nth-of-type(2) > div > div:nth-of-type(3) > div:nth-of-type(1) > div > div:nth-of-type(3) > button","button:has-text('Submit')"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Submit","cssPath":"div:nth-of-type(2) > div > div:nth-of-type(3) > div:nth-of-type(1) > div > div:nth-of-type(3) > button"}} -->
   <!-- BLOCKED: Aggregate requirements do not all match: the UPC placeholder and adjustment radio label differ from the stated expectations. -->
19. VERIFY: No UI component is missing or incorrectly displayed or labeled, and no default selection or state differs from the expected behavior <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SpoilagePage","key":"correctionRadio","primary":"#r2","fallbacks":["button[role='radio'][value='addInventory']","text=Correction"],"type":"radio","fingerprint":{"tag":"button","id":"r2","testId":null,"text":null,"cssPath":"#r2"}} -->
   <!-- BLOCKED: The placeholder and radio label mismatches mean the complete UI does not match every stated expected label. -->