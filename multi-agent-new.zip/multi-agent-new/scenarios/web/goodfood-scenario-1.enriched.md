# Scenario: Create Inventory Adjustment - Theft - Manual Type Mode

**Type:** web
**URL:** {{ENV.BASE_URL}}
**Tags:** @P1 @inventory-adjustment
**Priority:** P1
**Browser:** chromium

## Detail Level: EXPLORER-VERIFIED
Steps verified during live exploration on 2026-10-27.
Element data was captured from the accessibility snapshots and confirmed through successful live interactions. Page sections map steps to the observed pages.

## App Behavior: unknown
One route transition was observed: the authenticated home view navigated to `/adjust-inventory` after Adjust Inventory was clicked. There was not enough route-transition evidence to classify the application rendering model.

## Steps

### LoginPage (/)
1. Navigate to {{ENV.BASE_URL}} <!-- ORIGINAL -->
<!-- LEDGER:END step=1 -->
2. VERIFY the login page is displayed <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"LoginPage","key":"employeeIdInput","primary":"role=textbox[name='Employee Id']","fallbacks":["input[name='employeeId']","input[aria-label='Employee Id']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":null}} -->
   <!-- LEDGER:END step=2 -->
3. Log in with Employee ID `{{ENV.GOODFOOD_EMPLOYEE_ID}}` and passcode `{{ENV.GOODFOOD_PASSCODE}}` <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"LoginPage","key":"employeeIdInput","primary":"role=textbox[name='Employee Id']","fallbacks":["input[name='employeeId']","input[aria-label='Employee Id']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":null}} -->
   <!-- ELEMENT: {"page":"LoginPage","key":"passcodeInput","primary":"role=textbox[name='Passcode']","fallbacks":["input[name='passcode']","input[aria-label='Passcode']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":null}} -->
   <!-- ELEMENT: {"page":"LoginPage","key":"loginButton","primary":"role=button[name='Log in']","fallbacks":["button:has-text('Log in')","text=Log in"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Log in","cssPath":null}} -->
   <!-- LEDGER:END step=3 -->

### HomePage (/)
4. Click Choose the Store dropdown list <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"HomePage","key":"chooseStoreCombobox","primary":"role=combobox","fallbacks":["text=Choose Store","[role='combobox']"],"type":"select","fingerprint":{"tag":null,"id":null,"testId":null,"text":"Choose Store","cssPath":null}} -->
   <!-- LEDGER:END step=4 -->
5. Select the Department `000006 - Long Beach` <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"HomePage","key":"longBeachOption","primary":"role=option[name='000006 - Long Beach']","fallbacks":["text=000006 - Long Beach","[role='option']"],"type":"text","fingerprint":{"tag":null,"id":null,"testId":null,"text":"000006 - Long Beach","cssPath":null}} -->
   <!-- DISCOVERED: The application labels the chooser as Choose Store and the selected value as Long Beach; the scenario calls this choice a department. The next department control showed 02 - Grocery by default. -->
   <!-- LEDGER:END step=5 -->
6. Click the "Adjust Inventory" option <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"HomePage","key":"adjustInventoryButton","primary":"role=button[name='Adjust Inventory']","fallbacks":["button:has-text('Adjust Inventory')","text=Adjust Inventory"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Adjust Inventory","cssPath":null}} -->
   <!-- DISCOVERED: Clicking Adjust Inventory navigates to `/adjust-inventory`. -->
   <!-- LEDGER:END step=6 -->

### InventoryAdjustmentPage (/adjust-inventory)
7. Select "Theft" <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"InventoryAdjustmentPage","key":"theftButton","primary":"role=button[name='Theft']","fallbacks":["button:has-text('Theft')","text=Theft"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Theft","cssPath":null}} -->
   <!-- LEDGER:END step=7 -->
8. Switch to "Type Mode" <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"InventoryAdjustmentPage","key":"scanTypeSwitch","primary":"role=switch[name='Scan Type']","fallbacks":["[role='switch']","text=Type"],"type":"button","fingerprint":{"tag":null,"id":null,"testId":null,"text":"Scan Type","cssPath":null}} -->
   <!-- DISCOVERED: The Scan Type switch toggles between Scan and Type; after switching, the UPC textbox placeholder changes from Scan upc to Enter upc. -->
   <!-- LEDGER:END step=8 -->
9. Enter a valid UPC `{{ENV.GOODFOOD_UPC}}` <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"InventoryAdjustmentPage","key":"upcInput","primary":"role=textbox[name='Enter upc']","fallbacks":["input[placeholder='Enter upc']","input[aria-label='Enter upc']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":null}} -->
   <!-- LEDGER:END step=9 -->
10. Press Enter or click Search <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"InventoryAdjustmentPage","key":"upcInput","primary":"role=textbox[name='Enter upc']","fallbacks":["input[placeholder='Enter upc']","input[aria-label='Enter upc']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":null}} -->
   <!-- DISCOVERED: Pressing Enter loads the item details; no separate Search button was present in the observed Type Mode form. -->
   <!-- LEDGER:END step=10 -->
11. VERIFY the item details are displayed (item loaded correctly) <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"InventoryAdjustmentPage","key":"itemDetails","primary":"text=Recent Adjustments","fallbacks":["text=Enter upc","[role='generic']"],"type":"text","fingerprint":{"tag":null,"id":null,"testId":null,"text":"Recent Adjustments","cssPath":null}} -->
   <!-- LEDGER:END step=11 -->
12. Enter quantity `5` <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"InventoryAdjustmentPage","key":"quantityInput","primary":"role=textbox[name='0']","fallbacks":["input[placeholder='0']","input[type='number']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":null}} -->
   <!-- LEDGER:END step=12 -->
13. VERIFY the quantity is accepted <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"InventoryAdjustmentPage","key":"quantityInput","primary":"role=textbox[name='0']","fallbacks":["input[placeholder='0']","input[type='number']"],"type":"input","fingerprint":{"tag":"input","id":null,"testId":null,"text":null,"cssPath":null}} -->
   <!-- LEDGER:END step=13 -->
14. Click the Submit button <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"InventoryAdjustmentPage","key":"submitButton","primary":"role=button[name='Submit']","fallbacks":["button:has-text('Submit')","text=Submit"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":null,"text":"Submit","cssPath":null}} -->
   <!-- LEDGER:END step=14 -->
15. VERIFY the success modal/message is displayed <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"InventoryAdjustmentPage","key":"adjustmentSuccessMessage","primary":"text=Inventory adjustment added successfully","fallbacks":["role=dialog","text=successfully"],"type":"text","fingerprint":{"tag":null,"id":null,"testId":null,"text":"Inventory adjustment added successfully","cssPath":null}} -->
   <!-- LEDGER:END step=15 -->