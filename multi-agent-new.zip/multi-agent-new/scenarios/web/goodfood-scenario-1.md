# Scenario: Create Inventory Adjustment - Theft - Manual Type Mode

**Type:** web
**URL:** https://test.storeiq.goodfoodholdings.com/
**Tags:** @P1 @inventory-adjustment
**Priority:** P1
**Browser:** chromium

---

## Description

Verifies a user can log in, select a store and department, and create a Theft inventory adjustment in Type Mode by entering a valid UPC and quantity, and that the record is saved in the Inventory Adjustment table.

---

## Steps

1. Navigate to https://test.storeiq.goodfoodholdings.com/
2. VERIFY the login page is displayed
3. Log in with Employee ID `10205` and passcode `123456`
4. Click Choose the Store dropdown list
5. Select the Department `000006 - Long Beach`
6. Click the "Adjust Inventory" option
7. Select "Theft"
8. Switch to "Type Mode"
9. Enter a valid UPC `049000028911`
10. Press Enter or click Search
11. VERIFY the item details are displayed (item loaded correctly)
12. Enter quantity `5`
13. VERIFY the quantity is accepted
14. Click the Submit button
15. VERIFY the success modal/message is displayed 

 
