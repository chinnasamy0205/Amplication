---
description: "Run the full QE Automation pipeline (Enrichment → Explorer → Builder → Executor → Reviewer → Healer) for TC-001-vfs-full-booking-flow-cdp against the VFS Global booking flow via CDP."
mode: agent
---

Run a fresh, complete QE Automation pipeline for the following scenario.

## Mandatory Pipeline Behavior

Use the Pipeline Orchestrator and invoke these agents in order:

1. Enrichment Agent
2. Explorer Agent
3. Builder Agent
4. Executor Agent
5. Reviewer Agent
6. Healer Agent only when Reviewer returns NEEDS FIXES
7. Reviewer Agent again after successful healing

Scenario name:

`TC-001-vfs-full-booking-flow-cdp`

Scenario type:

`web`

Treat this as a new scenario input from:

`scenarios/web/TC-001-vfs-full-booking-flow-cdp.md`

Do not reuse SauceDemo artifacts or any unrelated generated files.

Do not skip Explorer or Builder based on unrelated artifacts. If this scenario has no existing generated spec, it must proceed as `FIRST_RUN`.

Do not manually perform work assigned to specialist agents. The Pipeline Orchestrator must delegate each applicable stage to its designated agent.

## Important Execution Model

This scenario uses an already-open Chrome or Edge browser via CDP.

The generated Playwright automation must connect to the browser using the CDP endpoint configured by:

`${CDP_ENDPOINT}`

The test must not launch a new browser for the VFS flow. It must attach to the externally launched browser and leave that browser open at the end.

The test must not close the browser, context, page, or CDP connection in a way that terminates the externally launched browser.

## External Data Requirements

This scenario intentionally contains no environment-specific, credential, or business test data embedded in the spec.

All data must be loaded from framework-convention external files (already created):

- Runtime automation data: `output/test-data/web/TC-001-vfs-full-booking-flow-cdp.json`
- Credentials + environment config: `output/.env` (`CRED_IDX`, `CRED_00{n}_USERNAME`, `CRED_00{n}_PASSWORD`, `VFS_BASE_URL`, `VFS_DASHBOARD_URL`, `CDP_ENDPOINT`, `TEST`, `RETRIES`)

Before execution, verify that these files exist and contain valid values for the target environment.

Do not embed credentials, URLs, appointment details, applicant data, or validation data directly in the Playwright spec or page objects.

Credential selection must use `CRED_IDX` (0-based) resolved against `CRED_00{n}_USERNAME`/`CRED_00{n}_PASSWORD` where `n = CRED_IDX + 1`.

## Scenario

1. Connect to an already-open Chrome or Edge browser via CDP endpoint configured in `${CDP_ENDPOINT}`.
2. Navigate to the VFS Global URL configured in `${VFS_BASE_URL}` and verify the login page is displayed.
3. Accept cookies if the cookie consent banner is present.
4. Log in using the secure credentials loaded by the framework, selected via `CRED_IDX` from env config, with manual CAPTCHA verification support; verify login is successful and the user is redirected to the dashboard URL.
5. Verify the dashboard page is displayed and the URL contains `/dashboard`.
6. Click on **Start New Booking** and verify navigation to the application detail page `/application-detail`.
7. Select the Visa Application Centre identified by `appointment.centre` from the external test data.
8. Select the Appointment Category identified by `appointment.category` from the external test data.
9. Select the Sub-category identified by `appointment.subCategory` from the external test data.
10. Verify the earliest available slot text contains `earliest available slot`.
11. Click **Continue** and verify navigation to the Your Details page `/your-details`.
12. Without filling any mandatory fields, attempt to click **Save** with `allowDisabled: true`; if Save is disabled, verify the form is marked invalid and at least one invalid control exists; if Save is clicked, verify validation errors are displayed; confirm the user remains on the Your Details page.
13. Fill all mandatory fields with valid data from `validApplicant` except email, using `invalidEmail`.
14. Click outside the form to trigger validation; collect validation errors and verify the user remains on the Your Details page.
15. Correct the email to `validApplicant.email`.
16. Change the Passport Expiry Date to `pastExpiryDate`.
17. Click outside the form to trigger validation; collect validation errors and verify the user remains on the Your Details page.
18. Fill all mandatory fields with valid data from `validApplicant` except date of birth, using `minorDob`.
19. Click outside the form to trigger validation; collect validation errors and verify the user remains on the Your Details page.
20. Fill all mandatory fields with valid data from `validApplicant` except contact number, using `invalidPhoneNumber`.
21. Click outside the form to trigger validation; collect validation errors and verify the user remains on the Your Details page.
22. Fill all mandatory fields with valid data from `validApplicant` except first name, using `specialCharsName`.
23. Click outside the form to trigger validation; collect validation errors and verify the user remains on the Your Details page.
24. Fill all mandatory fields with valid data from `validApplicant` except first name and last name, using `numericName` for both fields.
25. Click outside the form to trigger validation; collect validation errors and verify the user remains on the Your Details page.
26. Fill all mandatory fields with valid data from `validApplicant` except date of birth, using `futureDateOfBirth`.
27. Click outside the form to trigger validation; collect validation errors and verify the user remains on the Your Details page.
28. Fill all mandatory fields with valid data from `validApplicant` except passport number, using `invalidPassportNumber`.
29. Click outside the form to trigger validation; collect validation errors and verify the user remains on the Your Details page.
30. Fill all fields with complete valid data from `validApplicant`.
31. Click **Save** and handle Cloudflare CAPTCHA if presented, allowing manual verification within the configured turnstile timeout; verify navigation to the Details Summary page.
32. Verify the Details Summary page is displayed; confirm the summary text contains the first name and last name from `validApplicant` using a case-insensitive comparison.
33. Click the **Delete** icon on the applicant row and confirm removal.
34. Leave the externally launched browser open; do not close or disconnect.

## Enrichment Requirements

Invoke the Enrichment Agent.

Canonical scenario file already exists at:

`scenarios/web/TC-001-vfs-full-booking-flow-cdp.md`

If the Enrichment Agent determines the file is already well-structured, pass it through unchanged per its normal behavior. Preserve all 34 scenario steps and their order — do not merge, omit, or reorder steps.

Because the scenario has more than 20 steps, apply the framework's multi-step scenario handling rules.

## Explorer Requirements

Invoke the Explorer Agent after enrichment.

Explorer must inspect the live VFS application using the approved Playwright exploration mechanism and the already-open browser/CDP setup where supported.

Explorer must execute and verify each scenario step against the real application.

Manual CAPTCHA handling is allowed where the application requires it.

Capture selectors from observed application evidence only.

Do not invent selectors.

Validate selector uniqueness and stability.

Generate:

`scenarios/web/TC-001-vfs-full-booking-flow-cdp.enriched.md`

Produce Explorer report and metrics with evidence-backed results.

If live exploration is blocked by missing external data, invalid CDP endpoint, inaccessible environment, CAPTCHA timeout, or application-side access restriction, stop and report INCOMPLETE with the precise blocker. Do not fabricate enriched selectors.

## Builder Requirements

Invoke the Builder Agent only after successful exploration.

Generate Playwright TypeScript automation from the enriched scenario.

Generated spec must be:

`output/tests/web/TC-001-vfs-full-booking-flow-cdp.spec.ts`

Generate or update required locator files, page objects, test data wiring, and spec code.

Maintain exact scenario-to-code fidelity: 34 source steps must be represented in the generated automation.

Use externalized locator definitions.

Do not place raw selectors in the spec or page objects.

Do not embed credentials, URLs, applicant data, appointment data, invalid validation values, or environment-specific data in code.

Load all runtime values from `output/test-data/web/TC-001-vfs-full-booking-flow-cdp.json` and `output/.env`.

Run Explorer post-check and cleanup-annotations validation.

## Execution Requirements

Invoke the Executor Agent.

Execute only the generated scenario spec:

`tests/web/TC-001-vfs-full-booking-flow-cdp.spec.ts`

Use Chromium `chrome` project unless CDP execution requires a dedicated project or fixture.

Run in headed/CDP mode against the already-open browser.

Do not permanently change framework defaults.

Use an execution equivalent to:

```powershell
cd output
$env:HEADLESS = "false"
$env:CDP_ENDPOINT = "http://127.0.0.1:9222"
npx playwright test tests/web/TC-001-vfs-full-booking-flow-cdp.spec.ts --project=chrome --headed
```

If the generated CDP test must bypass Playwright's normal browser launch fixture, implement that through the scenario-specific spec or page object only, without changing global framework defaults.

Executor must preserve the externally launched browser and must not close it.

## Review Requirements

Invoke Reviewer Agent after Executor completes or exhausts allowed fix cycles.

Reviewer must audit all applicable quality dimensions, including:

- Locator quality
- Wait strategy
- Test architecture
- Configuration
- Code quality
- Maintainability
- Security
- Scenario-to-code fidelity

Scenario-to-code fidelity is a hard gate: all 34 source steps must be represented.

## Healer Requirements

Invoke Healer Agent only if Reviewer verdict is NEEDS FIXES.

If Healer runs and tests pass after healing, invoke Reviewer Agent again for re-review.

Do not invoke Healer when tests are failing because of environment access, missing data, invalid credentials, CAPTCHA timeout, account lock, unavailable slots, or other user/application-side blockers.

## Final Summary

Write the pipeline summary to:

`output/reports/pipeline-summary-TC-001-vfs-full-booking-flow-cdp.md`

The summary must include:

- Final verdict
- Pipeline mode
- Agents invoked
- Files generated
- Test execution result
- Any manual CAPTCHA handling
- Any CDP/browser attachment details
- Any blockers or caveats
- Reviewer verdict and score
