---
name: web-selector-healing
description: "The Executor's Level-3 recovery — ARTIFACT-FIRST (read the failure ARIA already on disk in error-context.md), with a gated Playwright CLI live-probe (playwright-cli, never MCP) as the fallback: Trigger A (discover a missing locator from the failure ARIA / live snapshot and APPEND it to the locator JSON) and Trigger B (probe DOM structure when tactical fixes won't converge), the healed-selector priority + hard rules, when-NOT-to-heal, and the conditional Informed-Retargeting exception under Menu-Driven Reset option (e)."
version: "1.0"
---

# web-selector-healing

> Loaded by the **Executor** only when the `web-failure-diagnosis` Diagnostic Gate finds an element genuinely absent (Trigger A) or a structural question won't yield to code-only fixes (Trigger B / Menu-Driven Reset option (e)). This is the framework's Level-3 recovery path.
>
> **ARTIFACT-FIRST — HARD RULE. NOT optional.** The failing-page ARIA is **already captured** on disk in `output/test-results/**/error-context.md` (Playwright writes it on failure when tracing is enabled — see `playwright.config.ts`).
> - **You MUST consult `error-context.md` FIRST — but QUERY it, do NOT Read it whole.** It is a full-page aria tree (20K–80K tokens on data-heavy pages). Use `node scripts/snapshot-query.js --file=<error-context.md> --find="<element>"` (also `--interactive` for a page overview, `--structure` for grids) to pull only the region you need. Read a scoped slice only if a query can't localize it.
> - **You MUST NOT open a browser** — no MCP, no `playwright-cli`, no live navigation, no re-login — **UNLESS** you have queried `error-context.md`, determined it does not contain the target region, AND written `Path 1 insufficient: <reason>` in the cycle report.
> - **Opening any browser before consulting `error-context.md` is a VIOLATION of this rule.**
> - The only permitted browser use is the **gated CLI live-probe (Path 2, §4.5b)** via `playwright-cli` — **never MCP**, never to "debug." Tests still run via Bash. (Section numbers preserved from source for internal cross-reference.)

## 4.5a: Level-3 Recovery — ARTIFACT-FIRST is MANDATORY (CLI live-probe is the GATED fallback)

**This section is the framework's Level 3 recovery path. It is reachable under TWO distinct triggers — the Executor MUST invoke it when either fires.**

**Trigger A — Element not found (original scope).** The Diagnostic Gate (`web-failure-diagnosis` Step A) determines the element is NOT in the DOM AND the browser is on the correct page. The Executor discovers the missing element in the **failure ARIA** (`error-context.md` — Path 1; CLI live-probe only if needed), generates a locator entry, and appends to the locator JSON.

**Trigger B — Structural-ambiguity convergence failure (MANDATORY extension).** The element IS in the DOM but the same root-cause has persisted for 2 consecutive cycles (per the `web-failure-diagnosis` same-root-cause detection) on a question about DOM structure the code-only path cannot answer. Symptoms include:
- Count assertion returning wrong value across multiple hand-rolled fixes (scope unclear — is the counted region correct? is there shadow DOM?)
- Overlay/z-index blocking whose topology is not visible in `error-context.md` text (screenshot suggests overlay; DOM snapshot alone doesn't reveal stacking context)
- "element outside of the viewport" after `scrollIntoViewIfNeeded` (is there a custom scroll container?)
- Any failure where the Executor has tried tactical fixes and the next reasonable attempt requires observing the live rendered structure rather than more guessing

Under Trigger B, the Executor MUST observe the failure state's ARIA tree BEFORE writing the cycle-3 fix — **artifact-first: read `error-context.md`** (Path 1); only if it is missing/insufficient for the target region, run a **CLI live-probe** (Path 2, §4.5b). The ARIA tree (roles, labels, regions, hierarchy) is used to RE-SELECT a strategy from the Menu-Driven Reset (`web-failure-diagnosis`) informed by ground truth, NOT to write a new hand-rolled locator.

**The distinction between Trigger A and Trigger B:**
- Trigger A output: a new locator entry appended to the JSON.
- Trigger B output: a new informed strategy choice from the Menu-Driven Reset menu, applied by rewriting the failing method from scratch. The locator JSON is typically NOT modified under Trigger B — the primary locator was correct; the strategy using it was wrong.

**Why this is needed:** The Explorer captures element data for ~90% of interactive elements during exploration. The remaining ~10% may have failed capture (`ELEMENT_CAPTURE_FAILED`), or the element may have changed since exploration. The Executor discovers these one at a time — one snapshot, one element, one locator entry. Context pressure is minimal.

**Additionally:** when tactical code fixes fail to converge on a structural question (Trigger B), the Executor has historically burned 4-5 cycles improvising DOM walks against a misunderstood DOM shape. A single ARIA snapshot reveals the actual structure and redirects the fix — the reference failure pattern this extension prevents is "5+ cycles of DOM-walking for a count assertion against an iframe-nested or shadow-DOM-wrapped grid that the Executor never queried directly."

**Healing Flow:**

```
Step failed → Element not found → Correct page confirmed
  ↓
1. Read the SCENARIO STEP to understand WHAT the element is
   (e.g., "Select 'With photo' for the Photo Status filter")
  ↓
2. OBSERVE the failing page — ARTIFACT-FIRST. MANDATORY and gated:
   PATH 1 — MUST DO FIRST: QUERY output/test-results/**/error-context.md with
     scripts/snapshot-query.js (--find/--interactive/--structure) — NOT a wholesale
     Read (20K–80K tokens). It is the ARIA snapshot Playwright captured AT THE FAILURE
     POINT on the authenticated, deep page (already on disk). MUST NOT re-navigate/re-login.
   PATH 2 — FORBIDDEN unless Path 1 fails: run a CLI live-probe (§4.5b) ONLY after
     you queried error-context.md AND it lacks the target region. You MUST first write
     "Path 1 insufficient: <reason>" in the cycle report. No justification = no browser.
  ↓
3. FIND the element in the ARIA tree (from error-context.md OR the CLI snapshot)
   using the scenario's description
   - Look for matching: aria-label, role, visible text, placeholder
   - e.g., "Photo Status" → find [role="combobox"][aria-label="Photo Status"]
  ↓
4. Generate a locator entry with:
   - primary: best semantic selector (role + aria-label, or label=, or placeholder=)
   - fallbacks: 2 alternatives (id, text-based, class-based)
   - type: button/input/dropdown/link based on role
   - interactionNotes: if it's a dropdown, note the open → select pattern
  ↓
5. ADD the entry to the locator JSON file on disk — APPEND ONLY
   **HARD STOP: You MUST read the existing JSON file FIRST, parse it, add your
   new key to the existing object, then write the MERGED result back. You MUST
   NOT overwrite the file with only your new entries. The file contains Explorer-captured
   entries AND entries from previous healing cycles — destroying them forces
   re-discovery of already-proven selectors.**
   - Step 1: const existing = JSON.parse(fs.readFileSync(path, 'utf-8'));
   - Step 2: existing['newKey'] = { primary: '...', fallbacks: [...], type: '...' };
   - Step 3: fs.writeFileSync(path, JSON.stringify(existing, null, 2));
   - Key name: camelCase from aria-label or text (e.g., "photoStatusDropdown")
   **If you overwrite the file with fewer entries than it had before, you have
   violated this rule. Check entry count before and after writing.**
  ↓
6. UPDATE the page object if needed
   - If the page object method references this locator key, it will now work
   - If a new method is needed, add it to the page object
  ↓
7. Re-run the test
```

## 4.5b: CLI Live-Probe — Path 2 fallback (ONLY when error-context.md is insufficient)

**GATE — HARD STOP. Do not enter this section without justification.** Run the CLI live-probe ONLY after you have (1) read `error-context.md` (Path 1), AND (2) written `Path 1 insufficient: <reason>` in the cycle report (missing file, or the target region is not in the captured ARIA — e.g. failure before render). **If you have not read `error-context.md`, you MUST NOT run a live probe.** Drive via **`playwright-cli`** (terminal/`execute`), **never MCP**.

**Reach the failing page — establish a probe session, then go direct:**
1. **Open the probe browser:** `playwright-cli open --persistent` (**headed vs headless is config-driven: append `--headed` if `framework-config.json → executor.healProbeHeaded` is `true`; else headless — never hardcode**). **Get it to the app's authenticated state by ONE of:** (a) **preferred** — `playwright-cli state-load <file>` if a saved storage-state file exists (lands authenticated, no login); (b) **else** — let the app authenticate the way it normally does: an **SSO / persistent-profile** app may land authenticated on navigate, while an app with **interactive login** must perform that login. **If you cannot authenticate (e.g. SSO with no saved state, or login won't complete), ESCALATE — do not loop on login.** **Do NOT hand-extract cookies/localStorage from the failed run's trace — there is no tool for that; a trace→session helper is a graduation TODO.**
2. **Go STRAIGHT to the failing page:** `playwright-cli goto "<failing-page-URL>"` (URL from the test failure / `error-context.md`). **Do NOT replay the scenario from step 1.**
3. `playwright-cli snapshot` (or scoped `playwright-cli snapshot "#container"` / `--depth=N`) → **Read** the printed `.yml` → find the element by scenario intent.
4. For stable id/testId the ARIA lacks: `playwright-cli eval "el => el.getAttribute('data-testid')" <ref>`. Optional cross-check: `playwright-cli generate-locator <ref> --raw`.
5. `playwright-cli close`; clean up any temporary probe profile/state.

**Do NOT persist a `storageState` into the test config** — the scenario INCLUDES the login steps; a pre-authenticated test would skip the login page, the login locators would be absent, and the login steps would FAIL. The probe session is **transient and probe-only**; the test always runs unauthenticated.

**MCP → CLI mapping:** `browser_snapshot()` → `playwright-cli snapshot` (read the `.yml`); `browser_evaluate(fn,ref)` → `playwright-cli eval "<fn>" <ref>`.

> If no transient session is recoverable, Path 2 must log in fresh (slow + fragile on SSO/MFA) — which is why Path 1 (artifact-first) carries the common case.

---

**Selector Priority for Healed Elements (from the failure ARIA — `error-context.md` or CLI snapshot):**

| Priority | Strategy | When |
|----------|----------|------|
| 1 | `label=Photo Status` | Element has an associated label |
| 2 | `role=combobox[name='Photo Status']` | Element has role + accessible name |
| 3 | `placeholder=Search...` | Input with placeholder |
| 4 | `[aria-label="Photo Status"]` | Direct aria-label |
| 5 | `#mui-component-select-photoStatus` | Stable ID |
| 6 | `button:has-text("Search")` | Unique text content |

**HARD RULES for Selector Healing:**
- **ONE element per healing attempt.** Fix one missing locator, re-run, fix the next. Do NOT batch-discover selectors.
- **USE the accessibility snapshot, not the DOM.** The accessibility tree has semantic information (roles, labels) that produces better selectors than CSS classes.
- **NEVER use CSS-in-JS classes** (`css-NNN`, `sc-XXXXX`) — they change every build.
- **NEVER use auto-generated IDs** (`id__NNN`, `_r_XX_`) — they change every session.
- **Mark healed entries with `"_healed": true`** in the locator JSON entry. JSON does not support comments — do NOT use `// HEALED` as it would break `JSON.parse()`. The `_healed` field signals to the Builder that this selector was refined at runtime and must NOT be overwritten during incremental regeneration. Example:
  ```json
  "smesNavLink": {
    "primary": "a.nav-text[href='/Experts/']",
    "fallbacks": ["role=link[name='SMEs']", "text=SMEs"],
    "type": "link",
    "_healed": true
  }
  ```
- **Count healed selectors in the Executor report** — the user needs to know how many elements the Explorer missed.

**When NOT to heal (escalate instead):**
- If the page is wrong (navigation failure, auth wall) → fix navigation first
- If the element requires a business-specific interaction to appear (e.g., "click row 3, then a hidden panel opens") → the scenario step order may be wrong. Escalate.
- If you've already healed 5+ elements on the same page → Explorer's element capture for this page was insufficient. Note in report: "Recommend re-running Explorer for this page."

---

## Informed retargeting under Option (e) — CONDITIONAL EXCEPTION

> This rule governs the case where a Trigger-B probe (artifact-first `error-context.md`, or CLI live-probe) reveals the Explorer captured the *wrong* element for the scenario's intent. It is the only path by which an Executor fix may change which element a step targets — and only under all three conditions below. The same rule is the single source for the Phase-2 mobile Executor's §4.7 (no separate copy to keep in sync).

Option (e)'s probe (artifact-first `error-context.md`, or the CLI live-probe) may reveal that the Explorer's captured target is wrong for the scenario's intent (e.g., Explorer captured a category-header checkbox when the scenario intent was a leaf-item checkbox). The Executor MAY retarget to the correct element PROVIDED ALL THREE of the following conditions are true:

**Condition 1 — Scenario step text is UNAMBIGUOUS about intent.** The step text, read in isolation by a reasonable reader, has one clear interpretation. Examples:
- UNAMBIGUOUS: "Select one leaf product from the Product category" — the word "leaf" and "from the Product category" make the intent specific.
- AMBIGUOUS: "Select a product" — could be any product-related control; scenario intent is unclear. STOP and escalate.
- AMBIGUOUS: "Click the appropriate item" — "appropriate" requires judgment. STOP and escalate.

**Condition 2 — the probe ARIA (`error-context.md` or CLI snapshot) shows EXACTLY ONE element matching the scenario intent.** Not "best match" — exactly one, such that any reasonable reader would agree. If the ARIA shows multiple candidates, the choice is a judgment call and the Executor MUST escalate.

**Condition 3 — Evidence chain is documented in the cycle entry.** The Executor MUST record ALL of the following in the cycle report; missing any field blocks the retarget:

```markdown
- **Informed retarget under Option (e):**
  - Scenario step text (quoted verbatim): "<text>"
  - Explorer's captured target (key + primary selector from enriched.md ELEMENT annotation): `<key>` → `<selector>`
  - Probe ARIA observation — `error-context.md` or CLI snapshot (the specific ARIA tree fragment showing the scenario's intended element): <observation>
  - New target (key + primary selector): `<newKey>` → `<newSelector>`
  - Why the Explorer's target was wrong: <one sentence tying scenario text to the probe observation>
```

**If ANY of the three conditions fails** — scenario ambiguous, multiple probe candidates, or incomplete evidence — the Executor MUST escalate with `test.fixme('UNFIXABLE: Option (e) probe suggests Explorer retarget needed, but [condition N] not met — human review required')`.

**Why this rule is conditional, not permissive:** LLMs are reliable on deterministic transformations (scenario intent is clear + one matching element = deterministic) and unreliable on judgment calls (ambiguous intent or multiple candidates = guessing). The three conditions route each case to its strength.

**When the retarget is blocked by this rule,** the escalation message MUST flag the Explorer capture as needing re-exploration so the next pipeline run fixes the root cause at the Explorer stage, not in Executor code.

**The `UNFIXABLE:` marker** signals to humans that automated healing has been exhausted for this specific issue. It's different from `POTENTIAL BUG:` (app defect) and `SCENARIO BLOCKED:` (step can't execute as written).

> The Semantic Guard (`fix-discipline` knowledge §2 rule #9) still bounds every rewrite: pacing/scoping/locator-strategy changes on the SAME target are always allowed; silently changing the target is not — except via this conditional exception with all three conditions met.

