---
name: web-pacing
description: Classify a web app's rendering behavior (spa-async / server-rendered / hybrid-hydration) via the marker-survival navigation probe, and choose the correct wait strategy with the 5-tier pacing hierarchy. The Explorer records the signal + per-action waits; the Builder generates waits from them.
version: "1.0"
---

# web-pacing

> Shared skill. The **Explorer** applies it to observe rendering timing, run the navigation probe on context-changing actions, classify the app's `App Behavior`, and record the working wait per action. The **Builder** consumes those records to generate correct waits. (Section numbers preserved from source for internal cross-reference.)

### 4.8a: App-Level Pacing Signal — MANDATORY Observation

**While walking the scenario, track cross-route rendering timing. Emit a single app-level signal in the enriched.md header so the Builder can generate correct waits up front — not discover them cycle-by-cycle.**

**What to track** during exploration:
- After each route-changing interaction (navigation, SPA link click, view change), observe how long until the landmark element of the new page renders (heading, main section).
- Note whether the browser URL changes instantly but the content paints later (SPA async), both change together (server-rendered), or neither changes (in-place partial update).
- **Observe navigation events, not just URL shape.** URL path equality does NOT imply "no navigation" — an action that fires a real page navigation (cookies cleared from DOM, `load` event re-fires, `domcontentloaded` re-fires) may land back on a URL that LOOKS the same as before (e.g., role-switcher that navigates through `/switch_context` → `/dashboard` but the starting page was also `/dashboard`). Misclassifying a real navigation as in-place SPA update is a documented failure mode that costs multiple Executor cycles to recover from.

**Navigation-event probe — MANDATORY for any action that changes user context** (role/tenant/organization switch, logout+login, context-active-entity change). Use the **marker-survival** pattern — event listeners do not survive a real navigation, so they cannot be used as a positive signal for navigation. A window-scoped marker CAN be checked post-action for survival, which is the reliable signal.

```javascript
// Step 1 — BEFORE the triggering action, plant a marker on the window and capture navigation-entry count:
await browser_evaluate({
  expression: `
    window.__nav_marker = 'EXPLORER_${Date.now()}_${Math.random()}';
    window.__nav_entry_count_before = performance.getEntriesByType('navigation').length;
    window.__nav_url_before = window.location.href;
    window.__nav_marker
  `
});
// Store the returned marker string locally as `plantedMarker`.

// Step 2 — Trigger the action (MCP click, selectOption, etc.). Allow up to ~3s for any resulting navigation to settle.

// Step 3 — AFTER the action, read back the marker and the navigation-entry count:
const result = await browser_evaluate({
  expression: `
    ({
      marker: (typeof window.__nav_marker === 'string') ? window.__nav_marker : null,
      entryCountAfter: performance.getEntriesByType('navigation').length,
      entryCountBefore: window.__nav_entry_count_before ?? null,
      urlBefore: window.__nav_url_before ?? null,
      urlAfter: window.location.href
    })
  `
});
```

**Classification rule based on the returned object:**

| `result.marker` | `entryCountAfter` vs `entryCountBefore` | `urlAfter` vs `urlBefore` | Classification |
|---|---|---|---|
| `null` (marker gone) | N/A (before-value lost with window) | Any | **Real navigation (document replaced)** — Builder MUST emit `await page.waitForLoadState('load', { timeout })` AFTER the triggering action, BEFORE the landmark wait |
| Equal to `plantedMarker` | `after > before` | Any | **Real navigation with same window context** (rare — typically only first document load) — Builder treats as real navigation |
| Equal to `plantedMarker` | Equal | Different path | **SPA route change (same document, URL updated)** — Builder emits `waitForURL(newPathPattern)` + landmark wait |
| Equal to `plantedMarker` | Equal | Identical | **In-place SPA update (no navigation)** — Builder emits landmark wait only |

**Record findings in the Dynamic Content Map:**

```markdown
| Org switch (step 47) | Real navigation (marker gone, document replaced) | page.waitForLoadState('load') + landmark wait on filterButton |
```

**Builder contract when the Dynamic Content Map entry says "Real navigation (marker gone, document replaced)":**
- After the triggering action, emit `await page.waitForLoadState('load', { timeout })` BEFORE the landmark wait.
- Do NOT rely on landmark wait alone — the previous page's DOM can still be visible during the navigation, causing the landmark wait to return immediately against stale DOM.

**Record findings in the Dynamic Content Map:**

```markdown
| Org switch (step 47) | Real navigation (load event fired) | page.waitForLoadState('load') + landmark wait on filterButton |
```

**Builder contract when the Dynamic Content Map entry says "Real navigation (load event fired)":**
- After the triggering action, emit `await page.waitForLoadState('load', { timeout })` BEFORE the landmark wait.
- Do NOT rely on landmark wait alone — the previous page's DOM can still be visible during the navigation, causing the landmark wait to return immediately against stale DOM.

**When to run the probe:** context-switch actions (org/tenant/role), explicit "change active X" UI controls, and any action where the Explorer sees the filter/content visibly reset or reload even without an obvious URL change. Skip the probe for ordinary button clicks inside a page that only update partial DOM.

**Classification — emit exactly ONE of these in the enriched.md header `## App Behavior:` line:**

| Signal | Meaning | When to use |
|---|---|---|
| `spa-async` | URL changes instantly on route change, but landmark element renders 1–5s later. Seen on two or more route transitions during this exploration. | Most SPAs: React/Vue/Angular/Ember apps, OrangeHRM, Salesforce Lightning, Workday, most "modern" enterprise UIs |
| `server-rendered` | URL and content change together (both appear after `load` event). Landmark is in DOM at `domcontentloaded`. | Classic server-rendered apps: older JSF, ASP.NET WebForms, plain-HTML server apps |
| `hybrid-hydration` | Server-rendered HTML shows immediately, then JS hydration replaces/upgrades interactive elements 1–3s later (click handlers bind late). | Next.js/Nuxt SSR apps, Rails with Hotwire/Turbo, some Blazor Server apps |
| `unknown` | Only one route transition observed or timing was inconsistent. | Short scenarios with ≤1 route change |

**Emit the signal** in the enriched.md's header block (after `## Detail Level` and before `## Common Setup`):

```markdown
## App Behavior: spa-async
The application exhibits SPA async rendering — route URL changes are instant, but
landmark elements render 1–5s later. Observed on the following transitions during
exploration:
- Login → /dashboard (dashboard heading rendered ~2s after URL change)
- Claim nav click → /claim/viewAssignClaim (banner heading rendered ~2s after URL change)
- View Details → /claim/submitClaim/id/3 (submit-claim heading rendered ~4s after URL change)
Builder: implement visibility VERIFY checks in the owning page object's semantic
assertion method with a bounded retry; use waitForURL+landmark wait for post-click
navigation; prefer URL/landmark waits over waitForLoadState('networkidle').
```

**Builder contract — MANDATORY when the signal is `spa-async` or `hybrid-hydration`:**

1. Every VERIFY / VERIFY_SOFT visibility check calls a semantic assertion method on the owning page object; that method uses a retrying visibility assertion or bounded `waitFor` against its cached locator.
2. Every post-click navigation method in a page object follows the pacing hierarchy (see §4.8b below) — **not** `waitForLoadState('networkidle')` by default.
3. Every `is{X}Visible()` / `is{X}Hidden()` page-object helper uses `waitFor({state})` wrapped in try/catch — NEVER bare `isVisible()` / `isHidden()`.

**Builder contract when signal is `server-rendered`:** `waitForLoadState('load')` + direct `isVisible()` is acceptable. `networkidle` is still not the default — prefer landmark waits.

**If `unknown`:** Builder defaults to the stricter `spa-async` contract. Better to over-wait than to under-wait.

### 4.8b: Pacing Hierarchy — Prefer URL and Landmark Over Network-Idle

**The Explorer MUST record the post-action wait that worked during the live walk, and the Builder MUST translate it to code using this priority order.** `networkidle` is last resort — on apps with analytics beacons, websockets, or long-polling (most enterprise apps) it never fires and becomes a 30s false timeout.

| Priority | Strategy | When to use | Builder code pattern |
|---|---|---|---|
| 1 | `waitForURL(/pattern/)` | Action triggers a route change | `await this.page.waitForURL(/\/dashboard/, { timeout });` |
| 2 | Landmark-element wait | Action reveals a specific post-state element (heading, panel, row) | `await this.page.locator(this.loc.get('landmarkKey')).waitFor({ state: 'visible', timeout });` — or `await pageObj.waitForReady('landmarkKey')` if BasePage primitive is available |
| 3 | `waitForResponse(urlPattern)` | Action triggers a specific XHR that the next step depends on | `await this.page.waitForResponse(r => r.url().includes('/api/claims') && r.ok(), { timeout });` |
| 4 | `waitForLoadState('domcontentloaded')` | Full-page navigations to a new URL (multi-page / server-rendered apps) | `await this.page.waitForLoadState('domcontentloaded');` |
| 5 | `waitForLoadState('networkidle')` | **LAST RESORT.** Only when none of the above exist AND the app is NOT known to have persistent network activity (analytics/websockets/polling). | `await this.page.waitForLoadState('networkidle', { timeout });` — always paired with an explicit short timeout |

**When the Explorer notes a slow post-action transition in its report** (`Dynamic Content Map` entry), the Explorer MUST pick one of priorities 1–3 and record it alongside the `<!-- DISCOVERED: ... -->` note. Default-to-`networkidle` is an anti-pattern and MUST NOT be recommended when a URL pattern or landmark selector is available.

**Example — correct pacing annotation in enriched.md:**

```markdown
19. Click Reference Id "202307180000003" to open the claim detail <!-- ORIGINAL -->
    <!-- ELEMENT: { ... } -->
    <!-- DISCOVERED: Post-click navigation to /claim/submitClaim/id/{N} takes ~3-5s.
         Pacing: use waitForURL(/\/submitClaim\/id\//) + landmark wait on "Submit Claim" heading.
         NOT networkidle — OrangeHRM analytics prevent networkidle from firing within 30s. -->
```

**Builder then generates:**

```typescript
async clickViewDetails(rowKey: string): Promise<void> {
  await this.page.locator(this.loc.get(rowKey)).click();
  await this.page.waitForURL(/\/submitClaim\/id\//, { timeout: 30000 });
  await this.page.locator(this.loc.get('submitClaimHeading'))
    .waitFor({ state: 'visible', timeout: 30000 });
}
```

