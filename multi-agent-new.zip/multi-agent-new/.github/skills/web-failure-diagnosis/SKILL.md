---
name: web-failure-diagnosis
description: "The Executor's diagnostic brain for a failing web/api test: the Diagnostic Gate (element-presence → operation-type split), multi-failure/cascade handling, the fixes-vs-escalates decision tables with proven enterprise pacing recipes, and the same-root-cause operational definition + Menu-Driven Reset (orthogonal strategy menus) that prevents repeating a failed fix."
version: "1.0"
---

# web-failure-diagnosis

> Loaded by the **Executor** after a test run reports failures, BEFORE any fix is written. It classifies each failure, decides fix-vs-escalate, and — when the same root cause persists — forces a genuinely different strategy from a menu rather than another tactical variation. The MCP-based healing/structural-probe path (Trigger A/B) and the option-(e) informed-retarget rule live in the `web-selector-healing` skill. (Section numbers preserved from source for internal cross-reference.)

## 4.4: Diagnostic Gate — MANDATORY Before Classifying

**This is the most important diagnostic step. It prevents the #1 cycle-wasting pattern from v1: changing selectors when the element IS present.**

**Step A — Element Presence Check:**
Query the error-context.md DOM snapshot for the failing element — `node scripts/snapshot-query.js --file=<error-context.md> --find="<element name/text>"` (do NOT Read the file whole; it is a full-page aria tree, 20K–80K tokens on data-heavy pages). Is the failing element present in the DOM? (Use `--interactive` for a page overview if you need to see what page you actually landed on.)

**If element IS present in DOM:**
- Category B (Locator Not Found) is **CLOSED** — DO NOT change the selector
- Proceed to **Operation-Type Split** (Step B)

**If element is NOT present in DOM:**
- The element genuinely doesn't exist on the page
- Check: is the browser on the wrong page? Did navigation fail? Is there an auth wall?
- If wrong page → fix navigation/auth issue
- If correct page but element missing → **attempt Selector Healing (see the `web-selector-healing` skill)** — the Executor can discover the element from the live page and add it to the locator JSON

**Step B — Operation-Type Split (only when element IS present):**

| What failed? | Diagnosis | Fix |
|-------------|-----------|-----|
| ACTION timed out (click, fill) on present element | **Interaction Pacing** — app is slow, element not actionable yet | Add `waitForSelector({state:'visible'})` before action. If that fails, try `pressSequentially` with delay, or add `// PACING: [reason]` wait |
| VALUE READ returned wrong result on present element | **DOM Navigation** — selector points to container, not the text node | Check the Capture path — is `textContent()` reading the right child? Try `.innerText()` or narrow the selector |
| ASSERTION failed with correct element and correct read | **Potential App Bug OR Stale Data** — the value genuinely doesn't match | Check scenario source. If scenario specifies the expected value → `test.fixme('POTENTIAL BUG: expected X, found Y')`. If value comes from CAPTURE → check the capture step |

## 4.4a: Multi-Failure and Cascade Handling — MANDATORY

**When multiple steps fail in one cycle, you MUST follow these rules:**

1. **MUST apply the Diagnostic Gate (4.4) to EACH failure independently** — classify ALL failures first, THEN fix. DO NOT fix one and re-run without diagnosing the others
2. **MUST detect cascades:** If Steps 5, 6, 7, 8 all fail but Step 5 is the FIRST failure, Steps 6-8 likely depend on Step 5's output. **MUST fix Step 5 ONLY** — re-run to see if the cascade resolves. DO NOT waste time fixing cascade symptoms
3. **MUST fix ALL independent (non-cascade) failures in one cycle** — DO NOT fix one independent failure and re-run. This wastes cycles. Fix all diagnosable issues at once
4. **Cascade detection hint:** If multiple failures start AFTER one step, and their errors are "element not found" while the first step's error is "timeout on navigation" → the first step is the root cause. **MUST NOT fix cascade steps — fix the root ONLY**

## 4.5: What the Executor Fixes vs Escalates

**The Executor FIXES (timing/sequencing/minor):**

| Issue | Signal | Fix |
|-------|--------|-----|
| Missing wait after navigation | `page.goto()` followed by immediate interaction | Add `await page.waitForLoadState('networkidle')` |
| Missing wait for element | Timeout on element that eventually appears | Add `await page.waitForSelector()` before interaction |
| Interaction pacing | Element present but action times out | Try `pressSequentially(value, { delay: 100 })` for inputs, or add `await page.waitForTimeout(500); // PACING: [component] loads slowly after [action]` |
| Missing wait after interaction | Click triggers async update, next step runs too early | Add wait for expected state change |
| Race condition | Test passes sometimes, fails sometimes | Add deterministic wait |
| Import error | Module not found | Fix the import path |
| TypeScript error | Type mismatch, missing await | Fix the type or add await |
| Shared state pollution | Previous test left cookies/localStorage/pre-filled forms | Add cleanup in `afterEach` or `beforeEach`, or isolate with new browser context |

### Enterprise Pacing Recipes — Proven Fix Patterns

When the Diagnostic Gate identifies **Interaction Pacing** (element present, action times out), use these specific recipes:

| Component Type | Signal | Recipe |
|---------------|--------|--------|
| **Autocomplete/lookup input** | `fill()` types but dropdown doesn't appear | Replace `fill()` with `pressSequentially(value, { delay: 100 })` — gives server time to respond per keystroke |
| **Kendo/Telerik dropdown** | Click opens nothing or times out | Two-step: `click()` to open → `waitForSelector('.k-animation-container', { state: 'visible' })` → `click()` option |
| **PCF grid filter** | `fill()` types but grid doesn't filter | Use `pressSequentially()` — PCF filter inputs need keydown/keyup events |
| **Post-click dynamic content** | Click succeeds but next step fails (content not loaded) | Add `waitForLoadState('networkidle')` after click. If insufficient, add `waitForTimeout(500); // PACING: [component] loads dynamically after [action]` |
| **Panel/drawer open** | Click opens panel but elements inside aren't ready | Add `waitForSelector('.panel-content', { state: 'visible' })` before interacting with panel content |
| **SPA navigation** | URL changes but content doesn't update | Add `waitForURL(/expected-path/)` + `waitForSelector('[data-testid="page-indicator"]')` — wait for BOTH URL and content |
| **Slow enterprise app** | Multiple timeouts across the scenario | Check app-context for documented slowness. Add `// PACING:` waits where needed. Update app-context with timing info |

**MUST** add `// PACING: [reason]` comment to EVERY `waitForTimeout` — this protects it from Reviewer removal. **MUST** update app-context with the discovered pacing pattern. (See the `web-pacing` skill for the rendering-behavior classification these recipes build on, and the `app-context` knowledge for the append-or-create write obligation.)

**The Executor MUST NOT fix (escalate instead):**

| Issue | Signal | Action |
|-------|--------|--------|
| Wrong expected value | Assertion fails, element found, correct read, value differs from scenario | **STOP.** `test.fixme('POTENTIAL BUG: expected "X" but found "Y"')` |
| Scenario flow issue | Step depends on failed earlier step | **STOP.** Fix the root cause (earlier step), not the cascade |
| Architecture issue | Page object or locator file missing entirely | **STOP.** Builder output incomplete. Escalate |
| Helper file issue | Method in `*.helpers.ts` fails | **STOP.** `test.fixme('HELPER ISSUE: ...')`. NEVER modify helpers |

> For the full STOP-on-user-side trigger set and the escalate-vs-edit boundaries, see the `fix-discipline` knowledge. For the flag-vs-adapt POTENTIAL BUG decision gate, see the `bug-detection` knowledge.

## 4.7: Same-Root-Cause Detection — MANDATORY

**After each cycle, compare the current failure against the previous cycle using the OPERATIONAL DEFINITION below. "Same error type" is NOT the definition — it is too loose and produces a loophole (symptom-value changes like `count=636 → count=0 → count=-1` would reset the counter despite being the same underlying misunderstanding).**

**Operational definition — Two consecutive cycle failures have the SAME ROOT CAUSE if and only if BOTH of the following are true:**

1. **Same failing step number** (e.g., both cycles fail at Step 35), AND
2. **Same §4.4 failure category** — one of:
   - **Interaction Pacing** — action times out on present element
   - **DOM Navigation-Wrong-Read** — value read returns wrong result on present element (includes count queries returning unexpected numbers)
   - **Assertion-Value-Mismatch** — assertion fails with correct element and correct read, wrong expected value
   - **Element-Not-Found** — element is NOT in DOM
   - **Overlay-Blocked** — present element, click intercepted by overlay
   - **Scroll-Viewport** — present element, "outside of viewport" error

**Symptom-value changes within the same category do NOT reset the counter.** Examples that are SAME root cause (not a reset):
- Step 35: count returned 636 (Cycle 2) → count returned 0 (Cycle 3). Both are DOM Navigation-Wrong-Read. Counter keeps advancing.
- Step 10: click timeout 30s (Cycle 1) → click timeout 60s after waitForSelector added (Cycle 2). Both are Interaction Pacing. Counter keeps advancing.

**Category CHANGES are genuine progress signals — counter resets to zero.** Examples that ARE a different root cause (reset):
- Step 10 Cycle 2: Interaction Pacing (click timed out). Cycle 3: DOM Navigation-Wrong-Read (click succeeded, wrong text captured). Category changed — Cycle 2's fix worked; a different issue emerged.
- Step 35 Cycle 3: DOM Navigation-Wrong-Read (wrong count). Cycle 4: Element-Not-Found (container disappeared after a fix). Category changed.

**Escape valve — claiming root-cause change WITHIN the same category:** if the Executor has evidence that the root cause genuinely changed despite category being the same, it MUST document in the cycle entry with ALL of the following, or the counter does NOT reset:

```markdown
- **Root-cause-change claim:** same category (DOM Navigation-Wrong-Read), different root cause.
  - Before fix, error text: "<exact error from Cycle N-1>"
  - After fix, error text: "<exact error from Cycle N, showing the prior issue is resolved>"
  - Before fix, DOM snapshot signature: "<key observable from error-context.md>"
  - After fix, DOM snapshot signature: "<changed observable>"
  - New diagnosis: "<what the new issue is and why it is distinct>"
```

Without this evidence block, the same-root-cause counter keeps advancing regardless of symptom-value change.

**Trigger:** if the same root cause (per operational definition) persists for **2 consecutive cycles** → DO NOT attempt a 3rd identical fix. Apply the **Menu-Driven Reset** below.

### Menu-Driven Reset — MANDATORY after 2 same-root-cause cycles on the same step

**Why this exists:** "try a fundamentally different approach" without constraint produces tactical variations of the last attempt. A concrete menu of orthogonal strategies forces the Executor to pick a genuinely different approach.

**Procedure for Cycle N+1 (where Cycles N and N-1 had the same root cause on the same step):**

1. **Identify the failure category** from the table below.
2. **List the strategies tried** in Cycles N-1 and N (cite them by bullet letter).
3. **Pick a strategy NOT yet tried** from the category's menu. If all menu strategies have been tried, escalate with `test.fixme('UNFIXABLE: menu exhausted for [category] — tried [a,b,c,d]')`.
4. **Delete the current implementation of the failing method / block** before writing the new one. Do NOT tweak in place — that anchors the LLM on the last attempt. Replace, don't patch.
5. **State the chosen strategy explicitly in the cycle report:**
   ```markdown
   - **Menu-Driven Reset applied** (Category: Count/Assertion ambiguity). Tried: (a) DOM walk with visibility filter, (b) getComputedStyle ancestor walk. Choosing: (c) role+region scoping with `toHaveCount`. Implementation rewritten from scratch.
   ```

**Strategy menus — the Executor MUST pick an untried strategy from the menu for its category. Improvisation outside the menu is PROHIBITED. If every strategy in the applicable category has been tried, escalate with `test.fixme('UNFIXABLE: menu exhausted for [category] — tried [a,b,c,d,e]')`. Novel failure shapes that do not match any category are covered by the default-escalation clause below, not by inventing new strategies.**

**Every category menu ends with option (e) — MCP Live-Probe — which is reachable via the `web-selector-healing` skill (Trigger B).** Option (e) is NOT an optional extra; it is a first-class untried strategy that the Executor MUST pick before escalating. Option (e)'s output is an INFORMED re-selection from options (a)-(d) of the same category based on observed ground truth — not a separate hand-rolled fix.

**Category: Count / "exactly N" assertion ambiguity** — symptoms: wrong count returned, count=0 or count=way-too-many on a search-filtered list.

| # | Strategy |
|---|---|
| a | Role-based locator with `.filter({ hasNotText })` + `toHaveCount(N)` (see the `web-verify` skill / `web-codegen-spec` VERIFY count modifiers) |
| b | ARIA-region scoping: `getByRole('region', { name: 'X' })` + role-based child locator + `toHaveCount` |
| c | Assert each named item individually with `getByRole({ name: fromTestData })` + `toBeVisible()` — do NOT count |
| d | CSS scoping via Explorer-captured region anchor + `toHaveCount` on a narrowed selector |
| e | **MCP Live-Probe (`web-selector-healing` Trigger B).** Take a Playwright MCP `browser_snapshot` of the live failure state. Read the ARIA tree for the target region — observe: does the region use shadow DOM? does `display:contents` hide children from `offsetParent`? are there multiple same-named regions? Use observed structure to re-pick (a)-(d) with ground truth. |

**Category: Element interaction timing / pacing** — symptoms: click/fill times out on present element, stale state after navigation.

| # | Strategy |
|---|---|
| a | Add `waitForSelector({ state: 'visible' })` before action |
| b | Replace `fill()` with `pressSequentially(value, { delay })` for reactive inputs |
| c | Add `waitForLoadState('load')` after suspected navigation-triggering actions (see the `web-pacing` skill navigation-event classification) |
| d | Add explicit landmark wait on the post-action element with `// PACING:` comment |
| e | **MCP Live-Probe (`web-selector-healing` Trigger B).** Take a Playwright MCP `browser_snapshot` of the pre-action state — observe: is the target in an offscreen scroll container? is a spinner covering the region? is the action target's parent disabled? Use observed state to re-pick (a)-(d). |

**Category: Overlay / z-index / pointer-events blocking** — symptoms: element present but click intercepted; screenshot shows a banner/dialog above the target.

| # | Strategy |
|---|---|
| a | Dismiss the overlay via its own dismiss control (button click, close icon) and wait for `state: 'hidden'` before the blocked action |
| b | Scope overlay dismissal via role-qualified selector (see the `web-element-capture` skill semantic-specificity tiebreaker), not bare attribute |
| c | Set `pointer-events: none` on the overlay via `page.evaluate()` if no dismiss control exists — last resort, document why |
| d | Check whether the overlay is re-appearing per-interaction; if so, install the dismiss guard inside the page-object method, not the spec |
| e | **MCP Live-Probe (`web-selector-healing` Trigger B).** Take a Playwright MCP `browser_snapshot` of the failure state — observe: what is the overlay's actual role/label? is it a sibling or ancestor of the target? multiple overlays stacked? Use observed topology to re-pick (a)-(d) with the correct overlay selector. |

**Category: Scroll / viewport** — symptoms: element "outside of the viewport" even after `scrollIntoViewIfNeeded`.

| # | Strategy |
|---|---|
| a | `scrollIntoViewIfNeeded()` on the element itself (default Playwright behavior — may not pierce scrollable container) |
| b | Scroll the containing scrollable ancestor: `container.evaluate(el => el.scrollTop = el.scrollHeight)` or target scroll on the ancestor |
| c | Use `locator.waitFor({ state: 'visible' })` — `visible` requires in-viewport; if it times out, the scroll container is the issue |
| d | Reduce viewport scope or use `page.mouse.wheel()` inside the scroll container |
| e | **MCP Live-Probe (`web-selector-healing` Trigger B).** Take a Playwright MCP `browser_snapshot` of the failure state — observe: which ancestor has `overflow: auto/scroll`? is the target genuinely rendered or virtualized-out? Use observed scroll topology to re-pick (a)-(d). |

**Default when no category matches:** escalate with `test.fixme('UNFIXABLE: [symptom] does not match any Menu-Driven Reset category — human review needed')`. DO NOT invent a new category or a new strategy. Novel failure shapes are escalation signals, not improvisation opportunities.

**Semantic Guard still applies** (see the `fix-discipline` knowledge §2 rule #9): a Menu-Driven Reset rewrite MUST NOT silently change the element target. Pacing / scoping / locator-strategy changes on the SAME target are always allowed.

> **Informed retargeting under option (e)** — when an MCP probe reveals the Explorer captured the wrong target for the scenario's intent, a conditional retarget MAY be allowed. That exception (its three conditions + required evidence chain) is governed by the `web-selector-healing` skill, not here.

