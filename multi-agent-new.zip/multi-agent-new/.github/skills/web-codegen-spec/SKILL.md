---
name: web-codegen-spec
description: "How the Builder assembles the spec file: language selection, spec structure, the DSL keyword → code contract (VERIFY/VERIFY_SOFT/CAPTURE/CALCULATE/SCREENSHOT/REPORT/SAVE), USE_HELPER, control-flow (IF/REPEAT/FOR_EACH/TRY_ELSE), Grid/Aggregate verification patterns, API CRUD chains, lifecycle hooks, tags, file download, and the step-completeness rule."
version: "1.0"
---

# web-codegen-spec

> Applied by the Builder when assembling `output/tests/{type}/{scenario}.spec.ts`. Per-action code (navigate/click/fill/…) comes from the interaction skills; this skill covers spec structure + the DSL keyword contract + control-flow + helpers + API. Multi-scenario structure & lifecycle live in the `scenario-handling` knowledge; mobile codegen is Phase 2. (Section numbers preserved from source.)

## Language Selection

## 0. Language Selection — MANDATORY First Check

**BEFORE generating any code, determine the target language:**

1. Read `output/.language` file — it contains `typescript`, `javascript`, or `python`
2. If file doesn't exist → default to `typescript`
3. Read the language profile: `languages/{language}.profile.json` (delivered to the project root by the stack installer)
4. The profile defines: naming conventions, assertion syntax, file extensions, import patterns, fixture patterns

**ALL code generation rules in this file show TypeScript examples by default.** When generating for other languages, adapt using the language profile:

| Aspect | TypeScript | JavaScript | Python |
|--------|-----------|------------|--------|
| File extension | `.ts` | `.js` | `.py` |
| Spec naming | `{scenario}.spec.ts` | `{scenario}.spec.js` | `test_{scenario}.py` |
| Page object | `{Page}Page.ts` | `{Page}Page.js` | `{page}_page.py` |
| Class export | `export class` | `class ... module.exports` | `class` |
| Imports | `import { X } from 'Y'` | `const { X } = require('Y')` | `from Y import X` |
| Async model | `async/await` | `async/await` | **Sync** (no async/await) |
| Assertions | `expect(loc).toHaveText()` | `expect(loc).toHaveText()` | `expect(loc).to_have_text()` |
| Env vars | `process.env.X` | `process.env.X` | `os.environ["X"]` |
| Method naming | `camelCase` | `camelCase` | `snake_case` |
| Step wrapper | `test.step('Step N', ...)` | `test.step('Step N', ...)` | `# Step N — {label}` (comment) |
| Capture vars | `let x: string` | `let x` | `x = None` |

**CRITICAL for Python:**
- Sync API by default — NO `async/await`
- Methods are `snake_case`
- NO `test.step()` equivalent — use `# Step N — {label}` comments as step markers
- Use `pytest.mark.{tag}` decorators for tags instead of `{ tag: [...] }`
- **NO `expect.soft()`** — for VERIFY_SOFT, collect assertion errors without stopping:
  ```python
  # VERIFY_SOFT: Cart badge shows "2"
  soft_errors = []
  try:
      expect(page.locator(loc.get("cart_badge"))).to_have_text("2")
  except AssertionError as e:
      soft_errors.append(str(e))
      page.screenshot(path=f"screenshots/VERIFY_SOFT-failed-cart-badge.png")
  # At end of test: assert not soft_errors, f"Soft assertions failed: {soft_errors}"
  ```
- **SCREENSHOT attach:** Use `page.screenshot(path="screenshots/{name}.png")` — no `test.info().attach()` in pytest. Use `pytest-html` plugin for report attachments
- **REPORT:** Use `print()` for console output + custom pytest fixture for structured reporting

---

---

## Spec File Structure

## 3. Spec File Structure — MANDATORY

**File location:** `output/tests/{type}/[{folder}/]{scenario}.spec.ts`

```typescript
import { test } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';

test.describe('{Feature Name}', () => {
  test('{Scenario Name}', { tag: ['@smoke', '@P0'] }, async ({ page }) => {
    const loginPage = new LoginPage(page);
    const scenarioSteps: Array<{ title: string; action: () => Promise<void> }> = [
      { title: 'Step 1 — Navigate to login page', action: () => loginPage.goto(process.env.BASE_URL!) },
      { title: 'Step 2 — Enter username', action: () => loginPage.fillUsername(process.env.TEST_USERNAME!) },
      { title: 'Step 3 — VERIFY: Login successful', action: () => loginPage.verifyDashboardDisplayed() },
    ];

    for (const step of scenarioSteps) {
      await test.step(step.title, step.action);
    }
  });
});
```

**Rules — HARD STOP on each:**

1. **Every scenario step MUST have one descriptor** with a `title: 'Step N — {description}'` and an `action: () => Promise<void>`; execute ordered descriptors with `for...of` and `await test.step(step.title, step.action)`. Each action remains an individual Playwright report step.
2. **Step numbers MUST be sequential** (1, 2, 3...) — positional count, NOT the user's original numbers
3. **Step descriptions MUST match the scenario intent** — DO NOT paraphrase to change meaning. **MUST use template literals** for runtime values: `` `Step 8 — Lookup ${testData.customerName}` `` — so the HTML report shows real data, not placeholder text
4. **CAPTURE variables MUST be declared with `let` in the OUTER test scope** — NOT inside test.step. This is a Playwright scoping requirement.
5. **Tags MUST have `@` prefix:** `{ tag: ['@smoke', '@P0'] }`
6. **All `{{ENV.VARIABLE}}` MUST become `process.env.VARIABLE`** — NEVER hardcode values
7. **DO NOT add steps that are not in the scenario** — the spec is a faithful translation, not an enhancement
8. **DO NOT combine, merge, or simplify steps** — every scenario step has exactly one descriptor and one `test.step` report entry. Complex branching, lifecycle hooks, or CAPTURE steps whose values are scoped across actions may use direct `test.step()` blocks, but must preserve one reported step per source step.
9. **Never add `console.log` to generated specs.** Step titles provide Playwright report visibility; use `test.info().annotations.push()` for machine-readable REPORT output. Page-object `logger.info()` follows the page-object skill.
10. **Execute scenario actions sequentially.** Do not use `Promise.all()` or `steps.map(async ...)` to run actions; browser steps are order-dependent. Use an awaited `for...of` loop.

**Standard linear-flow pattern:**
```typescript
const scenarioSteps: Array<{ title: string; action: () => Promise<void> }> = [
  { title: 'Step 1 — Open the store menu', action: () => homePage.openStoreDropdown() },
  { title: 'Step 2 — Select the store', action: () => homePage.selectStore(testData.store) },
];

for (const step of scenarioSteps) {
  await test.step(step.title, step.action);
}
```

Use the descriptor-list pattern for linear action sequences. Preserve direct `test.step()` blocks for control-flow steps, lifecycle hooks, or CAPTURE steps that require values to be assigned and read across step boundaries; do not make those cases less clear just to force an array.

### 3a. Import Path Depth — MANDATORY (folder-aware)

**Every relative import in the spec is resolved against the generated-project root `output/`.** The number of `../` segments is determined by how deep the spec sits, so it MUST be recomputed when the run has a `folder` parameter (the spec then sits one directory deeper).

| Spec location | Up to `output/` | Page-object import | Scenario test-data import | Core import (`loadTestData`/`saveState`/etc.) |
|---|---|---|---|---|
| `output/tests/{type}/{scenario}.spec.ts` (no folder) | `../../` | `../../pages/{PageName}Page` | `../../test-data/{type}/{scenario}.json` | `../../core/{module}` |
| `output/tests/{type}/{folder}/{scenario}.spec.ts` (foldered) | `../../../` | `../../../pages/{folder}/{PageName}Page` | `../../../test-data/{type}/{folder}/{scenario}.json` | `../../../core/{module}` |

**Rules:**
- **Page objects, locators, and scenario test-data carry the SAME `[{folder}/]` segment as the spec** — never import a flat page object from a foldered spec or vice versa.
- **`output/core/*` and `output/test-data/shared/` are NEVER foldered** — only the depth (`../` count) changes, the `core/` / `test-data/shared/` path does not gain a `{folder}` segment.
- **Compute the depth, do not memorize it.** From the spec's directory, count directories up to `output/`, emit that many `../`, then descend into `pages/`, `test-data/`, or `core/` with the folder segment where applicable.
- The page object's own `super()` locator argument and `loadTestData('{type}/[{folder}/]{scenario}', …)` path argument carry the folder too — see the `web-codegen-pageobject` (§2a) and `web-codegen-locators` skills.

> NOTE: TypeScript examples elsewhere in this skill show the **no-folder** depth (`../../pages/…`, `../../core/…`) for brevity. When generating for a foldered run, add one `../` per the table above.

---

---

## Keyword Contract (DSL → code) — canonical reference

## VERIFY — Mid-Step Assertions

**Scenario:** `VERIFY: Cart badge shows "2"`

**Explorer action** (verify in browser) / **Builder action** (generate code): Check the stated condition on the current page and log pass/fail.

**Generated code:**
```typescript
// VERIFY: Cart badge shows "2"
expect(await inventoryPage.getCartBadgeCount()).toBe(2);

// VERIFY: URL contains "/dashboard"
await expect(page).toHaveURL(/\/dashboard/);
```

### VERIFY count/comparison modifiers — Builder MUST use the canonical Playwright idiom

**Why this table exists:** when a VERIFY step asserts a **count** or **comparison** against a list (e.g., "Exactly 3 rows"), Builder must emit the Playwright-native assertion. Hand-rolled DOM-walking or `evaluate()`-based counting is a documented failure class — it invites multi-cycle Executor fix loops on shadow-DOM / display:contents / ARIA-region edge cases that the built-in retry-capable locator assertions handle correctly.

| Scenario phrase | Canonical Playwright idiom |
|---|---|
| `VERIFY: Exactly N <items> displayed` / `VERIFY: Exactly N <items> shown` | `await expect(scope.getByRole('{role}').filter({ hasNotText: '<exclusion>' })).toHaveCount(N);` |
| `VERIFY: Exactly the following items are displayed` (list given) | `toHaveCount(N)` AND one `toBeVisible()` per named item from test-data |
| `VERIFY: At least N <items>` / `VERIFY: No fewer than N` | `expect(await scope.getByRole('{role}').count()).toBeGreaterThanOrEqual(N);` |
| `VERIFY: No more than N` | `expect(await scope.getByRole('{role}').count()).toBeLessThanOrEqual(N);` |
| `VERIFY: No <items> displayed` | `await expect(scope.getByRole('{role}')).toHaveCount(0);` |
| `VERIFY: <element> contains text "X"` | `await expect(loc).toContainText('X');` |
| `VERIFY: <element> text exactly matches "X"` | `await expect(loc).toHaveText('X');` |
| `VERIFY: <element> is visible` | In the owning page object: `await expect(cachedLocator).toBeVisible();`; the spec calls a semantic `verify...Visible()` method |
| `VERIFY: <element> is hidden` / `is not displayed` | In the owning page object: `await expect(cachedLocator).toBeHidden();`; the spec calls a semantic `verify...Hidden()` method |

For UI VERIFY steps, these canonical locator assertions belong inside the owning page-object method, not in the spec. The spec step calls that method and must not reference locator keys with `getLocator('key')`. URL assertions and API response assertions remain in their corresponding scenario actions.

**Canonical example — "VERIFY: Exactly 2 rows are displayed under the Items section" (scope = Items region, exclude header row):**

```typescript
// Canonical idiom — auto-retries until the assertion holds or times out
await expect(
  page.getByRole('region', { name: 'Items' })
      .getByRole('row')
      .filter({ hasNotText: 'Header' })
).toHaveCount(2);
```

**Anti-pattern — do NOT emit this shape:**

```typescript
// ANTI-PATTERN: hand-rolled DOM walk, no auto-retry, fragile under shadow DOM / display:contents
const cbs = await page.locator('section input[type="checkbox"]').all();
let count = 0;
for (const cb of cbs) {
  const name = await cb.evaluate(el => /* ... */);
  if (name && !name.includes('Header')) count++;
}
expect(count).toBe(2);
```

**Builder rule:** when the scenario step matches any phrase above, emit the canonical idiom from the right column. DO NOT substitute a hand-rolled `evaluate()`/`.all()` loop.

**When a scenario phrase is not an exact match to any row:** map it to the closest row whose assertion semantics match (e.g., "There must be 3 items" → "Exactly N <items> displayed"; "No items should appear" → "No <items> displayed"). Do NOT invent a new idiom — if the phrase semantically asserts count/visibility/comparison, it maps to a row above. If the phrase is NOT a count/comparison assertion, the VERIFY-modifiers table does not apply; use the base VERIFY pattern.

**When the canonical idiom fails at runtime** (rare — e.g., truly closed shadow DOM), the Executor escalates via its Fix-Cycle Menu-Driven Reset — NOT by reverting to a hand-rolled DOM walk.

**Executor rule:** when a VERIFY-count step fails, the Executor MUST first check whether the spec emitted the canonical idiom. If not, the first fix is to REWRITE the assertion using the canonical idiom from the table (counts as the strategy reset for that step).

**Reviewer rule:** flag any VERIFY-count step whose implementation is a hand-rolled `.all()` + manual accumulator when the scenario phrase matches a row in the table. Dim 5 (Code Quality).

**Scope discipline:** when the scenario mentions a section/region (`under the Items section`, `in the sidebar`), scope the locator with `getByRole('region', { name: '...' })` or the Explorer-captured region anchor before the role-based child locator. Do NOT count across the whole panel when the scenario names a region.

**Executor rule:** If VERIFY fails but the selector IS correct (element found, wrong content), flag as POTENTIAL BUG — do NOT change the expected value.

**Reviewer check:** VERIFY steps must produce `expect()` assertions inline, not just at the end.

### Robust VERIFY for environmentally-variable values — apply the `web-verify` idioms

When the value a VERIFY targets varies at runtime for reasons unrelated to the behavior under test — **the current date/timestamp (timezone offset between app server and runner), a server-generated id/reference, or a data-dependent row count** — generate the resilient assertion from the **`web-verify`** skill ("Robust Assertions for Dynamic / Time-Sensitive Values") rather than a brittle exact match:
- "current date" / date-stamped filename → accept **today OR yesterday** (±1-day, TZ-tolerant), not a hardcoded date.
- text with a generated prefix but stable tail → match the **stable suffix/substring** (`toContainText` / `toHaveText(/…$/)`), not the whole string.
- "results are shown" / "grid has data" (no number stated) → `toBeGreaterThanOrEqual(1)`, not `toHaveCount(N)`.

**Gate (same as `web-verify`):** ONLY when the scenario did NOT pin an exact value. If the scenario states the exact date, id, or count, assert it exactly — and never silently change a scenario-stated expected value (that is a `POTENTIAL BUG`, per the CRITICAL GUARDRAIL).

---

## VERIFY_SOFT — Non-Blocking Assertions

**Scenario:** `VERIFY_SOFT: Cart badge shows "2"`

**Explorer action** (verify in browser) / **Builder action** (generate code): Same as VERIFY — check the stated condition on the current page and log pass/fail.

**Generated code (with auto-screenshot on failure):**
```typescript
// VERIFY_SOFT: Cart badge shows "2"
{
  const result = await inventoryPage.getCartBadgeCount();
  expect.soft(result).toBe(2);
  if (result !== 2) {
    const screenshot = await page.screenshot({ fullPage: true });
    await test.info().attach('VERIFY_SOFT-failed-cart-badge', { body: screenshot, contentType: 'image/png' });
  }
}

// For URL/page-level assertions:
// VERIFY_SOFT: URL contains "/dashboard"
{
  const url = page.url();
  expect.soft(url).toContain('/dashboard');
  if (!url.includes('/dashboard')) {
    const screenshot = await page.screenshot({ fullPage: true });
    await test.info().attach('VERIFY_SOFT-failed-url-dashboard', { body: screenshot, contentType: 'image/png' });
  }
}
```

The block scope `{ }` prevents variable name collisions when multiple VERIFY_SOFT steps appear in sequence. The screenshot attachment name should be descriptive: `VERIFY_SOFT-failed-{short-description}`. Each screenshot is bound to the currently running test — Playwright's HTML report shows it under that specific scenario.

**Behavior:** Unlike VERIFY (which stops the test on failure), VERIFY_SOFT logs the failure but **continues executing** the remaining steps. The test is still marked as failed in the report, but all subsequent steps run. Use this when you want to check multiple conditions and see all failures at once, rather than stopping at the first one.

**When to use VERIFY vs VERIFY_SOFT:**
- `VERIFY` — The remaining steps depend on this condition being true (e.g., verifying login succeeded before proceeding to checkout)
- `VERIFY_SOFT` — The remaining steps can run regardless (e.g., checking multiple field values on a summary page)

**Executor rule:** Same as VERIFY — if VERIFY_SOFT fails but the selector IS correct (element found, wrong content), flag as POTENTIAL BUG — do NOT change the expected value. Never convert VERIFY_SOFT to VERIFY or vice versa.

**Reviewer check:** VERIFY_SOFT steps must produce `expect.soft()` assertions. Verify that VERIFY_SOFT is not used for conditions that subsequent steps depend on.

---

## CAPTURE — Store Runtime Values

**Scenario:** `CAPTURE: Read subtotal as {{subtotal}}`

**Explorer action** (verify in browser) / **Builder action** (generate code): Read the specified value from the page and record it with the `{{variableName}}`.

**Generated code:**
```typescript
// CAPTURE variable MUST be declared with `let` in OUTER test scope (not inside test.step)
let subtotal: string;

// Inside test.step:
await test.step('Step 5 — CAPTURE: Read subtotal', async () => {
  subtotal = await checkoutPage.getSubtotal();
});
```

**MANDATORY:** CAPTURE variables MUST use `let` in the outer scope and be assigned inside `test.step()`. Using `const` inside the step makes the value inaccessible to subsequent steps. Page objects MUST have getter methods that return the captured value (e.g., `getSubtotal(): Promise<string>`).

---

## CALCULATE — Arithmetic on Captured Values

**Scenario:** `CALCULATE: {{expectedTotal}} = {{subtotal}} + {{tax}}`

**Explorer action** (verify in browser) / **Builder action** (generate code): Perform the math on captured values and record the result.

**Generated code:**
```typescript
// CALCULATE: {{expectedTotal}} = {{subtotal}} + {{tax}}
const expectedTotal = (parseFloat(subtotal.replace('$', '')) + parseFloat(tax.replace('$', ''))).toFixed(2);
```

---

## SCREENSHOT — Visual Evidence

**Scenario:** `SCREENSHOT: checkout-overview`

**Explorer action** (verify in browser) / **Builder action** (generate code): Take a visual screenshot and note the filename.

**Generated code:**
```typescript
// SCREENSHOT: checkout-overview
const screenshot = await page.screenshot({ fullPage: true });
await test.info().attach('checkout-overview', { body: screenshot, contentType: 'image/png' });
```

---

## REPORT — Console Output and Annotations

**Scenario:** `REPORT: Print subtotal, tax, total`

**Explorer action** (verify in browser) / **Builder action** (generate code): Note that this value should appear in test output — record it.

**Generated code:**
```typescript
// The step label with interpolated runtime value IS the primary report.
// Use template literals so the HTML report shows real data.
await test.step(`Step 8 — REPORT: Subtotal=${subtotal}, Tax=${tax}, Total=${total}`, async () => {
  test.info().annotations.push({ type: 'subtotal', description: subtotal });
  test.info().annotations.push({ type: 'tax', description: tax });
  test.info().annotations.push({ type: 'total', description: total });
});
```
**MANDATORY:** Generated specs contain no `console.log`; Playwright step titles provide step-level report visibility. Use annotations for REPORT metadata.

---

## SAVE — Persist Values Across Scenarios

**Scenario:** `SAVE: {{orderNumber}} to shared-state.json as "lastOrderNumber"`

**Explorer action** (verify in browser) / **Builder action** (generate code): Note that this value needs to be persisted — record the key name.

**Generated code:**
```typescript
// SAVE: Write {{orderNumber}} to shared-state.json as "lastOrderNumber"
import { saveState } from '../../core/shared-state';   // depth per §3a (add one ../ for foldered runs)
saveState('lastOrderNumber', orderNumber);
```

---

## DATASETS — Data-Driven Parameterized Tests

**Scenario:**
```markdown
## DATASETS
| username | password | expectedResult |
|----------|----------|----------------|
| standard_user | secret_sauce | success |
| locked_out_user | secret_sauce | error |
```

**Explorer action** (verify in browser) / **Builder action** (generate code): Execute only the FIRST data row. Note all rows for code generation.

**Generated code:**
```typescript
import testData from '../../test-data/web/login-datasets.json';   // depth + {type}/[{folder}/] per §3a

for (const data of testData) {
  test(`Login: ${data.username || '(empty)'} — expects ${data.expectedResult}`,
    { tag: ['@regression'] },
    async ({ page }) => {
      // Use data.username, data.password, etc.
  });
}
```

---

## SHARED_DATA — Load Reusable Reference Data

**Scenario:** `## SHARED_DATA: users, products`

**Generated code:**
```typescript
// SHARED_DATA: users, products
import { loadTestData } from '../../core/test-data-loader';
const testData = loadTestData('web/saucedemo-checkout', ['users', 'products']);
// testData merges shared/users.json + shared/products.json + web/saucedemo-checkout.json
```

**Reviewer check:** If `SHARED_DATA` keyword is used, spec must import `loadTestData` from `core/test-data-loader` (not direct JSON import).

---

## USE_HELPER — Call Team-Maintained Helper Methods

**Scenario:** `USE_HELPER: CartPage.calculateTotalPrice -> {{cartTotal}}`

**Generated code:**
```typescript
// USE_HELPER: CartPage.calculateTotalPrice -> {{cartTotal}}
const cartTotal = await cartPage.calculateTotalPrice();

// USE_HELPER: CartPage.validateAllCartPrices (no capture — just call it)
await cartPage.validateAllCartPrices();
```

**Format:** `USE_HELPER: PageName.methodName` or `USE_HELPER: PageName.methodName -> {{variable}}`

**Where USE_HELPER can appear:** Any section of a scenario — `## Steps`, `## Common Setup Once`, `## Common Setup`, `## Common Teardown`, `## Common Teardown Once`. The Builder maps it to the corresponding Playwright lifecycle hook or test body.

**HARD STOP:** If the helpers file does not exist or the method is not found:
- Do NOT create the helpers file
- Do NOT add the method to the base page object
- Emit a warning comment: `// WARNING: USE_HELPER requested CartPage.calculateTotalPrice but CartPage.helpers.ts not found`
- Mark the test step with `test.fixme('MISSING HELPER: CartPage.calculateTotalPrice')`

### `@steps` — DSL in Helper Functions (Explorer-Walkable Helpers)

Team-maintained helper functions can carry a **`@steps` JSDoc tag** containing scenario DSL — the same numbered steps and keywords used in scenario `.md` files. This makes helpers **transparent to the Explorer**: instead of treating `USE_HELPER` as an opaque black box, the Explorer reads the `@steps` block and walks each step in the live browser for **state advancement**.

**Why this matters:** Without `@steps`, a `USE_HELPER` that does state-changing work (login, form submission, navigation) leaves the application in the wrong state — the Explorer skipped the interactions, so everything after the helper call fails. With `@steps`, the Explorer performs every interaction, the app state advances correctly, and all subsequent steps succeed.

#### Format

```typescript
// SSOLoginPage.helpers.ts
import { Page } from '@playwright/test';

/**
 * @steps
 * 1. Navigate to {{ENV.BASE_URL}}
 * 2. Enter {{email}} in the email field on the Microsoft SSO login page
 * 3. Enter {{password}} in the password field
 * 4. Click the Sign In button
 * 5. Wait for the ServicerHome page to load
 * 6. VERIFY: ServicerHome page is loaded and the left navigation panel is visible
 */
export async function login(page: Page, email: string, password: string): Promise<void> {
  await page.goto(process.env.BASE_URL!);
  await page.fill('#loginfmt', email);
  await page.click('#idSIButton9');
  await page.fill('#passwordInput', password);
  await page.click('#submitButton');
  await page.waitForURL('**/ServicerHome/**');
}

/**
 * @steps
 * 1. Click "SMEs" on the left navigation panel
 * 2. VERIFY: The SME Insights page is loaded and the National Specialty widget is visible
 * 3. Wait for the data grid within the National Specialty widget to finish loading
 */
export async function navigateToNationalSpecialty(page: Page): Promise<void> {
  await page.click('a:has-text("SMEs")');
  await page.waitForSelector('[id="ProducerDataGrid2"]');
}
```

#### Rules

1. **`@steps` uses the same DSL as scenario files.** Numbered steps, same keywords (VERIFY, VERIFY_SOFT, CAPTURE, SCREENSHOT, etc.). The Explorer processes them identically to regular scenario steps.
2. **Explorer walks `@steps` for state advancement ONLY — no element capture, ever.** The helper code is human-written, so the Explorer does not need to discover selectors. It clicks, fills, navigates, and verifies — but does NOT produce ELEMENT annotations for helper steps. Selectors are the human engineer's responsibility.
3. **Exported functions WITH `@steps` → callable via `USE_HELPER`.** The Explorer reads and walks the steps; the Builder generates a function call.
4. **Exported functions WITHOUT `@steps` → internal utilities.** NOT callable via `USE_HELPER`. If a scenario references a function that has no `@steps` block, the Builder MUST emit the same hard-stop as a missing function: `// WARNING: USE_HELPER requested X but no @steps found` + `test.fixme('MISSING @steps: X')`.
5. **Non-exported functions** are invisible to the framework entirely.

#### CAPTURE in `@steps` — Return Values

When a helper's `@steps` block contains a CAPTURE keyword, it serves as a **specification** for what the function returns. At runtime, the human-written TypeScript function implements the capture logic and returns the value. The calling scenario captures it via the `-> {{variable}}` syntax.

**Single CAPTURE** → function returns a value directly:
```typescript
/**
 * @steps
 * 1. Click "Create User" button
 * 2. Fill in the user form with test data
 * 3. Click "Submit"
 * 4. Wait for success confirmation
 * 5. CAPTURE: the new user ID from the confirmation message as {{userId}}
 */
export async function createTestUser(page: Page, userData: UserData): Promise<string> {
  // ... implementation
  return userId;
}
```

Scenario: `USE_HELPER: UserManagementPage.createTestUser -> {{newUserId}}`
Builder generates: `const newUserId = await userManagementPage.createTestUser(page, userData);`

**Multiple CAPTUREs** → function returns an object:
```typescript
/**
 * @steps
 * 1. Place the order
 * 2. CAPTURE: order number as {{orderNumber}}
 * 3. CAPTURE: confirmation code as {{confirmationCode}}
 */
export async function placeOrder(page: Page): Promise<{ orderNumber: string; confirmationCode: string }> {
  // ... implementation
  return { orderNumber, confirmationCode };
}
```

Scenario: `USE_HELPER: CheckoutPage.placeOrder -> {{orderResult}}`
Subsequent steps use: `{{orderResult.orderNumber}}`, `{{orderResult.confirmationCode}}`

#### Drift Detection

The `@steps` block and the TypeScript implementation can drift if someone updates one but not the other. This is checked by `scripts/review-precheck.js` — see the script's `@steps` validation check. It verifies that every `USE_HELPER` reference in the spec points to a function that has a `@steps` block, and flags missing blocks as a precheck warning.

---

## Grid / Aggregate Verification Patterns — Natural-Language Phrasings for Common Helpers

**Why this section exists:** Some verification patterns (CSV-vs-grid match, "every value in column X is within range", "sum a column across pages", "find first row matching") are so common that writing them as raw `USE_HELPER:` blocks leaks the helper's API into the scenario file. The result is JavaScript-shaped pseudo-steps like `REPORT: {{result.mismatches.map(m => m.rowKey).join(', ')}}` that non-developer testers can't author or safely edit.

This section defines a small vocabulary of **natural-language patterns** that the Enricher and Builder recognize and translate into the right helper call automatically. The author writes intent in English; the Builder picks the helper, supplies the parameters, and auto-emits the diagnostic REPORT line.

### How the patterns work

Each pattern has:
- **NL phrasing** — exactly what the user writes in the scenario `.md` (single-quoted column names, literal disambiguating phrases like *"checking all pages"*, *"aligned by"*).
- **Helper mapping** — which helper the Builder calls + which return-field options.
- **Auto-emitted REPORT** — the Builder automatically generates a REPORT step after the VERIFY/CAPTURE, pulling identifying values from the helper's return shape. The author does NOT write `.map(...).join(...)` themselves.
- **Required parts** — fields the Builder will error on if missing (don't silently default).

The literal phrases are the disambiguating signals — Builder uses them to decide which pattern matched.

### Pattern 1 — Verify column values are within a date range

**NL phrasing** (write this in the scenario):

```
VERIFY: Use the team-owned helper DataGridColumnHelpers.verifyColumnDatesInRange to verify
every '<column-name>' value in the datagrid is within {{fromDateVar}} and {{toDateVar}}
(inclusive); align rows by '<key-column-name>', walking pagination if a control is present;
report any mismatches.
```

**Required parts:**
- **`Use the team-owned helper DataGridColumnHelpers.verifyColumnDatesInRange`** — explicit helper name (REQUIRED per the Enrichment agent's USE_HELPER rule — see Disambiguation rule 1 below)
- `Every '<col>' value` — column name in single quotes
- `in the datagrid` — literal phrase (distinguishes from CSV / other data sources)
- `is within {{from}} and {{to}}` — two date variables previously CAPTUREd
- `(inclusive)` — boundary semantic, literal
- `align rows by '<key-col>'` — single-quoted key column for mismatch identification
- `walking pagination if a control is present` — pagination signal (the helper passes `pageNumberCollector` either way; the phrase makes intent visible)
- `report any mismatches` — triggers Builder's auto-emitted REPORT step listing mismatched `<key-col>` values

**Builder generates:**
```typescript
const result = await verifyColumnDatesInRange(page, {
  columnName: '<col>',
  keyColumnName: '<key-col>',
  fromDate: <fromDateVar>,
  toDate: <toDateVar>,
  rowCollector: pageNumberCollector({ headersSelector: 'thead th', rowsSelector: 'tbody tr' }),
});
expect(result.ok).toBe(true);
// Auto-emitted REPORT step:
console.log(`Compared ${result.rowsCompared} rows; ${result.mismatches.length} mismatch(es); ` +
  `mismatched ${'<key-col>'}s: ${result.mismatches.map(m => m.rowKey).join(', ')}`);
```

**Soft variant:** use `VERIFY_SOFT:` instead of `VERIFY:`.

### Pattern 2 — Capture from the first row matching a predicate

**NL phrasing:**

```
CAPTURE: Use the team-owned helper DataGridColumnHelpers.captureFirstRowMatching to find
the first row in the datagrid where '<column>' is <predicate>; record '<col-a>' as {{varA}}
and '<col-b>' as {{varB}}, walking pagination if a control is present.
```

**Supported predicates (verbatim phrasing — Builder pattern-matches these exactly):**

| Predicate phrase | Matches |
|---|---|
| `a non-zero number` / `a non-zero numeric value` | `parseFloat(v.replace(/[$,]/g, '')) !== 0` |
| `non-empty` / `any non-empty text` | `v.trim() !== '' && v !== '--'` |
| `exactly equal to '<value>'` | `v.trim() === '<value>'` |
| `matching /<regex>/` | regex test (slash-delimited) |

**Required parts:**
- **`Use the team-owned helper DataGridColumnHelpers.captureFirstRowMatching`** — explicit helper name (REQUIRED per Disambiguation rule 1 below)
- `the first row in the datagrid where '<col>' is <predicate>` — predicate column + matcher
- `record '<col-a>' as {{varA}}` — capture pairs (1 or more, AND-joined)
- `walking pagination if a control is present` — pagination signal

**Builder generates:**
```typescript
const firstMatch = await captureFirstRowMatching(page, {
  predicateColumn: '<column>',
  matcher: <derived from predicate phrase>,
  captureColumns: ['<col-a>', '<col-b>'],
  rowCollector: pageNumberCollector({ headersSelector: 'thead th', rowsSelector: 'tbody tr' }),
});
const varA = firstMatch.cells['<col-a>'];
const varB = firstMatch.cells['<col-b>'];
```

### Pattern 3 — Sum a column across pages

**NL phrasing:**

```
CAPTURE: Use the team-owned helper DataGridColumnHelpers.sumColumnAcrossPages to sum all
'<column>' values across all pages of the datagrid as {{var}}.
```

**Required parts:**
- **`Use the team-owned helper DataGridColumnHelpers.sumColumnAcrossPages`** — explicit helper name (REQUIRED per Disambiguation rule 1 below)
- `sum all '<col>' values` — column name in single quotes
- `across all pages of the datagrid` — literal pagination signal
- `as {{var}}` — capture variable (the helper returns a `ColumnSumReport`; `var.sum` is the numeric total — use it as `{{var.sum}}` in any follow-up VERIFY)

**Builder generates:**
```typescript
const sumResult = await sumColumnAcrossPages(page, {
  columnName: '<column>',
  rowCollector: pageNumberCollector({ headersSelector: 'thead th', rowsSelector: 'tbody tr' }),
});
const var = sumResult.sum;  // numeric
```

When followed by `VERIFY_SOFT: {{var}} is exactly equal to {{otherVar}}`, the Builder emits `expect.soft(var).toBe(otherVar)` with auto-screenshot on failure.

### Pattern 4 — Verify exported CSV matches displayed grid

**NL phrasing:**

```
VERIFY: Use the team-owned helper DataGridCsvVerifier.verifyExportedCsvMatchesGrid to
compare the downloaded CSV against the datagrid row-for-row, aligned by '<key-column>'
(at least N rows must be compared, walking pagination if a control is present); report
any mismatches and rows present on only one side.
```

**Required parts:**
- **`Use the team-owned helper DataGridCsvVerifier.verifyExportedCsvMatchesGrid`** — explicit helper name (REQUIRED per Disambiguation rule 1 below)
- `compare the downloaded CSV against the datagrid row-for-row` — literal anchor phrase
- `aligned by '<key-col>'` — single-quoted key column
- `(at least N rows must be compared)` — `N` is a literal integer (becomes `minRowsCompared`)
- `walking pagination if a control is present` — pagination signal
- `report any mismatches and rows present on only one side` — auto-emits the REPORT with mismatch count + rowsInUiNotInCsv + rowsInCsvNotInUi

**Builder generates:**
```typescript
const csvResult = await verifyExportedCsvMatchesGrid(page, {
  csvPath: <captured downloadPath>,
  rowCollector: pageNumberCollector({ headersSelector: 'thead th', rowsSelector: 'tbody tr' }),
  ...testData.csvCompare,            // columnMap + ignore lists from JSON
  // minRowsCompared: N comes from "(at least N rows must be compared)"
});
expect(csvResult.ok).toBe(true);
// Auto-emitted REPORT:
console.log(`Compared ${csvResult.rowsCompared} datagrid rows against the CSV; ` +
  `${csvResult.mismatches.length} mismatch(es); ` +
  `${csvResult.rowsInUiNotInCsv.length} row(s) in UI not in CSV; ` +
  `${csvResult.rowsInCsvNotInUi.length} row(s) in CSV not in UI`);
```

The `columnMap` / `ignoreUiColumns` / `ignoreCsvColumns` / normalizers come from the scenario's test-data JSON `csvCompare` block — NOT inline in the scenario `.md`.

### Disambiguation rules — required for ALL patterns

1. **Enricher MUST preserve the full NL phrase verbatim in the structured Steps section.** Do NOT reduce a Grid/Aggregate Pattern step to bare `USE_HELPER: ClassName.methodName -> {{var}}` syntax. The full NL phrase carries the parameters Builder needs (column names, predicates, key columns) — bare USE_HELPER strips them. This is a documented EXCEPTION to the general USE_HELPER passthrough rule in the Enrichment agent, and the exception applies whenever a step's NL starts with the literal phrase `Use the team-owned helper <Class>.<method> to ...`. See the Enrichment agent (USE_HELPER exception for Grid/Aggregate Patterns) for the canonical statement.

   - ✅ Preserved (Enricher emits this as the structured Step):
     ```
     21. VERIFY: Use the team-owned helper DataGridColumnHelpers.verifyColumnDatesInRange to verify
         every 'Completion Time' value in the datagrid is within {{fromDate}} and {{toDate}} (inclusive);
         align rows by 'Load ID', walking pagination if a control is present; report any mismatches.
     ```
   - ❌ Reduced (parameters stripped — Builder cannot construct the helper call):
     ```
     21. USE_HELPER: DataGridColumnHelpers.verifyColumnDatesInRange
     ```

2. **Each pattern includes an EXPLICIT HELPER NAME** in the form `Use the team-owned helper <ClassName>.<methodName> to ...`. The Enricher's existing rule (the Enrichment agent's USE_HELPER passthrough) requires helper references to be explicit — the Enricher MUST NOT invent or guess helper names. Authors MUST include the helper name verbatim:
   - ✅ `Use the team-owned helper DataGridColumnHelpers.verifyColumnDatesInRange to ...`
   - ❌ `Use DataGridColumnHelpers.verifyColumnDatesInRange to ...` (missing "the team-owned helper")
   - ❌ `Verify ... using the helper to ...` (no class.method name)
   - ❌ `Verify ...` (no helper reference at all — Enricher will emit a flat scenario step; Builder will then generate a custom page-object method instead of using the framework helper, bypassing the convention entirely)

   The explicit naming is what triggers the Enricher to emit `USE_HELPER: ClassName.methodName -> {{var}}` in the structured `.md`. Without it, the Enricher correctly cannot guess which helper is intended, the framework helper is bypassed, and the resulting spec contains duplicated logic on page objects instead of helper calls. **This rule is non-negotiable — every pattern in this section MUST start with `Use the team-owned helper <Class>.<method> to`.**

3. **Column names MUST be single-quoted** in the NL — `'Start Date'`, `'Total($)'`. Double quotes, no quotes, or backticks are NOT recognized.
4. **The literal disambiguating phrases are required, verbatim** — `"in the datagrid"`, `"walking pagination if a control is present"` / `"walking pagination if present"` / `"across all pages of the datagrid"`, `"aligned by"`, `"report any mismatches"`. Substituting synonyms ("inside the grid", "for all pages", "matched on") will cause the Builder to fail to recognize the pattern.
5. **The integer N** in *"(at least N rows must be compared)"* is a literal whole number (`1`, `5`, `100`). No variables.
6. **REPORT is auto-emitted** — the author does NOT write a separate `REPORT:` step after a VERIFY using these patterns. The Builder emits it automatically based on the helper's return shape.
7. **Enricher MUST NOT add conditional qualifiers** to these patterns. *"Every X value …"* stays *"Every X value …"* — no *"if any rows exist"*, no *"when pagination is shown"*, no *"if the grid is non-empty"*. The patterns are unconditional by design; the helper itself raises clear errors (e.g., `InsufficientRowsError`) if the data is empty. (See the Enrichment agent's Faithful Translation Rule for the general principle.)
8. **`VERIFY_SOFT:` variants** are valid for patterns 1, 3, and 4 — same NL shape, soft assertion semantics.

### When to extend this section

Add a new pattern to this section ONLY when:
1. A new team-owned helper has been added to `output/pages/*.helpers.ts` AND
2. The pattern is expected to appear in 3+ scenarios (one-off helpers don't need their own NL pattern — they can use the raw `USE_HELPER:` syntax)

For one-off helpers used in a single scenario, raw `USE_HELPER: HelperName.methodName -> {{var}}` is fine. The patterns above exist only for high-frequency reuse cases where the API leakage was creating real authoring friction.

---

## Control Flow Keywords — Conditional Logic, Loops, and Error Handling

**These keywords apply to ALL scenario types (web, api, hybrid, mobile, mobile-hybrid).** They express runtime control flow that cannot be represented as flat sequential steps.

### Enricher MUST use these when the user writes:
- "if ... then ..." / "when ... appears" / "in case of" → **IF / IF_ELSE**
- "repeat" / "for each" / "do this for every" / "swipe through all" → **REPEAT_UNTIL / FOR_EACH**
- "do this N times" → **REPEAT_TIMES**
- "try ... if not found ..." / "attempt ... otherwise" → **TRY_ELSE**

### Enricher MUST NOT:
- Unroll loops into hardcoded repeated steps (e.g., expanding "swipe through all photos" into 5 identical swipe+screenshot steps)
- Assume a fixed iteration count unless the user explicitly states one
- Flatten conditionals into unconditional steps (e.g., converting "if popup appears, dismiss it" into "dismiss popup")

---

### IF / IF_ELSE — Conditional Execution

**Scenario writes:**
```markdown
15. IF: A notification popup appears ("Allow notifications")
    a. Tap "Not Now" to dismiss it
16. Continue with the main flow
```

**Or with ELSE:**
```markdown
15. IF: The "Add to Cart" button is visible
    a. Tap "Add to Cart"
    ELSE:
    a. Tap "Go to Cart" (item already added from previous run)
```

**Builder generates (web):**
```typescript
await test.step('Step 15 — Handle Add to Cart state', async () => {
  const addToCart = page.locator(loc.get('addToCartButton'));
  if (await addToCart.isVisible({ timeout: 3000 }).catch(() => false)) {
    await addToCart.click();
  } else {
    await page.locator(loc.get('goToCartButton')).click();
  }
});
```

**Builder generates (mobile):**
```typescript
// Step 15 — Handle Add to Cart state
if (await productScreen.isVisible('addToCartButton')) {
  await productScreen.tap('addToCartButton');
} else {
  await productScreen.tap('goToCartButton');
}
```

---

### REPEAT_UNTIL — Loop Until a Condition is Met

**Scenario writes:**
```markdown
20. REPEAT_UNTIL: No more photos in the carousel
    a. SCREENSHOT: product-photo-{index}
    b. Swipe left on the product photo carousel
```

**Or:**
```markdown
12. REPEAT_UNTIL: The "Load More" button is no longer visible
    a. Scroll down
    b. CAPTURE: Number of visible items
```

**Builder generates (web):**
```typescript
await test.step('Step 20 — Capture all product photos', async () => {
  let index = 1;
  const maxIterations = 20; // Safety limit
  while (index <= maxIterations) {
    const screenshot = await page.screenshot({ fullPage: false });
    await test.info().attach(`product-photo-${index}`, { body: screenshot, contentType: 'image/png' });
    // Try to swipe — if no more photos, the carousel won't change
    const beforeSrc = await page.locator(loc.get('carouselImage')).getAttribute('src');
    await page.locator(loc.get('carouselNextArrow')).click().catch(() => {});
    await page.waitForTimeout(500);
    const afterSrc = await page.locator(loc.get('carouselImage')).getAttribute('src');
    if (beforeSrc === afterSrc) break; // No more photos
    index++;
  }
});
```

**Builder generates (mobile):**
```typescript
// Step 20 — Capture all product photos
let photoIndex = 1;
const maxPhotos = 20; // Safety limit
while (photoIndex <= maxPhotos) {
  await productScreen.takeScreenshot(`product-photo-${photoIndex}`);
  const beforeDesc = await productScreen.getAttribute('productImage', 'content-desc');
  await productScreen.swipe('left');
  await browser.pause(500);
  const afterDesc = await productScreen.getAttribute('productImage', 'content-desc');
  if (beforeDesc === afterDesc) break; // No more photos
  photoIndex++;
}
```

**Rules:**
- **MUST include a safety limit** (`maxIterations`) to prevent infinite loops — default 20
- **MUST detect the termination condition** at runtime (element disappeared, content unchanged, counter reached)
- The `{index}` placeholder in step text is replaced by the loop counter in generated code

---

### REPEAT_TIMES — Fixed Count Loop

**Scenario writes:**
```markdown
8. REPEAT_TIMES: 3
    a. Tap the "Add" button to increase quantity
```

**Builder generates:**
```typescript
// Step 8 — Increase quantity 3 times
for (let i = 0; i < 3; i++) {
  await screen.tap('addButton');
  await browser.pause(300);
}
```

---

### FOR_EACH — Iterate Over a Collection of Elements

**Scenario writes:**
```markdown
10. FOR_EACH: Item in the search results list (first 5 items)
    a. VERIFY: Item has a price displayed
    b. VERIFY: Item has a product image
```

**Or:**
```markdown
7. FOR_EACH: Row in the data table
    a. CAPTURE: The value in column "Status"
    b. VERIFY: Status is not empty
```

**Builder generates (web):**
```typescript
await test.step('Step 10 — Verify search result items', async () => {
  const items = await page.locator(loc.get('searchResultItems')).all();
  const limit = Math.min(items.length, 5);
  for (let i = 0; i < limit; i++) {
    const item = items[i];
    expect(await item.locator(loc.get('itemPrice')).isVisible()).toBe(true);
    expect(await item.locator(loc.get('itemImage')).isVisible()).toBe(true);
  }
});
```

**Builder generates (mobile):**
```typescript
// Step 10 — Verify search result items
// Note: Mobile FOR_EACH uses scrolling to iterate — elements may not all be in view
for (let i = 0; i < 5; i++) {
  const priceVisible = await resultsScreen.isVisible('itemPrice');
  expect(priceVisible).toBe(true);
  await resultsScreen.swipe('up'); // Scroll to next item
  await browser.pause(500);
}
```

**Rules:**
- If the user specifies a limit ("first 5 items"), use it. Otherwise default to all items up to safety limit of 20.
- For mobile, elements may not all be accessible at once — use scroll+check pattern instead of `.all()`

---

### TRY_ELSE — Attempt With Fallback

**Scenario writes:**
```markdown
5. TRY: Tap the "Accept Cookies" banner
   ELSE: Continue (no cookie banner present)
```

**Or:**
```markdown
12. TRY: Find the search bar by accessibility ID
    ELSE: Tap the search area by coordinates (300, 348)
```

**Builder generates (web):**
```typescript
await test.step('Step 5 — Dismiss cookie banner if present', async () => {
  try {
    const banner = page.locator(loc.get('cookieAcceptButton'));
    if (await banner.isVisible({ timeout: 3000 }).catch(() => false)) {
      await banner.click();
    }
  } catch {
    // No cookie banner — continue
  }
});
```

**Builder generates (mobile):**
```typescript
// Step 12 — Find search bar with fallback
try {
  await homeScreen.tap('searchBar');
} catch {
  // FRAGILE: Search bar has rotating content-desc, fallback to coordinates
  await browser.action('pointer')
    .move({ duration: 0, origin: 'viewport', x: 300, y: 348 })
    .down({ button: 0 }).pause(100).up({ button: 0 }).perform();
}
```

**Rules:**
- TRY_ELSE is for **expected variability** — elements that may or may not be present
- DO NOT use TRY_ELSE for assertions — if a VERIFY fails, it should fail the test, not silently catch
- The ELSE branch MUST either continue normally or document why it's acceptable to skip

---

## File Download — Capture and Verify Downloaded Files

**Scenario:** `Click "Download Invoice" button` followed by `VERIFY: Invoice file is downloaded successfully to OS' default Downloads folder`

**Explorer action** (verify in browser) / **Builder action** (generate code): Use Playwright's download event API to capture the file. If the scenario specifies a download location (e.g., "OS' default Downloads folder"), use THAT location — do NOT substitute a project-local path.

**Generated code:**
```typescript
import * as os from 'os';
import * as fs from 'fs';
import * as path from 'path';

// Click download trigger and capture the download event
await test.step('Step N — Click "Download Invoice" button', async () => {
  const downloadPromise = page.waitForEvent('download');
  await orderPage.clickDownloadInvoice();
  const download = await downloadPromise;

  // Save to the location specified in the scenario
  // If scenario says "OS' default Downloads folder":
  const downloadsDir = path.join(os.homedir(), 'Downloads');
  const downloadPath = path.join(downloadsDir, download.suggestedFilename());
  await download.saveAs(downloadPath);

  // Store path for subsequent VERIFY steps
  test.info().annotations.push({ type: 'downloadPath', description: downloadPath });
});

// VERIFY: File downloaded
await test.step('Step N+1 — VERIFY: Invoice file is downloaded', async () => {
  const ann = test.info().annotations.find(a => a.type === 'downloadPath');
  const downloadPath = ann?.description ?? '';
  expect(fs.existsSync(downloadPath)).toBe(true);
});

// VERIFY: File content check
await test.step('Step N+2 — VERIFY: Invoice contains "John Doe"', async () => {
  const ann = test.info().annotations.find(a => a.type === 'downloadPath');
  const downloadPath = ann?.description ?? '';
  const content = fs.readFileSync(downloadPath, 'utf-8');
  expect(content).toContain('John Doe');
});
```

**MANDATORY Rules:**
- `acceptDownloads: true` MUST be set in `playwright.config.ts` (under `use:`)
- Use `page.waitForEvent('download')` BEFORE the click that triggers the download
- **If the scenario specifies a download location, use it literally.** "OS' default Downloads folder" → `path.join(os.homedir(), 'Downloads')`. "project downloads folder" → `path.join(process.cwd(), 'downloads')`. Do NOT substitute your own path.
- If the scenario does NOT specify a location, default to `path.join(process.cwd(), 'downloads')` and create the directory if it doesn't exist
- Store the download path via `test.info().annotations` so subsequent VERIFY steps can access it

---

## Tags — CI/CD Filtering Labels

**Scenario:** `**Tags:** smoke, cart, P0`

**Generated code:**
```typescript
test('scenario name', { tag: ['@smoke', '@cart', '@P0'] }, async ({ page }) => { ... });
```

**MANDATORY:** Tags MUST have `@` prefix in generated code. Every test MUST have tags. DO NOT generate tests without tags.

---

## API Steps — REST API Calls

**Scenario:** `API POST: /api/users with body {"name": "John"}`

**Generated code:**
```typescript
const response = await request.post('/api/users', {
  data: { name: 'John' },
});
expect(response.status()).toBe(201);
const body = await response.json();
```

**MANDATORY Rules:**
- MUST use Playwright's `request` fixture exclusively — NEVER use `fetch` or `axios`
- For `api` type: destructure `{ request }` only
- For `hybrid` type: always destructure both `{ page, request }` — API steps are interleaved with UI steps
- For `web` type with ad-hoc API steps: destructure both `{ page, request }`
- Auth headers from environment variables: `Authorization: \`Bearer ${process.env.API_TOKEN}\``

---

## ENV_VARS — Environment Variable References

**Scenario:** `Navigate to {{ENV.BASE_URL}}`

**Generated code:**
```typescript
process.env.BASE_URL
```

**MANDATORY:** ALL `{{ENV.VARIABLE}}` references MUST become `process.env.VARIABLE`. NEVER hardcode credentials, URLs, or secrets.

---

## API Behavior — Mock vs Live Declaration

**Scenario header:** `## API Behavior: mock` or `## API Behavior: live`

- `mock` — API is non-persistent. Explorer or Executor may adapt tests for non-persistence (use existing IDs, accept mock responses).
- `live` or missing — API is real. All persistence/assertion guardrails apply with ZERO exceptions.
- NEVER infer API behavior from the URL or API name. ONLY the explicit `## API Behavior` header controls this. This is NON-NEGOTIABLE.

---

---

## Multi-Assertion VERIFY

## 5. Multi-Assertion VERIFY — Nested test.step Pattern

When a single VERIFY step checks multiple sub-assertions (e.g., "VERIFY: Order summary shows correct subtotal, tax, and total"), **MUST** use nested `test.step()` for each sub-assertion. This makes the HTML report pinpoint exactly which field failed:

```typescript
await test.step('Step 10 — VERIFY: Order summary is correct', async () => {
  await test.step('Verify subtotal', async () => {
    expect(await summaryPage.getSubtotal()).toBe(expectedSubtotal);
  });
  await test.step('Verify tax', async () => {
    expect(await summaryPage.getTax()).toBe(expectedTax);
  });
  await test.step('Verify total', async () => {
    expect(await summaryPage.getTotal()).toBe(expectedTotal);
  });
});
```

**Why:** Without nesting, a single `test.step` with 3 `expect()` calls shows "Step 10 failed" but doesn't say WHICH assertion. With nesting, the report shows "Step 10 > Verify tax — failed."

---

---

## Conditional Steps — code generation

## 9. Conditional Steps ("If...Then")

When a scenario step contains a condition (e.g., "If pagination exists, navigate to page 2"):

### During Exploration
1. Check the condition in the live browser (e.g., is pagination visible?)
2. If the condition is TRUE → explore and verify the action, write both the condition check AND the action
3. If the condition is FALSE → write the condition check code that SKIPS the action. Note in the explorer report that the condition was false during exploration

### Code Pattern — MANDATORY
```typescript
await test.step('Step 11 — If pagination exists, navigate to page 2', async () => {
  const hasPagination = await page.locator('[data-testid="pagination"]').isVisible().catch(() => false);
  if (hasPagination) {
    await page.locator('[data-testid="page-2"]').click();
    await page.waitForLoadState('networkidle');
  } else {
    console.log('Pagination not present — skipping page 2 navigation');
  }
});
```

**Rules:**
- **MUST** use `.isVisible().catch(() => false)` for existence checks — handles element not in DOM
- **MUST** wrap the entire condition + action in ONE `test.step()` — the conditional IS the step
- **MUST NOT** skip the step entirely if condition is false — the step exists, it just takes the "else" path
- **MUST NOT** use `test.fixme()` for false conditions — the step executed correctly, the condition was simply false
- For VERIFY after conditional action: assert ONLY if the action was taken:
  ```typescript
  await test.step('Step 12 — VERIFY: Page 2 shows Sports results', async () => {
    if (hasPagination) {
      const results = await gridPage.getAllSpecialties();
      expect(results.every(r => r.includes('Sports'))).toBe(true);
    } else {
      console.log('Pagination not present — VERIFY skipped (condition was false)');
    }
  });
  ```

---

---

## API CRUD Chain

## 10. API CRUD Chain Pattern

For create-read-update-delete sequences:

```typescript
let resourceId: string;

await test.step('Step 1 — API POST: Create user', async () => {
  const response = await request.post(`${process.env.API_BASE_URL}/users`, {
    data: { name: 'Test User' }
  });
  expect(response.status()).toBe(201);
  const body = await response.json();
  resourceId = body.id;
});

await test.step('Step 2 — API GET: Verify user exists', async () => {
  const response = await request.get(`${process.env.API_BASE_URL}/users/${resourceId}`);
  expect(response.status()).toBe(200);
});

await test.step('Step 3 — API DELETE: Remove user', async () => {
  const response = await request.delete(`${process.env.API_BASE_URL}/users/${resourceId}`);
  expect(response.status()).toBe(200);
});
```

**CRUD Persistence Guardrail — MANDATORY unless `## API Behavior: mock`:**
- POST returns 2xx → subsequent GET MUST find the resource. If GET returns 404 → `test.fixme('POTENTIAL BUG: POST returned 201 but resource not found')`
- PUT returns 2xx → subsequent GET MUST show updated values
- DELETE returns 2xx → subsequent GET MUST return 404

---

---

## Comment Conventions (FRAGILE / PACING)

## 8. Comment Conventions — FRAGILE and PACING

### `// FRAGILE:` Convention

Mark selectors or code paths that use fragile strategies (page.evaluate text-walkers, inferred selectors without data-testid, deep CSS paths) with a `// FRAGILE:` comment:

```typescript
// FRAGILE: No data-testid on this element — uses text content which may change with i18n
async getStatusText(): Promise<string> {
  return await this.page.locator('.status-container > span:first-child').textContent() ?? '';
}

// FRAGILE: Uses page.evaluate to walk DOM text nodes — breaks if DOM structure changes
async getCellValue(row: number, col: number): Promise<string> {
  return await this.page.evaluate(([r, c]) => {
    const cell = document.querySelectorAll('table tbody tr')[r]?.querySelectorAll('td')[c];
    return cell?.textContent?.trim() ?? '';
  }, [row, col]);
}
```

**The `// FRAGILE:` comment signals to the Reviewer (Dim 1) and humans that this code needs attention.** It is NOT a failure — sometimes fragile is the only option. But it MUST be documented.

### `// PACING:` Convention (recap)

Already documented in quality-gates.md — protects justified `waitForTimeout` calls from Reviewer removal.

---

---

## Lifecycle Hook Rules

## 15. Lifecycle Hook Rules — HARD STOP

### beforeAll / afterAll — `{ browser }` ONLY

**NEVER use `{ page }` or `{ request }` in beforeAll/afterAll. This is a Playwright constraint.**

```typescript
test.beforeAll(async ({ browser }) => {
  const page = await browser.newPage();
  // ... setup steps ...
  await page.close();
});
```

For API calls in beforeAll:
```typescript
const { request: playwrightRequest } = require('@playwright/test');
test.beforeAll(async ({ browser }) => {
  const ctx = await playwrightRequest.newContext();
  // ... API steps ...
  await ctx.dispose();
});
```

### beforeEach / afterEach — per type fixture

| Type | Fixture |
|------|---------|
| web | `{ page }` |
| api | `{ request }` |
| hybrid | `{ page, request }` |

### Step Labels in Lifecycle Hooks

**MUST use semantic prefixes, NOT step numbers:**
```typescript
await test.step('[Setup] Navigate to app', async () => { ... });
await test.step('[Before Each] Login', async () => { ... });
await test.step('[After Each] Clear cart', async () => { ... });
await test.step('[After All] Cleanup data', async () => { ... });
```

Main scenario steps use sequential numbers: `Step 1`, `Step 2`, etc.

---

---

## Step Completeness Rule

## Step Completeness Rule — MANDATORY

**For web/api/hybrid:** Every source step MUST produce exactly one ordered scenario-step descriptor and one Playwright `test.step()` report entry. Prefer a typed descriptor list executed sequentially with `for...of`; use direct `test.step()` only when control flow or variable scoping requires it. NEVER combine, merge, or skip steps. Generated specs MUST NOT contain `console.log`.

**For mobile/mobile-hybrid:** Every step MUST produce a `// Step N — [description]` comment marker (no `test.step()` in WDIO/Mocha) followed immediately by a `console.log` with timestamp and step label: `` console.log(`[${new Date().toISOString()}] Step N — {description}`) ``. Count comment markers vs source steps — they **MUST match exactly**.

After writing the spec, count step descriptors/direct scenario-step labels vs source steps — they **MUST match exactly**. Each descriptor must be executed exactly once.

**Step numbering is positional, not user-authored.** The user's step numbers in the scenario .md file may be incorrect, duplicated, out of order, or missing. Do NOT rely on them. Instead:
- Read the scenario top-to-bottom
- Assign sequential numbers by position: the first step encountered is STEP 1, the second is STEP 2, etc.
- Number continuously across all sections: Common Setup Once steps first, then Common Setup, then Scenario steps, then Common Teardown, then Common Teardown Once
- The `test.step('Step N — ...')` in the generated spec uses these positional numbers, NOT the user's original numbers
- The total count of scenario-step descriptors plus direct scenario `test.step()` entries must equal the total count of steps encountered positionally; do not count the shared loop's single `test.step()` call as one scenario step
- Lifecycle hook steps use semantic prefixes (`[Setup]`, `[Before Each]`, etc.) — NOT step numbers

---

