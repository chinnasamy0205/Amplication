---
name: review-dimensions
description: The Reviewer's 9 enterprise QE quality dimensions — the scoring rubric (checklists, 1-5 scoring bands, and type-applicability) for Locator Quality, Wait Strategy, Test Architecture, Configuration, Code Quality, Maintainability, Security, API Quality, and Scenario-to-Code Fidelity (the HARD GATE). One dimension per section; each lists the files to examine and what to score.
version: "1.0"
---

# Review Dimensions — Scoring Rubric

The Reviewer scores generated test code against these 9 dimensions and merges them into the scorecard. Each dimension states which types it applies to (mark **N/A** and reduce the denominator when it doesn't apply). **Dimension 9 (Fidelity) is the hard gate.** Section numbers and content are preserved verbatim from the source rubric for internal cross-reference.

---

## Dimension 1: Locator Quality (Weight: High)

**Applies to:** web, hybrid, mobile, mobile-hybrid. **N/A for:** api.

### Files to Examine
- All `output/locators/*.locators.json` from the explorer report manifest
- All `output/pages/*Page.ts` from the manifest
- For mobile: `output/locators/mobile/*.locators.json` and `output/screens/*Screen.ts`

### Checklist — MUST score each item

- [ ] Every element has a primary selector + at least 2 fallbacks in JSON
- [ ] Every element has a `type` field (`input`|`button`|`link`|`select`|`checkbox`)
- [ ] Primary locators follow priority: `role=` > `label=` > `testid=` > `id` > `name` > `text=` > CSS. Flag if CSS class is used as primary when semantic alternatives exist
- [ ] Fallbacks are CSS-based (work without prefix resolution)
- [ ] No fragile selectors: no `nth-child`, no deep CSS paths, no auto-generated IDs (like `ctl00_*`)
- [ ] **Fallbacks are STRUCTURAL, never scenario data** — no fallback embeds a record name, silo/org name, order number, username, date, status, or any value sourced from the scenario's test-data or a CAPTURE. A data-baked fallback (e.g., `tr:has-text('Automation_Silo')` as a fallback) passes once then mis-resolves when data changes — flag it. (Primary MAY carry a runtime value if the Explorer located the element that way live; fallbacks may not. See the `web-codegen-locators` skill — "Fallbacks MUST be STRUCTURAL".)
- [ ] No hardcoded selectors in page objects or test files — ALL selectors go through `LocatorLoader` / `this.loc.get()`
- [ ] Selector naming is descriptive camelCase (`submitButton`, not `btn1` or `element3`)
- [ ] For mobile: primary selectors prefer `accessibility_id` > `id` > class chain/predicate. No index-based XPath

### Scoring
- **5/5** — Every element has primary + 2 fallbacks, all stable strategies, zero raw selectors
- **4/5** — 1-2 elements missing a fallback, or 1 fragile selector strategy
- **3/5** — Some elements have only primary (no fallbacks), or CSS class-based primaries
- **2/5** — Multiple raw selectors in page objects, or fragile selectors throughout
- **1/5** — No JSON externalization, selectors hardcoded everywhere

**Score: _/5**

> Locator-quality reference: the `web-codegen-locators` skill defines the locator JSON format + selector priority the Builder follows.

---

## Dimension 2: Wait Strategy (Weight: High)

**Applies to:** ALL types.

### Files to Examine
- Page objects from manifest (`output/pages/*Page.ts`)
- Spec file (`output/tests/{type}/*.spec.ts`)

### Checklist — MUST score each item

- [ ] Navigation actions followed by `waitForLoadState`, `waitForURL`, or an explicit landmark wait
- [ ] Form submissions followed by response/navigation waits
- [ ] Dynamic content uses `waitForSelector` / `waitFor({state:...})` with explicit state
- [ ] No unjustified `waitForTimeout` or `setTimeout` calls
- [ ] **Visibility-check discipline — MANDATORY (see the `web-codegen-pageobject` skill, bounded-wait visibility):**
  - [ ] Page-object methods whose name starts with `is` and ends with `Visible` (or `Hidden`) MUST wrap a bounded `locator.waitFor({state, timeout})` in try/catch. Bare `return await locator.isVisible()` (instant-false snapshot) is a Dim 2 critical finding.
  - [ ] Spec-level VERIFY / VERIFY_SOFT checks call a semantic page-object assertion method; the page object owns the cached locator and uses a retrying assertion/shared state helper with a bounded timeout.
  - [ ] Bare `locator.isVisible()` is permitted ONLY with `.catch(() => false)` for optional-element existence gates (e.g., cookie banner dismissal) AND only with an explicit short `{ timeout }` option.
- [ ] **Pacing hierarchy (see the `web-pacing` skill):** prefer `waitForURL` / landmark `waitFor({state:'visible'})` / `waitForResponse` over `waitForLoadState('networkidle')`. `networkidle` on apps with analytics/websockets frequently times out — flag unexplained `networkidle` waits on apps whose enriched.md `## App Behavior:` signal is `spa-async` or `hybrid-hydration`.

**`waitForTimeout` exception — do NOT flag a call if BOTH are true:**
1. The call has a `// PACING:` comment explaining why the delay is needed
2. The application is documented as slow in `scenarios/app-contexts/` OR the comment references app speed, a complex UI component, or a dynamic content wait

**Removing justified pacing waits causes regressions.** Flag ONLY unjustified waits (no `// PACING:` comment, no app-context evidence).

**BasePage primitives available (when present in the project's base-page.ts):** `waitForReady(key, timeoutMs?)` and `isReady(key, timeoutMs?)` are the recommended primitives. If the project's BasePage exposes them, prefer those calls over inline `page.locator(...).waitFor(...)` in page objects — they centralize the timeout default and keep page-object code terse.

### Scoring
- **5/5** — Every navigation/interaction has appropriate waits, zero unjustified delays
- **4/5** — 1-2 missing waits after navigation, but no unjustified delays
- **3/5** — Several missing waits, or 1 unjustified waitForTimeout
- **2/5** — Multiple unjustified delays, missing waits cause likely race conditions
- **1/5** — No wait strategy at all, or pervasive waitForTimeout usage

**Score: _/5**

---

## Dimension 3: Test Architecture (Weight: Medium)

**Applies to:** ALL types.

### Files to Examine
- Spec file, page objects, test data files, helper files (if any) from manifest

### Checklist — MUST score each item

- [ ] Page Object Model properly implemented (web/hybrid) or Screen Object Model (mobile)
- [ ] Test files import page/screen objects — no direct Playwright/WDIO API in tests
- [ ] Specs do not reference locator keys via `getLocator('key')` for assertions; they call semantic methods on the owning page object
- [ ] Linear web/api/hybrid flows use ordered step descriptors executed sequentially with `for...of`; every step still appears individually in the Playwright report
- [ ] Generated specs contain no `console.log`; `test.step` titles provide step reporting
- [ ] Test data externalized to JSON — no hardcoded values in specs
- [ ] Multi-scenario files use `test.describe()` with `test.beforeEach()` for common setup
- [ ] DATASETS produce parameterized `for...of` loops, not duplicated test code
- [ ] VERIFY steps produce `expect()` assertions inline, not batched at the end
- [ ] Tags formatted correctly: `{ tag: ['@tagName'] }` with `@` prefix
- [ ] If `output/test-data/shared/` exists: scenario JSONs do not duplicate values already in shared files
- [ ] If `SHARED_DATA` keyword used: spec imports `loadTestData` from `core/test-data-loader` (not direct JSON import)
- [ ] If `*.helpers.ts` exists for a page: spec imports the helpers class (`{PageName}WithHelpers as {PageName}`), not the base class
- [ ] If `USE_HELPER` keyword used: verify the referenced method exists in the helpers file and the spec calls it

### Scoring
- **5/5** — Clean POM, all data externalized, correct imports, correct patterns
- **4/5** — 1-2 minor issues (e.g., one hardcoded value, one missing helper import)
- **3/5** — Some direct API usage in tests, or test data partially hardcoded
- **2/5** — No page objects, or significant hardcoded data
- **1/5** — No architecture pattern at all

**Score: _/5**

---

## Dimension 4: Configuration (Weight: Medium)

**Applies to:** ALL types. For mobile: check WDIO config instead of playwright.config.

### Files to Examine
- `output/playwright.config.ts` (web/api/hybrid)
- WDIO config (mobile) — if applicable

### Checklist — MUST score each item

- [ ] `channel: 'chrome'` (not `browserName: 'chrome'`)
- [ ] Timeouts configured (action, navigation)
- [ ] Screenshot on failure enabled (`screenshot: 'only-on-failure'`)
- [ ] Trace collection configured (`trace: 'retain-on-failure'` or `'on-first-retry'`)
- [ ] Video configured (`video: 'retain-on-failure'`)
- [ ] baseURL set correctly (reads from `process.env.BASE_URL`)

### Scoring
- **5/5** — All config items correct and present
- **4/5** — 1 missing config item
- **3/5** — 2-3 missing items, or incorrect channel setting
- **2/5** — Most config items missing or incorrect
- **1/5** — No meaningful configuration

**Score: _/5**

---

## Dimension 5: Code Quality (Weight: Low)

**Applies to:** ALL types.

**EXCLUDED from scope:** `output/tools/` — do not flag patterns in operational utilities.

### Files to Examine
- Spec file and page objects from manifest

### Checklist — MUST score each item

- [ ] Consistent TypeScript — no mixed JS/TS
- [ ] No `any` types where avoidable
- [ ] Meaningful variable and method names
- [ ] JSDoc on page object public methods
- [ ] No unused imports
- [ ] Every async method call uses `await` — missing await = silent failure
- [ ] `@types/node` listed in devDependencies
- [ ] `dotenv` listed in devDependencies
- [ ] **No undocumented literal returns in page-object methods.** A page-object method that claims to compute a value (`getCount`, `findName`, `computeX`) MUST NOT return a hardcoded literal (`return 1;`, `return 'OK';`) as a fallback path. Allowed ONLY when preceded by an inline `// SENTINEL: [meaning]` comment that documents the value as a sentinel (e.g., `// SENTINEL: -1 means heading not found — caller must handle`). Silent literal fallbacks pass tests even when the underlying state is wrong.

  **Grep signal:** inside `output/pages/*.ts`, any `return <number-literal>;` / `return '<string-literal>';` on a line NOT preceded by a `// SENTINEL:` comment within 2 lines above is a violation.

  **Example violation** (from observed run): `return 1;` in a course-count fallback path returns `1` regardless of actual visible count, silently satisfying `expect(count).toBe(1)`.

### Scoring
- **5/5** — Clean TypeScript, no `any`, all async calls awaited, good naming
- **4/5** — 1-2 minor issues (missing JSDoc, one unused import)
- **3/5** — Some `any` types, missing awaits, or poor naming
- **2/5** — Pervasive `any`, multiple missing awaits
- **1/5** — JavaScript mixed with TypeScript, major quality issues

**Score: _/5**

---

## Dimension 6: Maintainability (Weight: Medium)

**Applies to:** ALL types.

### Files to Examine
- Page objects, helper files, locator JSONs from manifest

### Checklist — MUST score each item

- [ ] Adding a new page requires only: new locator JSON + new page object + new spec
- [ ] Changing a selector requires editing only the locator JSON file
- [ ] Test data changes require no code changes
- [ ] Framework core (locator-loader, base-page, test-data-loader) is generic and reusable
- [ ] Shared reference data (users, products) lives in `output/test-data/shared/`, not duplicated per scenario
- [ ] If team-maintained `*.helpers.ts` files exist: they follow the convention (`{PageName}WithHelpers extends {PageName}`, JSDoc with `@scenario-triggers`, `@helpers` tag on class)
- [ ] Custom helper logic is in `*.helpers.ts` files, not mixed into Explorer/Builder-generated page objects
- [ ] **No scenario-specific string literals in page-object methods.** A string literal used inside a page-object method's `getByRole({ name: 'X' })`, `getByText('X')`, `.filter({ hasText: 'X' })`, or `.includes('X')` call is ALLOWED only when `'X'` appears in the SAME page's locator JSON (as part of a captured primary/fallback selector). If `'X'` is scenario-specific data (a product name, a user name, an expected value unique to one scenario), it MUST be a method parameter sourced from test-data — NOT a literal baked into the page object.

  **Rationale:** hardcoded scenario data in a page object couples the page object to one scenario's test data. A second scenario reusing the same page object with different data silently misbehaves.

  **Allowed (page's own identity, reinforced by locator JSON):**
  ```ts
  // "Log In" captured in login-page.locators.json's loginButton
  await this.page.getByRole('button', { name: 'Log In' }).click();
  ```

  **Not allowed (scenario-specific data):**
  ```ts
  // Product name is test-data for ONE scenario — must be a parameter
  await this.page.getByRole('checkbox', { name: 'Premium Widget Pack 3.0' });
  ```

  **Fix pattern:** accept the string as a parameter (`async selectProduct(productName: string)`) and source from `testData.expectedProduct` in the spec.

  **Grep signal:** string literals in `output/pages/*.ts` that do NOT appear in the page's matching `output/locators/*-page.locators.json`. Framework constants (timeout values, framework error messages, debug log prefixes) are exempt.

### Scoring
- **5/5** — Clean separation, single point of change for selectors/data, proper helper pattern
- **4/5** — 1-2 minor coupling issues
- **3/5** — Some selectors duplicated across files, or data partially hardcoded
- **2/5** — Tight coupling between tests and page objects, changes ripple across files
- **1/5** — Monolithic spec with no separation of concerns

**Score: _/5**

---

## Dimension 7: Security (Weight: High)

**Applies to:** ALL types.

### Files to Examine
- Spec file from manifest
- `output/.env.example` (informational only — see "Out of Scope" below)
- `.gitignore`
- Page object files (for hardcoded credential strings)

### Checklist — MUST score each item

- [ ] No passwords, tokens, or secrets hardcoded anywhere in code
- [ ] All credentials use `process.env.VARIABLE_NAME`
- [ ] `.gitignore` includes `.env`
- [ ] Scenario `.md` files use `{{ENV.VARIABLE}}` pattern, not real values
- [ ] Storage state files (`output/auth/*.json`) are gitignored (contain auth tokens)

### Out of Scope — `.env.example` Completeness

**Per the `quality-gates` knowledge §2b, the completeness of `output/.env.example` is NOT a scored item in this dimension.**

`.env.example` is a developer-onboarding template (analogous to `.vscode/mcp.example.json`) — it is NOT a runtime dependency. Tests read `.env`, not `.env.example`. The scenario `.md` `## Application` section is the authoritative source for which env vars a scenario uses.

- **MUST NOT** dock Dimension 7 score for missing `LM_URL`, `BASE_URL`, or any other `process.env.X` reference being absent from `.env.example`.
- **MAY** add a Recommendation (nice-to-have) line noting that the next developer setting up the project may benefit from a placeholder entry — but ONLY if the project explicitly designates `.env.example` as its onboarding contract.
- **MUST NOT** raise this as a Critical Issue under any circumstance.
- Real credentials APPEARING in `.env.example` IS still a Critical Issue (that's a leak) — score it under "hardcoded secrets" instead.

### Scoring
- **5/5** — Zero hardcoded secrets, all env vars properly referenced, gitignore complete
- **4/5** — 1 minor issue (e.g., one storage state file accidentally tracked, or scenario `.md` contains a literal credential value)
- **3/5** — 1 hardcoded value that should be env var, or `.env` not gitignored
- **2/5** — Multiple hardcoded credentials or missing security config
- **1/5** — Real credentials in committed code

**Score: _/5**

---

## Dimension 8: API Test Quality (Weight: Medium)

**Applies to:** api, hybrid, mobile-hybrid. **N/A for:** web, mobile (pure native).

### Files to Examine
- Spec file and scenario `.md` from manifest

### Checklist — MUST score each item

- [ ] Uses Playwright's built-in `request` fixture (not axios/fetch)
- [ ] For hybrid: `{ page, request }` correctly destructured in test fixture
- [ ] API auth headers use `process.env.API_TOKEN` (not hardcoded)
- [ ] Response status assertions present for every API call
- [ ] Response body structure verified (not just status code)
- [ ] API chaining properly passes values between requests (CAPTURE → subsequent steps)
- [ ] CAPTURE steps on API responses correctly use property access (`body.id`, `body.data[0].name`)
- [ ] For hybrid: API assertions AND UI assertions are both present where scenario requires cross-channel verification
- [ ] If `## API Behavior: mock` declared: spec does NOT assert CRUD persistence (POST→GET chain relaxed)
- [ ] If `## API Behavior: live` or missing: spec DOES assert CRUD persistence where applicable

### Scoring
- **5/5** — All API calls have status + body assertions, proper chaining, correct fixture, mock/live respected
- **4/5** — 1-2 API calls missing body structure verification
- **3/5** — Some missing status assertions, or incorrect fixture for hybrid
- **2/5** — Using fetch/axios, or missing most assertions
- **1/5** — No API quality patterns at all

**Score: _/5**

---

## Dimension 9: Scenario-to-Code Fidelity (Weight: HIGH — Most Important)

**Applies to:** ALL types. This is the HARD GATE for approval.

**This dimension verifies that the generated spec is a faithful, complete, and exact translation of the source scenario.** Every step, every assertion, and every keyword MUST have corresponding code that does exactly what the scenario describes. No omissions. No approximations. No silent failures.

### Files to Examine
- Source scenario `.md` file
- Generated spec file
- Keyword → code patterns (the `web-codegen-spec` skill — for correct code patterns)
- Explorer report (for step results, blocked steps)
- Executor report (for test pass/fail status)

### 9a. Step Completeness — MANDATORY

**Step numbering is positional** — count by position, not user's numbers.

- [ ] Count every step in the source scenario by position (ALL sections: Setup Once, Setup, Steps, Teardown, Teardown Once)
- [ ] Count every `Step N — ...` descriptor plus direct scenario `test.step()` entries; do not count a shared loop's single `test.step()` invocation as one step
- [ ] **Counts MUST match exactly** — any mismatch is an automatic FAIL. `test.fixme()` steps COUNT as present (blocked but documented). Record: `Blocked steps (test.fixme): [N]`
- [ ] Every step is represented by exactly one ordered descriptor executed as one `test.step()` report entry, or by one direct `test.step()` when control flow/scoping requires it — missing entries are a FAIL
- [ ] `test.step()` numbers are sequential (1, 2, 3...) — not user's original numbers
- [ ] Steps in correct sequence — no reordering
- [ ] Step labels match original intent — no meaning-changing paraphrases
- [ ] Template variables in labels use string interpolation (runtime values) — not placeholder names
- [ ] Multi-assertion VERIFY blocks use nested `test.step()` for each sub-assertion
- [ ] Do not flag data-driven sequential step descriptors as missing `test.step()` calls when each descriptor is run through `await test.step(step.title, step.action)`
- [ ] **Do NOT flag** a VERIFY_SOFT step showing pass when the soft assertion failed — expected Playwright behavior

### 9b. Plain Action Steps

- [ ] Every navigation step produces `page.goto()` or navigation click + wait
- [ ] Every click step produces a click on the correct element via page object
- [ ] Every fill/type step produces a fill with the correct value
- [ ] The code for each step performs the EXACT action described — not a different or simplified action

### 9c. Assertion Fidelity

- [ ] Every UI VERIFY → a semantic assertion method on the owning page object, invoked in the corresponding scenario step; API VERIFY retains status/body assertions in the API step
- [ ] Every UI VERIFY_SOFT → `expect.soft()` behavior in the owning page-object assertion method or an explicitly designed soft-assert helper, with auto-screenshot on failure
- [ ] No VERIFY converted to VERIFY_SOFT or vice versa — NEVER
- [ ] Expected values match scenario verbatim — no weakened, generalized, or approximated assertions
- [ ] Assertions at same position in test flow as in scenario — not batched at end
- [ ] Count and trace VERIFY/VERIFY_SOFT scenario steps to their invoked assertion methods; do not require UI `expect()` calls to appear textually in the spec

### 9c-alpha. Scenario-Locked Test Data — MANDATORY (Guardrail)

The Executor MUST NOT silently change a test-data JSON value that is stated verbatim in the scenario's `## Test Data` table. Such changes hide real POTENTIAL BUGs — the correct response is `test.fixme('POTENTIAL BUG: ...')` with a `test.info().annotations.push({ type: 'potentialBug', ... })`. (This is the same rule the Executor follows — see the `fix-discipline` knowledge §4.)

- [ ] Read precheck evidence `dim9_fidelity.testDataDivergence`. For every divergence entry where `hasFixmeAnnotation === false`: **CRITICAL — cap Dim 9 at 3/5 and cite in findings.** The spec must preserve the scenario value and annotate the divergence, not mutate the JSON.
- [ ] For divergence entries where `hasFixmeAnnotation === true`: verify the fixme reason cites both the scenario value and the observed app value. Partial annotation is acceptable but should be noted as a recommendation.

### 9c-beta. Soft-Fail Surfacing — MANDATORY

A test whose `expect.soft()` assertion fails still passes overall in Playwright. Silent soft failures can indicate: (a) a helper returning `""` / `null` so the assertion never actually verifies, (b) a real app bug being accepted without annotation, (c) a flaky selector that was never investigated.

- [ ] Read precheck evidence `dim9_fidelity.softFailures`. If `softFailuresDetected > 0`:
  - [ ] **EACH soft failure must have an explicit "Known Soft Failures" table entry in the Executor report AND a documented reason** (known app behavior, known bug, accepted flakiness). Untriaged soft failures are a Dim 9 finding — cap at 4/5 if any untriaged.
  - [ ] If a helper method returns `""` / empty array and is consumed by `expect.soft(x).toContain(...)`, the assertion structurally cannot fail or pass meaningfully. **CRITICAL — cap Dim 9 at 3/5 and cite the specific method.**

### 9d. Keyword Code Patterns

For each keyword in the scenario, verify the spec has the correct code:

- [ ] **CAPTURE** → `let varName` in outer scope, assigned via getter inside `test.step()`. Count matches.
- [ ] **CALCULATE** → Arithmetic matching the exact formula. Count matches.
- [ ] **SCREENSHOT** → `page.screenshot({ fullPage: true })` + `test.info().attach('name')`. Count matches.
- [ ] **REPORT** → `test.step()` label includes runtime value (template literal) AND `test.info().annotations.push()`. `console.log()` NOT required. Count matches.
- [ ] **SAVE** → `saveState('key', value)`. Count matches.
- [ ] **USE_HELPER** → Helper method call, or WARNING + `test.fixme()` if helper missing. Count matches.
- [ ] **DATASETS** → `for...of` parameterized loop covering all data rows.
- [ ] **SHARED_DATA** → `loadTestData` import with correct dataset names.
- [ ] **API steps** → `request.{method}()` with status assertion. Count matches.

### 9e. Lifecycle Hook Fidelity (multi-scenario files)

- [ ] `Common Setup Once` in scenario → `test.beforeAll()` with ALL steps
- [ ] `Common Setup` → `test.beforeEach()` with ALL steps
- [ ] `Common Teardown` → `test.afterEach()` with ALL steps
- [ ] `Common Teardown Once` → `test.afterAll()` with ALL steps
- [ ] `beforeAll`/`afterAll` destructure ONLY `{ browser }` — NEVER `{ page }` or `{ request }`
- [ ] Lifecycle hook steps use semantic prefix labels: `[Setup]`, `[Before Each]`, `[After Each]`, `[After All]` — no step numbers

### Scoring

- **5/5** — Every step, assertion, and keyword has exact corresponding code. Zero gaps.
- **4/5** — 1-2 minor discrepancies (step label paraphrases slightly but code is correct)
- **3/5** — 1-2 missing steps or keywords, but assertions are intact
- **2/5** — Multiple missing steps/keywords, OR an assertion is weakened/missing. Also: CAPPED here if `TESTS_STATUS=FAILING`.
- **1/5** — Significant gaps: multiple steps dropped, assertions missing, keywords not implemented

**Verdict: FAIL if score below 4. This dimension has ZERO tolerance for missing assertions or dropped steps.**

**Score: _/5**

