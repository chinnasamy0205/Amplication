---
name: pipeline-plan
description: "The deterministic QE pipeline plan the orchestrator executes: the ordered stage DAG (Enrichment → Incremental-Detection → Explorer → Builder → Cleanup → Executor → Reviewer → Healer → re-Review → Summary), the pipeline-mode table that drives Explorer/Builder skip rules, the per-stage delegation contracts and validation gates, and the safety-critical decision logic (Executor HARD GATE, Stage-4 Healer, Final Verdict, subagent-failure) carried verbatim."
version: "1.0"
---

# Pipeline Plan — Deterministic Execute + Validation Gates

This is the **plan object** the `pipeline-orchestrator` executes. Control flow is **deterministic**: stages run in the fixed order below, each guarded by a validation gate; the orchestrator never does an agent's work and never deviates from the gate logic. The only LLM judgment lives inside the delegated agent stages. (Dynamic, intent-driven planning + agent auto-scaling are staged for P2/P3 — not this plan.)

All paths resolve via the `path-resolution` knowledge. Type skip rules + fixtures via `type-registry`. Timing + the orchestrator metrics JSON via `agent-reporting`.

## The Plan (ordered stages)

| # | Stage | Agent | Condition | Validation gate (HARD STOP on fail → report INCOMPLETE) |
|---|-------|-------|-----------|----------------------------------------------------------|
| 0 | Enrichment | `enrichment-agent` | only if input is NL/Swagger (skip if structured `.md`/`.enriched.md` exists) | `SCENARIO_PATH` exists AND has `## Steps` with numbered steps |
| 1-pre | Incremental Detection | — (scripts only) | always | `builder-instructions.json` produced with a `pipelineMode` |
| 1a | Explorer | `explorer-agent` | RUN for FIRST_RUN / EXPLORER_REQUIRED; SKIP for BUILDER_ONLY / NO_CHANGES | `{scenario}.enriched.md` exists AND explorer report exists |
| 1b | Builder | `builder-agent` | SKIP for NO_CHANGES; RUN otherwise | (after post-check) `TEST_SPEC` exists AND builder report exists |
| 1-post | Cleanup Annotations | — (script only) | after Builder | enriched.md cleaned; post-check shows step-count match + zero raw selectors |
| 2 | Executor | `executor-agent` (web/api/hybrid) | always | EXECUTOR_REPORT exists → apply the **Executor HARD GATE** below |
| 3 | Reviewer | `reviewer-agent` | always | REVIEW_SCORECARD exists; read the verdict |
| 4 | Healer | `healer-agent` | only if Reviewer verdict = NEEDS FIXES (see Stage-4 table) | HEALER_REPORT exists; read final test status |
| 3b | Re-Review | `reviewer-agent` | only if Healer ran AND its tests pass | updated REVIEW_SCORECARD exists |
| — | Pipeline Summary | — (orchestrator writes) | always | `PIPELINE_SUMMARY` saved as a FILE (zero placeholders) |

> **There is no Scout prerequisite.** The Explorer captures element selectors directly from the MCP snapshot during exploration; the Builder extracts ELEMENT annotations from the enriched.md to create locator JSONs. No separate element-discovery tool is needed.
> **Mobile (Phase 2):** for `mobile`/`mobile-hybrid`, Stage 1a uses Appium MCP (+ device pre-flight) and Stage 2 routes to the mobile executor via `scripts/mobile-runner.js` marker-polling. Web/api/hybrid is the Phase-1 path.

## Pipeline Cleanup — before every run
Delete the existing **reports** for this scenario (stale reports cause inconsistent results): enrichment/explorer/builder/executor/healer reports, precheck JSON, review scorecard, pipeline summary, and the explorer/executor/healer metrics JSON. **DO NOT delete** locators, page objects, core files, shared test data, or the spec file — only reports.

## Stage 1-pre — Pipeline Mode (drives Explorer/Builder skip rules)
Run `scenario-diff.js` then `builder-incremental.js` (both zero-LLM-token), then read `pipelineMode` from `builder-instructions.json`:

| `pipelineMode` | Stage 1a (Explorer) | Stage 1b (Builder) | Meaning |
|----------------|--------------------|--------------------|---------|
| `FIRST_RUN` | **RUN** (full exploration) | **RUN** (full generation) | No existing spec — first pipeline run |
| `NO_CHANGES` | **SKIP** | **SKIP** | Scenario matches spec — proceed directly to Stage 2 |
| `BUILDER_ONLY` | **SKIP** | **RUN** (incremental) | Only VERIFY values or teardown changed — no new interactions to explore |
| `EXPLORER_REQUIRED` | **RUN** (selective) | **RUN** (incremental) | New/changed interactions — Explorer must verify in browser |

For EXPLORER_REQUIRED, the Explorer reads `classified-changeset.json` for per-step walk modes (FAST = execute to maintain state, no capture; DEEP = full verify+capture; SKIP = deleted). After Builder, always run `cleanup-annotations.js` to strip `<!-- CHANGE: -->`/`<!-- WALK: -->` markers and delete the temp `classified-changeset.json` + `builder-instructions.json`.

## Per-stage delegation contract
For each RUN stage the orchestrator delegates via the `Task` tool, passing **minimum necessary context** (the agent does NOT inherit the orchestrator's context): `SCENARIO_NAME`, `SCENARIO_TYPE`, `FOLDER` (if set), `LANGUAGE` (Builder), the resolved input/output paths for that stage, and — for the Executor/Reviewer — `TESTS_STATUS`. The agent's own instructions + skills/knowledge load on the agent side; the orchestrator does not restate them.

---

## Executor HARD GATE — verbatim (Stage 2 → Stage 3)

**HARD GATE — MANDATORY verification before proceeding. DO NOT skip this gate. DO NOT rationalize skipping.**

1. **MUST** check that EXECUTOR_REPORT exists — if missing → STOP, report INCOMPLETE
2. **MUST** read the executor report and extract: tests passed, tests failed, test.fixme count, fix cycles used, final status
3. **MUST** apply this EXACT decision logic — NO deviations:

   - **IF all tests pass (0 failed)** → Record `TESTS_STATUS=PASSING`. Proceed to Stage 3.
   - **IF tests failing AND fix cycles NOT exhausted** (e.g., 1/N used where N = `framework-config.json → executor.maxCycles`, executor stopped early) → **MUST NOT proceed to Stage 3.** Re-delegate to Executor to continue fix cycles. ONLY proceed after Executor exhausts all `maxCycles` cycles OR all tests pass.
   - **IF tests failing AND fix cycles exhausted** (N/N where N = `executor.maxCycles`, still failing) → Record `TESTS_STATUS=FAILING`. Proceed to Stage 3 with TESTS_STATUS=FAILING.

**Cycle-budget metric:** read `testExecutionCount` from `output/reports/metrics/executor-metrics-{scenario}.json`. The gate: `testExecutionCount < executor.maxCycles` ⇒ executor stopped early; `testExecutionCount == executor.maxCycles` with tests still failing ⇒ exhausted. (Mobile metrics also carry `infraRetries`/`runnerCrashRetries` which do NOT count toward the budget.)

**HARD STOP: MUST NOT skip to Stage 3 while the Executor has remaining fix cycles and tests are still failing. This was the #1 bug in v1 — the pipeline reported APPROVED with 0 tests passing. NEVER AGAIN.**

---

## Stage 4: Healer — verbatim decision table (only when Reviewer verdict = NEEDS FIXES)

| Reviewer Verdict | Action |
|-----------------|--------|
| APPROVED | **SKIP Stage 4** — proceed to Final Verdict |
| APPROVED WITH CAVEATS | **SKIP Stage 4** — proceed to Final Verdict |
| NEEDS FIXES | **INVOKE Healer** — fix the issues |
| TESTS FAILING | **SKIP Stage 4** — Executor already exhausted cycles, Healer cannot help |

**Post-Healer gate:**
1. **MUST** check that HEALER_REPORT exists. Read the final test status.
2. If healer test status = **PASSING** → Re-run the Reviewer (Stage 3b) to produce an UPDATED scorecard reflecting the healer's fixes. Note in the prompt: `"This is a re-review after Healer fixes. The healer-report is at: {HEALER_REPORT}"`
   - **Precheck MUST be regenerated, not reused.** The Stage-3 precheck JSON (`precheck-report-{scenario}.json`) is now **stale** — the Healer edited specs/page-objects/locators after it was written. The re-review Reviewer's flow already runs `review-precheck.js` FIRST (its §3 step 1), which overwrites the stale JSON with healed-state evidence. Do NOT let any consumer read the pre-Healer precheck between Stage 4 and Stage 3b; the re-review's own precheck run is the source of truth for the updated scorecard.
3. If healer test status = **FAILING** → Record as TESTS FAILING in the pipeline summary. Do NOT re-run Reviewer.
4. **Maximum one Healer invocation per pipeline run.** Do NOT loop Healer → Reviewer → Healer.

---

## Final Verdict — verbatim decision logic

**MUST use this exact logic — DO NOT deviate:**

| Condition | Verdict |
|-----------|---------|
| Reviewer says APPROVED **AND** all tests passing (0 failed, 0 fixme) | **APPROVED** |
| Reviewer says APPROVED **AND** some tests have `test.fixme()` (potential bugs, not code failures) | **APPROVED WITH CAVEATS** — list each fixme |
| Reviewer says NEEDS FIXES **AND** Healer was invoked **AND** re-review says APPROVED | **APPROVED (after Healer fixes)** — note healer involvement |
| Reviewer says NEEDS FIXES **AND** Healer was NOT invoked or re-review still says NEEDS FIXES | **NEEDS FIXES** — list remaining fixes |
| Tests still failing after Executor exhausted all cycles | **TESTS FAILING** — list failing tests |
| Healer was invoked but tests now failing | **TESTS FAILING** — healer introduced regression |
| A stage failed or didn't complete | **INCOMPLETE** — {Stage N}: {reason} |

**HARD STOP: NEVER report APPROVED when tests are failing.** A perfect reviewer score on code that doesn't pass is meaningless.

---

## Subagent Failure — verbatim HARD STOP (DO NOT fabricate)

**If a subagent returns partial output (context exhaustion, timeout), the Orchestrator MUST NOT complete the stage itself. The Orchestrator MUST NOT generate code, locators, page objects, or spec files.**

| Subagent Result | Orchestrator Action |
|----------------|---------------------|
| COMPLETE | Proceed to next stage |
| PARTIAL — some steps explored, code written for those steps | Log warning, proceed with what exists. Report shows PARTIAL. |
| FAILED — no output | Log error, report INCOMPLETE. **DO NOT generate code yourself.** |
| Context exhaustion mid-exploration | Same as PARTIAL — use what the subagent wrote to disk. **DO NOT "complete" the remaining steps.** |

**Why this rule exists:** In a prior incident, the Orchestrator "completed Stage 1 directly" after a subagent context exhaustion — generating code from the scenario text without browser verification. Every step failed during Executor. The Orchestrator is NOT an Explorer — it cannot generate correct selectors because it has no browser access. **The correct response to subagent failure is INCOMPLETE, not fabrication.**

