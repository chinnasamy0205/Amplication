---
name: agent-reporting
description: "The common reporting + metrics + time-tracking convention every pipeline agent follows: per-stage report to output/reports/, a metrics JSON, wall-clock Duration (never a placeholder), and LEDGER anti-fabrication markers for evidence-producing agents. The metrics JSON example shown is the Explorer's; each agent carries its own fields."
version: "1.0"
---

# agent-reporting

> Shared convention for ALL pipeline-stage agents. Each agent writes a per-stage report + a metrics JSON and tracks its own wall-clock duration. The **LEDGER** markers below are the anti-fabrication evidence for evidence-producing agents (Explorer), consumed by the Reviewer. The metrics JSON fields shown are the Explorer's example — each agent declares its own field set. (Section numbers preserved from source.)

## 6. Explorer Report — MANDATORY

**Follow the per-stage report template for your agent** — the structure below (a MANDATORY header block with **Duration**) plus the agent's stage-specific sections.

Save to: `output/reports/[{folder}/]explorer-report-{scenario}.md`

The `[{folder}/]` segment is REQUIRED whenever the run has a `folder` parameter (e.g., `folder=connect-mobile` → `output/reports/connect-mobile/explorer-report-{scenario}.md`). Omit it only when `folder` is unset. Other consumers (Reviewer, precheck script, Builder) all expect this folder-prefixed path per the qe-automation output path conventions. Writing to a non-folder path when folder is set causes downstream tools to report `explorerReportFound: false`.

The Explorer report documents:
- Steps verified vs blocked
- Pages discovered and elements captured per page
- Element capture statistics (how many elements captured, selector strategies used)
- App-context patterns confirmed or newly discovered
- Flow issues encountered

### 6.0: LEDGER Markers — MANDATORY Anti-Fabrication Evidence

**HARD STOP: The Explorer MUST emit one `<!-- LEDGER:END step=N -->` HTML comment marker immediately after each Step Results table row, where `N` is the step number from that row.**

**Why this exists:** The Reviewer agent's anti-fabrication gate (Check 2) counts these markers and compares against the claimed step count. A run with 42 claimed steps but 0 LEDGER markers triggers `## WARNING: LEDGER INCOMPLETE` and caps Dimension 9 (Fidelity) at 2/5 — even when exploration is genuine. Emitting markers turns the check from a warning into a pass.

**When to emit each marker — strict timing rule (defeats pre-emission fabrication):**

A marker for step `N` MUST be written to the report file ONLY AFTER:
1. The MCP browser interaction for step `N` has actually been performed (e.g., `browser_click`, `browser_type`, `browser_snapshot` returned a result), AND
2. The corresponding Step Results table row for step `N` has been fully written (Description, Status, Selector Used, Notes all populated)

**MUST NOT** emit all 42 markers up-front in a single batch. **MUST NOT** emit a marker for a step that was SKIPPED or NOT_EXPLORED (those steps appear in the table with status `BLOCKED` or `SKIPPED` and get NO ledger marker).

**Format:**

```markdown
| 3 | Click filter icon | VERIFIED | 2 | th:first-child svg:last-of-type | SVG element, not IMG — attempt 1 used img selector |
<!-- LEDGER:END step=3 -->
| 4 | Enter filter text | VERIFIED | 2 | [data-testid="filter-input"] | fill() didn't trigger filter → used pressSequentially |
<!-- LEDGER:END step=4 -->
| 5 | VERIFY: Grid filtered | BLOCKED | 3 | .grid-cell | Grid content not accessible via DOM |
```
(Note: step 5 is BLOCKED → NO marker emitted)

**Cost:** ~15 tokens per step (e.g., ~630 tokens for a 42-step scenario). No additional MCP calls, no additional browser interactions, no additional wall-clock time.

**Self-audit before saving the report:** Count the markers you have emitted. The count MUST equal the number of VERIFIED-status rows in your Step Results table. If they don't match, fix the report before saving.

---

---

## 6a. Time Tracking and Metrics — MANDATORY

**HARD STOP: Every Explorer run MUST track its own wall-clock duration and write a metrics JSON file.**

### Recording Time

1. **FIRST ACTION** (before any pre-flight reads): run `date -u +"%Y-%m-%dT%H:%M:%SZ"` in the terminal and record the output as `startTime`.
2. **LAST ACTION** (after writing enriched.md, explorer report, and all outputs): run `date -u +"%Y-%m-%dT%H:%M:%SZ"` again and record as `endTime`.
3. **Compute `durationMs`**: calculate the difference between endTime and startTime in milliseconds.
4. **Fill the Duration field** in the explorer report: populate `**Duration:** {N}m {N}s` in the MANDATORY header block AND the Observability section's Duration row. Both MUST have the same computed value (e.g., `5m 40s` for durationMs=340000). NEVER leave a `~{N}` placeholder in the saved report.

### Per-Step Timing — OPT-IN via `EXPLORER_STEP_TIMING=true`

Per-step timing is **disabled by default** because capturing timestamps at each step boundary adds measurable overhead (1-3% on a typical Explorer run, more if the agent has to shell out to `date` for timestamps). This capability is a **diagnostic tool for latency investigations**, not standard runtime instrumentation. Keep it off in routine runs; enable when investigating slow Explorer behavior.

**Activation gate — check `process.env.EXPLORER_STEP_TIMING`:**

- **If `process.env.EXPLORER_STEP_TIMING === 'true'`** → capture per-step timings per the procedure below.
- **Otherwise (default — env var unset, empty, or any other value)** → skip the capture. Set `stepDurations: []` in the metrics JSON and set `observabilityNote` to `"per-step timing disabled — set EXPLORER_STEP_TIMING=true to enable"`. Do NOT spend tokens estimating timings.

**Capture procedure (only when gate is on):**

1. **BEFORE each step's first action**: record the current epoch milliseconds (`Date.now()` equivalent) as `stepStartMs`.
2. **AFTER the step is complete** (annotation written, screenshot captured if any, ready to move to next step): record `stepEndMs` and compute `stepDurationMs = stepEndMs - stepStartMs`.
3. **Accumulate** these into an array, one entry per scenario step (including Common Setup steps and Common Teardown steps if present).
4. **Categorize** each step by its keyword type — one of: `verify` | `action` | `capture` | `screenshot` | `wait` | `setup` | `teardown` | `other`. This enables breakdowns by step kind (especially useful for SCREENSHOT steps, which are typically the slowest due to image capture/serialization).
5. **Write to the metrics JSON** under `stepDurations` per the schema below. Do NOT include this in the explorer report markdown (keep the markdown human-readable; the JSON is for tooling).

If the Explorer cannot reliably record per-step times even when the gate is on (e.g., the agent runtime does not expose a clock), it MUST write `stepDurations: []` and set `observabilityNote` to explain why ("runtime did not expose Date.now() during step processing"). Never fabricate values.

**When to enable:** opening a new latency investigation, comparing before/after of a perf-impacting change (Appium driver upgrade, MCP server change, new scenario complexity class), or responding to a "my Explorer run took N minutes" report from another QE engineer.

**When to leave off (default):** all routine pipeline runs, CI runs, customer-facing scenarios. The aggregate `durationMs` field alone is enough for trend tracking; per-step breakdown is only needed when actively diagnosing.

### Metrics JSON — MANDATORY Output

**MUST** write a metrics file to `output/reports/metrics/explorer-metrics-{scenario}.json` on EVERY run.

```json
{
  "agent": "explorer",
  "scenario": "{scenario-name}",
  "type": "{web|api|hybrid|mobile|mobile-hybrid}",
  "startTime": "{ISO timestamp}",
  "endTime": "{ISO timestamp}",
  "durationMs": 0,
  "stepsExplored": 0,
  "stepsVerifiedFirstTry": 0,
  "stepsRequiredRetry": 0,
  "stepsBlocked": 0,
  "elementsDiscovered": 0,
  "pagesVisited": 0,
  "helpersWalked": 0,
  "mcpInteractions": 0,
  "mcpSnapshotCount": 0,
  "browserTouchingSteps": 0,
  "appContextUpdated": false,
  "stepDurations": [
    { "stepIndex": 1, "type": "setup", "durationMs": 0 },
    { "stepIndex": 2, "type": "verify", "durationMs": 0 },
    { "stepIndex": 3, "type": "action", "durationMs": 0 }
  ],
  "observabilityNote": "",
  "contextWindowPercent": "Platform does not expose context window usage",
  "tokenEstimate": "Platform does not expose token count",
  "metricsVersion": "2.1.0"
}
```

**Field rules:**
- `stepsExplored`: total steps walked (including helper @steps)
- `stepsVerifiedFirstTry`: steps that succeeded on first attempt
- `stepsRequiredRetry`: steps that needed retries (up to maxAttemptsPerStep)
- `stepsBlocked`: steps that failed after all retries
- `elementsDiscovered`: count of ELEMENT annotations produced
- `pagesVisited`: count of distinct page sections in enriched.md
- `helpersWalked`: count of USE_HELPER steps where @steps were walked
- `mcpInteractions`: **total** Playwright/Appium MCP tool calls performed during exploration — every browser/app interaction (clicks, types, navigations, waits, AND snapshots). This is the numerator of the Reviewer's Check 1 MCP-interaction ratio. The Explorer increments a counter as it works and writes the final total here. **If the runtime genuinely cannot expose a reliable count, set `null`** (not 0) and explain in `observabilityNote` — the Reviewer treats `null` as INDETERMINATE (no fabrication warning), NOT as zero. A real value of `0` with `stepsExplored > 0` IS a fabrication signal.
- `mcpSnapshotCount`: count of snapshot-type MCP calls specifically (`browser_snapshot` and equivalents) — a subset of `mcpInteractions`. Numerator basis for the Reviewer's Check 3 snapshot-rate check. `null` if not countable.
- `browserTouchingSteps`: count of steps that actually require a browser/app MCP interaction (navigation, click, fill, element-level VERIFY/VERIFY_SOFT, page CAPTURE, SCREENSHOT). **Excludes pure-logic steps** (CALCULATE, REPORT, SAVE, and URL/title-only VERIFYs that need no snapshot). This is the **preferred denominator** for the Reviewer's Check 1 ratio — using it instead of `stepsExplored` prevents logic-heavy scenarios from being false-flagged as low-MCP. `null` if the Explorer cannot classify steps.
- `stepDurations`: array of `{stepIndex, type, durationMs}` — one entry per scenario step in positional order (Common Setup + Steps + Common Teardown, continuous numbering). `type` is one of `setup|verify|action|capture|screenshot|wait|teardown|other`. **Populated ONLY when `EXPLORER_STEP_TIMING=true`** (see Per-Step Timing section above). Empty array `[]` in all other cases (default), or when the gate is on but the runtime cannot expose a clock. Whenever empty, set `observabilityNote` to explain why ("per-step timing disabled" or "runtime did not expose Date.now()").
- `observabilityNote`: free-form string for caveats; empty string when no caveats. Required when `stepDurations` is empty.

---

