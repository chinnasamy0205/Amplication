---
name: INDEX
description: "Knowledge: INDEX"
version: "1.0"
---

# Knowledge Base Index — qe-automation

<!-- This file indexes the qe-automation knowledge base and is used by knowledge-search.js for relevance scoring.
     Agents reference each entry by name (e.g., "the bug-detection knowledge"); the entry loads on demand.
     Use: node scripts/knowledge-search.js "<query>" -->

---

## Conventions

### Enriched.md Contract
- **path**: `knowledge/conventions/enriched-md-contract.md`
- **tokens**: 1500
- **trigger_signals**: `["enriched.md", "ELEMENT annotation", "page section header", "provenance tag", "ORIGINAL/EXPANDED/DISCOVERED", "variable-path", "Detail Level header", "App Behavior header", "key naming"]`
- **typical_relevance**: HIGH for Explorer (produces it) and Builder (consumes it); LOW otherwise

### App-Context
- **path**: `knowledge/conventions/app-context.md`
- **tokens**: 900
- **trigger_signals**: `["app-context", "appContext", "scenarios/app-contexts", "learned pattern", "known application", "persist patterns", "Voyager", "create-on-missing"]`
- **typical_relevance**: HIGH for Explorer/Executor (read before, write after a run); LOW otherwise

### Agent Reporting
- **path**: `knowledge/conventions/agent-reporting.md`
- **tokens**: 1100
- **trigger_signals**: `["report", "metrics JSON", "Duration", "time tracking", "LEDGER", "anti-fabrication", "observability", "output/reports"]`
- **typical_relevance**: HIGH for every pipeline agent (each writes a report + metrics)

### Scenario Handling
- **path**: `knowledge/conventions/scenario-handling.md`
- **tokens**: 1600
- **trigger_signals**: `["multi-scenario", "### Scenario", "Common Setup Once", "Common Teardown", "lifecycle hook", "DATASETS", "20+ steps", "test.describe"]`
- **typical_relevance**: HIGH when a scenario has multiple blocks, hooks, datasets, or 20+ steps

### Type Registry
- **path**: `knowledge/conventions/type-registry.md`
- **tokens**: 1300
- **trigger_signals**: `["scenario type", "web", "api", "hybrid", "mobile", "mobile-hybrid", "fixture", "type-specific behavior", "pipeline stage", "appContext key"]`
- **typical_relevance**: HIGH whenever resolving type-specific behavior, paths, or fixtures

### Guardrails
- **path**: `knowledge/conventions/guardrails.md`
- **tokens**: 1200
- **trigger_signals**: `["*.helpers.ts", "team-owned", "read-only", "ownership boundary", "hardcoded credential", "hardcoded wait", "force bypass", "mock vs live API", "forbidden action"]`
- **typical_relevance**: HIGH for every agent that writes files or interacts with APIs

### Fix Discipline
- **path**: `knowledge/conventions/fix-discipline.md`
- **tokens**: 1700
- **trigger_signals**: `["fix rule", "Semantic Guard", "necessary and sufficient", "throw-free", "STOP on user-side", "file edit scope", "PRE-EDIT GATE", "scenario-locked", "test data divergence", "config not code", "POTENTIAL BUG", "test.fixme", "what can the Executor edit"]`
- **typical_relevance**: HIGH for the Executor (governs every fix); MEDIUM for Healer/Reviewer

### Heal Discipline
- **path**: `knowledge/conventions/heal-discipline.md`
- **tokens**: 700
- **trigger_signals**: `["healer fix rule", "what can the Healer edit", "repair not rewrite", "NEEDS FIXES", "fix by dimension", ".env.example editable", "scenario-level override", "preserve test.fixme", "Healer file edit scope"]`
- **typical_relevance**: HIGH for the Healer (governs every fix); LOW otherwise

### Path Resolution
- **path**: `knowledge/conventions/path-resolution.md`
- **tokens**: 1100
- **trigger_signals**: `["path", "where does this go", "output/reports", "scenario path", "spec file path", "locator path", "metrics path", "report path", "test execution command", "script command", "hardcode path"]`
- **typical_relevance**: HIGH for the Orchestrator; MEDIUM for every agent that reads/writes files

### Pipeline Plan
- **path**: `knowledge/conventions/pipeline-plan.md`
- **tokens**: 2000
- **trigger_signals**: `["pipeline", "stages", "orchestrator", "pipeline mode", "FIRST_RUN", "NO_CHANGES", "BUILDER_ONLY", "EXPLORER_REQUIRED", "HARD GATE", "final verdict", "TESTS_STATUS", "subagent failure", "delegate", "validation gate"]`
- **typical_relevance**: HIGH for the Orchestrator (the plan it executes); LOW otherwise

---

## Patterns

### Bug Detection (Flag vs Adapt)
- **path**: `knowledge/patterns/bug-detection.md`
- **tokens**: 900
- **trigger_signals**: `["interaction failed", "flag vs adapt", "is this a bug", "3-question decision gate", "HOW vs WHAT", "BLOCKED", "test issue vs application bug"]`
- **typical_relevance**: HIGH for Explorer (applied after every interaction); MEDIUM for Healer/Reviewer

### Quality Gates
- **path**: `knowledge/patterns/quality-gates.md`
- **tokens**: 1600
- **trigger_signals**: `["fidelity", "scenario-to-code", "step counting", "self-validation gate", "raw selector audit", "cookie/consent/popup", "zero tolerance"]`
- **typical_relevance**: HIGH for Explorer/Builder (fidelity) and Reviewer (audit)

### Review Dimensions
- **path**: `knowledge/patterns/review-dimensions.md`
- **tokens**: 2600
- **trigger_signals**: `["scorecard", "9 dimensions", "dimension score", "locator quality", "wait strategy", "test architecture", "code quality", "maintainability", "API quality", "scenario-to-code fidelity", "verdict", "APPROVED", "NEEDS FIXES", "review", "audit"]`
- **typical_relevance**: HIGH for the Reviewer (its scoring rubric); LOW otherwise
