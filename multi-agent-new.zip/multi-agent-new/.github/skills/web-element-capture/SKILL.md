---
name: web-element-capture
description: "Derive a stable, validated selector for a target element during live web exploration: snapshot-first capture, DOM-probe fallback, priority order, the validation gate (uniqueness + semantic tiebreaker + cross-key/cross-run dedup), element typing, and structural capture. The Explorer applies this on every interaction step."
version: "1.0"
---

# web-element-capture

> The Explorer applies this skill for **every element it captures** during the live walk. Given a step intent + the live Playwright MCP session, you return a validated `primary` selector + `fallbacks` + `fingerprint` for the ELEMENT annotation. (Section numbers below are preserved from the source so the internal cross-references stay valid.)

### 4.2: Snapshot-First Element Capture — MANDATORY for Interactions

**The MCP accessibility snapshot is your PRIMARY source of element data.** It already contains role, name, text, href, placeholder, and state (disabled, checked, expanded) for every accessible element. Use it directly — do NOT call `browser_evaluate()` unless the snapshot is insufficient.

**Step 1: Retrieve the target from the snapshot — surgically, NOT wholesale.** After a snapshot is written to `.playwright-cli/page-*.yml`, do **NOT** read the whole tree into context (on a grid/table page it is 20,000+ tokens and every read is re-billed on later turns — the Explorer's #1 token cost). Instead query for just the target node:

```
node scripts/snapshot-query.js --file=<snapshot.yml> --find="<name/text from step intent>" [--role=<role>]
```

This returns the matching `role "name" [ref=eN]` line plus its ancestor region and child metadata (`/url`, `/placeholder`, state) — the exact same bytes the full tree contains, in a few dozen tokens. Use `--structure` for grid/data-existence checks and `--interactive` for a cheap page overview. Only `Read` the raw `.yml` as a last resort on a genuinely small page (< ~150 lines). Everything below (role/name/href/placeholder extraction, the decision rule, selector priority) applies **unchanged** to the retrieved node. The snapshot format is:

```yaml
- button "Sign in" [ref=e89] [cursor=pointer]       # role=button, name="Sign in"
- link "SMEs" [ref=e36] [cursor=pointer]:
    - /url: /Experts/                                 # href available
- textbox "Enter password" [active] [ref=e77]:
    - /placeholder: Password                          # placeholder available
- columnheader "Specialty" [ref=e66] [cursor=pointer] # role=columnheader, name="Specialty"
- img [ref=e68]                                       # img with no name — generic
- generic [ref=e67]                                   # no role, no name — generic
```

**Step 2: Decide — snapshot or DOM probe?**

| Snapshot gives you... | Action | DOM probe needed? |
|---|---|---|
| Recognized role (button, link, textbox, checkbox, radio, combobox, heading, columnheader) + non-empty name | **Use snapshot directly.** Build selector from role+name. | **NO** |
| role=link + `/url:` value | **Use snapshot directly.** Build selector from href. | **NO** |
| role=textbox + `/placeholder:` value | **Use snapshot directly.** Build selector from placeholder. | **NO** |
| role=img with name | **Use snapshot directly.** Build selector from role+name. | **NO** |
| `generic` with no name, or `img` with no name, or element not in snapshot at all (SVGs, DOM-only panels, custom widgets) | **DOM probe required.** Call `browser_evaluate()` for this element. | **YES** |

**CRITICAL RULE: If the snapshot gives a recognized role + name, DO NOT call `browser_evaluate()`.** The snapshot data is sufficient. This saves one MCP round trip per element.

**Step 3a: Snapshot-derived element data (NO DOM probe).**

From the snapshot entry, extract:

| Snapshot field | Maps to ELEMENT annotation field |
|---|---|
| Role string (e.g., `button`, `link`, `textbox`) | `type` (use role→type mapping from Section 4.4) |
| Name string (quoted text after role) | Used for primary selector: `role=button[name='Submit']` |
| `/url:` value | Used for href-based selector: `a[href='/Experts/']` |
| `/placeholder:` value | Used for placeholder-based selector |
| `[ref=eNN]` | Used for MCP interaction (not stored in ELEMENT annotation) |

For fingerprint fields not available in the snapshot (`id`, `testId`, `cssPath`), set them to `null` in the ELEMENT annotation. The fingerprint will be partial — this is acceptable. If the Healer later needs a full fingerprint, it can DOM-probe at that time.

**Step 3b: DOM probe via `browser_evaluate()` (ONLY when snapshot is insufficient).**

Call this ONLY for elements that appear as `generic`, `img` with no name, or are not in the snapshot at all:

```javascript
browser_evaluate({
  ref: "{element_ref}",
  expression: "el => ({ tag: el.tagName?.toLowerCase(), id: el.id || null, testId: el.getAttribute('data-testid') || el.getAttribute('data-automation-id') || null, text: el.textContent?.trim()?.substring(0, 80) || null, name: el.getAttribute('name') || null, placeholder: el.getAttribute('placeholder') || null, href: el.getAttribute('href') || null, type: el.getAttribute('type') || null, ariaLabel: el.getAttribute('aria-label') || null, cssPath: (() => { try { let e = el; const p = []; while (e && e !== document.body) { let s = e.tagName.toLowerCase(); if (e.id) { p.unshift('#' + CSS.escape(e.id)); break; } const parent = e.parentElement; if (parent) { const sibs = [...parent.children].filter(c => c.tagName === e.tagName); if (sibs.length > 1) s += ':nth-of-type(' + (sibs.indexOf(e) + 1) + ')'; } p.unshift(s); e = e.parentElement; } return p.join(' > '); } catch { return ''; } })() })"
})
```

This is a lighter probe than the previous version — no uniqueness counts (the snapshot context already implies uniqueness), no `isNativeRole` flag (derived from tag). It returns the raw DOM data needed to build a selector for elements the snapshot couldn't cover.

**When the target element is NOT in the snapshot at all** (e.g., filter panel inputs, popover content), use `browser_evaluate()` with a CSS selector expression instead of a ref:

```javascript
browser_evaluate({
  expression: "document.querySelector('input[placeholder=\"Enter filter\"]') ? { tag: 'input', placeholder: 'Enter filter', id: document.querySelector('input[placeholder=\"Enter filter\"]').id || null, cssPath: 'input[placeholder=\"Enter filter\"]' } : null"
})
```

**Summary of the decision rule:**

```
SNAPSHOT has role+name or href or placeholder?
  ├── YES → Use snapshot data directly. NO browser_evaluate(). Save time and tokens.
  └── NO  → DOM probe this element via browser_evaluate(). Record the extra data.
```

### 4.3: Build the Selector — Priority Order

From the snapshot data (or DOM probe data for fallback elements), build the primary selector and fallbacks using this priority:

| Priority | Condition | Primary Selector Format | Example | Source |
|----------|-----------|------------------------|---------|--------|
| 1 | `testId` exists (from DOM probe) | `testid={value}` | `testid=submit-btn` | DOM probe only |
| 2 | `id` exists, not dynamic* (from DOM probe) | `#{id}` | `#login-button` | DOM probe only |
| 3 | Snapshot has recognized role + unique name | `role={role}[name='{name}']` | `role=button[name='Submit']` | Snapshot |
| 4 | `href` exists (from snapshot `/url:` or DOM probe) | `a[href='{value}']` | `a[href='/dashboard']` | Both |
| 5 | Snapshot has name text, unique in context | `text={value}` | `text=Sign In` | Snapshot |
| 6 | Text exists but not unique | CSS + has-text | `span:has-text("Sign In")` | Both |
| 7 | None of the above | `cssPath` from DOM probe | `#form > div:nth-of-type(2) > button` | DOM probe only |

*Dynamic ID detection: IDs containing UUIDs, timestamps, or random strings (e.g., `react-12abc`, `ember-456`) are skipped.

**For snapshot-derived elements (no DOM probe):** Priorities 1-2 are not available (no `testId` or `id` from snapshot). Start at Priority 3. This is fine — role-based selectors are the most stable strategy for Playwright.

**For DOM-probed elements:** All priorities are available. Use testId or id if present.

**Role mapping for native elements:**

| Tag | Role |
|-----|------|
| `a` | `link` |
| `button` | `button` |
| `input[type=text]` | `textbox` |
| `input[type=checkbox]` | `checkbox` |
| `input[type=radio]` | `radio` |
| `select` | `combobox` |
| `h1`–`h6` | `heading` |

**CRITICAL: NEVER use `role=` for non-native elements** (`span`, `div`, `li`, `td` with click handlers). MCP's accessibility tree infers roles that don't exist in the DOM. A `<span class="link">Users</span>` appears as `link "Users"` in the snapshot, but `getByRole('link', { name: 'Users' })` fails at runtime because the DOM has no `role="link"` attribute. Use `text=` or CSS selectors instead.

**Fallback generation — MUST include at least 2 fallbacks:**

Pick 2 additional selectors from the priority list (different strategies than primary):
- If primary is `testid=`, add a CSS fallback and a text fallback
- If primary is `text=`, add a CSS fallback and an aria-label or name fallback
- If primary is `role=`, add a text fallback and a CSS fallback

### 4.3a: Selector Validation Gate — MANDATORY

**After building the primary selector, validate it resolves to exactly 1 element on the live page.** This prevents the two most common test failure modes: selectors that match multiple elements (Playwright strict mode violation) and selectors that match zero elements (phantom/stale selector from DOM probe).

**Skip validation for:** structural selectors (type `structural` — e.g., `tbody tr`) which intentionally match multiple elements.

**For all other selectors, run:**

```javascript
browser_evaluate({
  expression: "document.querySelectorAll('YOUR_CSS_SELECTOR').length"
})
```

For `role=` selectors, validate the underlying CSS equivalent. For example, `role=button[name='Submit']` → validate `button:has-text('Submit')` or `input[value='Submit']`. This is an approximation — role selectors may match `<div role="button">` that CSS misses — but it catches the majority of ambiguity issues.

| Count | Action |
|-------|--------|
| **1** | Unique. Record as primary — but first run the **semantic-specificity tiebreaker** and the **cross-key collision check** below. |
| **0** | Doesn't match. Try next priority selector. If all fail → `<!-- ELEMENT_CAPTURE_FAILED -->`. |
| **2+** | Ambiguous. **Narrow it** — add `:has-text('...')`, add class qualifier (e.g., `a.nav-text[href='...']`), or scope with parent container. Re-validate after narrowing. |

**Semantic-specificity tiebreaker — MANDATORY when the primary is a bare attribute selector that matched count=1.**

A bare attribute selector (`[aria-label='X']`, `[data-foo='Y']`) resolves to the FIRST matching element in document order. When the app renders a generic container around a role-specific child that shares the same attribute (e.g., `<div aria-label='Consent Dialog'>` wrapping `<dialog aria-label='Consent Dialog'>`), the bare attribute selector matches the outer container — not the semantically-meaningful child. Count=1 is satisfied, but the element is wrong: the container may be always-visible or have different display state than the dialog, causing `isVisible()` / `isHidden()` to return the wrong answer and silently break dismissal guards.

**The rule:** when the validated primary is a bare attribute selector (no tag, no role prefix), also validate the tag-qualified form (e.g., `dialog[aria-label='X']`, `button[aria-label='X']`) derived from the fingerprint's `tag` field. If the tag-qualified form ALSO resolves to count=1 AND resolves to a DIFFERENT element that is a descendant of the bare-selector match, emit the tag-qualified form as primary and keep the bare form as the first fallback.

```javascript
// Tiebreaker check
const bareMatch = document.querySelectorAll("[aria-label='Consent Dialog']")[0];
const qualifiedMatch = document.querySelectorAll("dialog[aria-label='Consent Dialog']")[0];
if (qualifiedMatch && bareMatch !== qualifiedMatch && bareMatch.contains(qualifiedMatch)) {
  // Emit `dialog[aria-label='Consent Dialog']` as primary
}
```

**When the tiebreaker does NOT apply:** fingerprint's `tag` is `div`/`span`/`section` (no semantic role); both forms resolve to the same element; tag-qualified form resolves to count=0 or 2+. In those cases, keep the bare attribute selector as primary.

**Cross-key collision check — MANDATORY before closing Section 4.3a for an element.**

Before appending a new `<!-- ELEMENT: -->` annotation to enriched.md, check the in-memory record of primary selectors already emitted for the SAME page in this run. If the new key's primary selector string is byte-for-byte identical to an already-emitted primary on the same page, the Explorer has captured two semantically distinct concepts (e.g., `anyProductCheckbox` and `anyCourseCheckbox`) that resolve to the same DOM node. **Narrow at least one of them** — scope by the nearest ARIA region, container heading text, or section-specific ancestor. Re-validate after narrowing.

**Exception:** two keys may legitimately share a primary when one is explicitly marked `"alias_of": "<otherKey>"` in the element annotation. Aliasing is rare and MUST be documented with a `<!-- DISCOVERED: {newKey} is an alias for {existingKey} because [reason] -->` note.

**Cross-run key reuse — MANDATORY before assigning a new key name.**

Before deciding the `key` field for a new ELEMENT annotation, check if `output/locators/{page-name}.locators.json` exists (apply the PascalCase → kebab-case mapping from the Builder agent's locator-file naming rule to derive the file name). If yes, read it and compare the new capture's `fingerprint` against each existing entry's persisted `fingerprint` field.

**Operational match:** all five fingerprint fields (`tag`, `id`, `testId`, `text`, `cssPath`) byte-for-byte identical, treating absent fields as `null === null`. Any single field differing — including whitespace inside `text` or a single index difference inside `cssPath` — means no match. No partial / fuzzy matching.

**On match:** **reuse the existing entry's key name verbatim** in the new ELEMENT annotation's `key` field. Do NOT invent a new name. The new capture's `primary`, `fallbacks`, `type`, and `fingerprint` still travel through the annotation; the Builder applies its merge rules (the Builder agent's locator-merge rules) to those fields.

**On no match (or existing entries lack a `fingerprint` field):** assign a new key name as usual. Older locator JSONs that predate fingerprint persistence will gradually acquire fingerprints written by the Builder, enabling reuse on subsequent runs. This is a one-way phase-in — no retroactive deduplication.

**Why:** prevents semantically-identical elements from being captured under different key names across scenarios (e.g., `loginEmailInput` and `emailInput` both targeting the same email field on `login-page.locators.json`, written by separate scenarios). Eliminates duplicate locator entries on shared pages without altering selector freshness.

**Skip all three checks (validation gate, cross-key collision, cross-run reuse) for:** type `structural` (list containers), type `list`, or any annotation that carries `"multiple": true` — these are expected to match multiple elements or be reused as container anchors.

**Iframe-aware validation:** If the current step's element is inside an iframe (Explorer switched frames via `frameLocator()`), run the validation query inside that same frame — not the top-level document. `querySelectorAll` only searches the current frame context.

**Shadow DOM:** If the app uses web components with shadow roots (e.g., Salesforce Lightning, ServiceNow), `querySelectorAll` will not find elements inside shadow DOM. In that case, skip CSS validation and rely on the MCP snapshot ref interaction result as the validation — if the MCP click/fill succeeded on the ref, the element exists. Record a `<!-- DISCOVERED: Shadow DOM — selector validation skipped, verified by MCP interaction -->` note.

**Emit-what-you-validated — HARD RULE.** The `primary` string written to the ELEMENT annotation MUST be byte-for-byte identical to the selector you ran through this gate. Do NOT substitute a different syntactic form between validation and emission (CSS ↔ `role=` ↔ `testid=` ↔ `text=`). If you validated `h1:has-text("'s Dashboard")`, emit `h1:has-text("'s Dashboard")` — not `role=heading[level=1]:has-text("'s Dashboard")` or any other "equivalent-looking" variant. Approximations are fine WHILE validating (the table above permits a CSS equivalent for a `role=` selector), but the emitted primary must be the exact string that Playwright will run at test time.

**Why this matters:** when the role-based approximation is "equivalent-looking" but not actually supported by Playwright's locator parser (e.g., `role=heading[level=N]:has-text(...)` combines `[level=N]` attribute filter with `:has-text()` pseudo-class — NOT a valid Playwright locator string), emitting it after validating a DIFFERENT CSS form produces a locator JSON entry that fails at Builder-run or Executor-run time with `InvalidSelectorError`. The Builder will faithfully copy the primary verbatim (per the Builder agent's primary-selector fidelity rule) — so whatever Explorer emits is what runs. **Validate the exact string you will emit, or emit the exact string you validated. The two MUST be identical.**

**Examples of the rule applied (non-exhaustive — the rule applies to ANY pair of locator forms, not only these cases):**

- Validated `h1:has-text("'s Dashboard")` (CSS) → emit `h1:has-text("'s Dashboard")`. Do NOT emit `role=heading[level=1]:has-text("'s Dashboard")` — it's a different syntactic form, AND this particular `[level=N]` + `:has-text()` combination is not a valid Playwright locator string (Builder-copy would fail at runtime with `InvalidSelectorError`).
- Validated `[data-testid="submit-btn"]` (CSS attribute) → emit that exact CSS form. Do NOT swap to `testid=submit-btn` (LocatorLoader prefix form) — LocatorLoader resolves the prefix through a different code path than a raw attribute selector; your validation run didn't exercise the prefix resolution path.
- Validated `button:has-text("Confirm")` (CSS) → emit that exact CSS form. Do NOT emit `role=button[name="Confirm"]` — the two forms are typically equivalent on native `<button>` elements but diverge on `<div role="button">`, and the validation ran against the CSS form, not the accessibility tree.
- Validated `xpath=//input[@placeholder='Search']` → emit the identical XPath string. Do NOT "simplify" to a CSS form after validation succeeded on the XPath.

**The rule is: validate-then-emit produces byte-identical strings. The examples above show a few observed traps; the rule applies to ANY pair of locator forms the Explorer can construct (CSS ↔ `role=` ↔ `testid=` ↔ `text=` ↔ `xpath=` ↔ `label=` and any future form). When you validate form A and emit form B, you have NOT validated what the Builder and Executor will run — by construction.**

### 4.4: Determine Element Type

From the captured `tag` and `type` fields:

| Tag + Type | Element Type |
|-----------|-------------|
| `input[type=text]`, `input[type=email]`, `input[type=password]`, `textarea` | `input` |
| `button`, `input[type=submit]` | `button` |
| `a` | `link` |
| `select` | `select` |
| `input[type=checkbox]` | `checkbox` |
| `input[type=radio]` | `radio` |
| `img` | `image` |
| Everything else | `text` |

### 4.5: Structural Element Capture — For VERIFY and Data-Grid Steps

When the step involves verifying data existence, sort order, or reading grid/table content, capture **structural selectors** in addition to individual element selectors:

| Scenario Intent | Structural Selector to Capture | Key Name Pattern |
|----------------|-------------------------------|-----------------|
| "Grid has data" / "widget visible with data" | `tbody tr` (all rows) | `{section}GridRows` |
| "Sorted A-Z" / "sorted descending" | `tbody tr td:first-child` (first column cells) | `{section}FirstColumnCells` |
| "Page shows N items" | `tbody tr` (count rows) | `{section}GridRows` |
| "Filter applied" / "all rows show X" | `tbody tr td:nth-child({col})` (specific column) | `{section}ColumnCells` |

**Structural selectors ALWAYS require a DOM probe** — the snapshot shows row/table structure but not CSS selectors for structural patterns. Use `browser_evaluate()` on the container element to verify the structural pattern and capture the selector:

```javascript
browser_evaluate({
  ref: "{table_or_grid_ref}",
  expression: "el => ({ rowCount: el.querySelectorAll('tbody tr').length, firstColumnSample: [...el.querySelectorAll('tbody tr')].slice(0, 3).map(r => r.querySelector('td:first-child')?.textContent?.trim()), hasData: el.querySelectorAll('tbody tr').length > 0 })"
})
```

Record structural selectors as ELEMENT annotations with `"type": "structural"`.

