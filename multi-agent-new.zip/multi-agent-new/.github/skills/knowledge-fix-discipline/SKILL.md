---
name: fix-discipline
description: "Executor fix-discipline boundaries: STOP on user-side root cause, the 11 Fix Rules (Semantic Guard, Necessary-and-Sufficient, Throw-Free page objects), the File-Edit-Scope table, Scenario-Locked test-data values, and Config-in-config-not-code. The Executor's MUST-NOT ruleset for every fix."
version: "1.0"
---

# Fix Discipline — Boundaries for Every Executor Fix

These rules govern WHAT the Executor is allowed to change while fixing a failing test, and what it must escalate instead. They pair with the `guardrails` ownership conventions. Every fix the Executor makes MUST clear all five sections below.

> **Shared source:** the Fix Rules in §2 (rules 9, 10, 11) are the single source of truth for both the web Executor and the Phase-2 mobile Executor (which uses "screen-object" for "page-object"). Edit them here once — there is no separate mobile copy to keep in sync.

---

## 1. STOP on User-Side Root Cause — MANDATORY

**When the Executor's diagnosis identifies the root cause as outside the agent's authority, the Executor MUST stop modifying code, write a "Fix required by you" report, and exit. No code changes that mask, work around, or wrap the user-side issue are permitted.**

**Operational triggers — STOP if ANY ONE fires:**

1. **Env var resolves to empty or matches a placeholder pattern.** Check the resolved value of any env var the test reads (`TEST_USERNAME`, `TEST_PASSWORD`, `BASE_URL`, etc.) against these regex patterns:
   - `/^your-/i` (e.g., `your-test-username`)
   - `/<.+>/` (e.g., `<replace-me>`)
   - `/changeme/i`
   - `/example\.com/`
   - `/replace-me/i`
   - Empty string
2. **HTTP 401/403 in the error AND a credential-related signal** — pair the auth code with EITHER an env-var placeholder match from #1 OR error message containing `Invalid credentials` / `Unauthorized` / `Login failed`. Bare 401/403 alone does NOT trigger; standalone auth errors may indicate session expiry, role-locked test account, or permission gap — all Executor-fixable.
3. **Test-data value is the literal placeholder from a template** (e.g., a JSON value of `"<insert real value>"`, `"changeme"`, `"your-app-url"`).
4. **Test-data file referenced by the spec does not exist on disk** (`fs.existsSync(...) === false` for an `output/test-data/{type}/*.json` path the spec imports).

**Required action when STOP fires:**

1. STOP all code modification immediately. Do NOT enter a fix cycle for this failure.
2. Write a "Fix required by you" section in the executor report listing:
   - The trigger that fired (which of #1–#4) and the matched value/error
   - The exact env var name(s), test-data file path(s), or credential field(s) the user needs to set
   - The file path the user should edit (`output/.env`, `output/test-data/{type}/{file}.json`, etc.)
3. Annotate the affected spec(s) with `test.skip('USER FIX REQUIRED: {trigger} — see executor report')` so subsequent runs do not re-attempt the same failure.
4. Exit with the user-side issue clearly surfaced. The Executor's job is done; control returns to the user.

**Explicitly NOT blocked — these stay editable per the File-Edit-Scope section (§3 below):**

- `output/playwright.config.ts` (missing browser config, project setup, timeout values)
- `framework-config.json` (`maxCycles`, type-specific timeouts, MCP settings)
- Any framework-level config gap that is the Executor's authority to fix per §3 below

**Why:** when the Executor compensates for a user-side issue with code changes, the fix does not address the actual root cause AND can introduce cross-scenario regressions in shared code (page-object methods consumed by multiple scenarios). The user-side issue persists; downstream scenarios break. STOP-on-user-side prevents this entire class of compensatory code changes — the user fixes their input, the Executor stays in its lane.

---

## 2. Fix Rules — MANDATORY

**MUST follow these rules for EVERY fix:**

1. **ONE fix per failure** — fix the root cause, not symptoms. Cascade failures from one root cause should be fixed at the ROOT, not at each cascading step
2. **MUST NOT change expected values in assertions** — if the value is wrong, it's a POTENTIAL BUG
3. **MUST NOT alter scenario step order or skip steps** — fidelity is sacred
4. **MUST NOT add `{ force: true }`** — EVER
5. **MUST NOT add `page.waitForTimeout()`** without a `// PACING:` comment explaining WHY the delay is needed and WHAT component is slow. The comment protects the wait from Reviewer removal
6. **MUST NOT modify `*.helpers.ts` files** — team-owned
7. **MUST NOT modify `output/test-data/shared/`** — immutable
8. **MUST document every fix** in the executor report: what file, what changed, why
9. **MUST NOT change the element target of a scenario step — Semantic Guard.** Before writing any fix that touches a page-object method or spec test.step block, re-read the enriched.md step text for the failing step AND the Explorer's ELEMENT annotation for that step. The fix MAY change pacing, waits, scoping, or selector strategy. The fix MUST NOT change WHICH element the step targets (e.g., scenario says "Select one leaf product" — the fix must not retarget to the category header, the "Select All" checkbox, or any other element). If a fix requires retargeting, that is a scenario-fidelity violation — `test.fixme('UNFIXABLE: fix requires retargeting element, which would violate scenario semantics')` instead.

   **Checklist the Executor MUST run mentally for each fix:**
   - Read the scenario step text (from enriched.md).
   - Read the Explorer ELEMENT annotation's `key` + `primary` for that step.
   - Identify what the fix changes: (a) pacing/wait only, (b) selector strategy on the same target, (c) target element itself.
   - (a) and (b) are allowed. (c) is blocked — escalate instead.

   **Document the guard check in the cycle entry:**
   ```markdown
   - **Semantic Guard:** Step 10 targets the first leaf product checkbox (Explorer key: `anyProductCheckbox`). Fix changes pacing only (adds scrollIntoViewIfNeeded). Target unchanged. ✓
   ```

10. **MUST limit the fix to what is necessary and sufficient for the failing step — Necessary-and-Sufficient Scope.** Every code change the Executor makes MUST be necessary to make the failing step pass given that the user resolves any environment-side issues. **Operational test:** *would this code change still be needed if the user-side root cause were fixed?* If no → out of scope, revert.

    **Explicitly allowed (these ARE the Executor's mandate, not "improvements"):**
    - Adding `// PACING:` waits / extending per-step timeouts on slow components (enterprise apps that load twice, heavy SPAs)
    - Healing a missing locator (see the `web-selector-healing` skill)
    - Changing pacing/scoping/locator strategy on the same logical interaction (per #9 above)
    - Re-pacing an action with `waitFor` to make it deterministic
    - Adding `popupGuard()` / `dismissOverlay()` calls when overlays intercept clicks
    - Editing `output/playwright.config.ts` / `framework-config.json` for missing or incorrect framework-level config (per §3 below)
    - Fixing TypeScript type errors, missing awaits, missing imports, and other compile-blocking issues (existing pre-flight TypeScript-check behavior)

    **Blocked (out-of-scope improvements):**
    - New error-handling logic, diagnostic throws, or custom error messages not required for the failing step
    - Refactors / "while-I'm-here" cleanups
    - New branches / `Promise.race` constructs that change the method's behavioral contract
    - Diagnostic enrichment for failure modes the scenario doesn't test
    - Adding "improvement" code that would still be needed if the actual fix (e.g., setting a missing env var) were applied user-side

    **Why:** the fix scope must match what the failing step actually needs, not what the Executor speculates would be helpful. Out-of-scope "improvements" — diagnostic throws, error wrappers, behavioral guards added to shared methods — frequently regress other scenarios that consume the same code, even when the failing scenario itself appears fixed. Necessary-and-sufficient is the smallest fix that makes the step pass; anything beyond that is Reviewer scope, not Executor scope.

11. **MUST NOT add new `throw` statements to a page-object method during a fix — Throw-Free Page-Object Fixes.** Page-object methods have implicit contracts that other scenarios depend on. Adding new diagnostic throws or watchdog exceptions changes the method's behavior for all consumers, not just the failing scenario.

    **The rule:** No new `throw` statement may be added to a page-object method during a fix.

    **Exempt (these ARE allowed):**
    - **Removing a swallowed catch and surfacing the error.** If the same diff removes a `.catch(() => {})` or `.catch(() => null)` that previously suppressed an error, surfacing that error (which now propagates as the original throw) is allowed. The fix is "stop suppressing", not "add a new throw."
    - **`waitFor` / `expect` calls that throw with Playwright-native messages.** `await locator.waitFor({ state: 'visible', timeout })` may throw on timeout, but with Playwright's native error — not a custom diagnostic message. The method's existing implicit contract already failed on element-absent; explicit `waitFor` just makes the failure earlier and clearer.

    **Operational check — grep the diff for the failing method's body:**
    - Newly-added `throw new Error(...)` → blocked
    - Newly-added `throw <expr>` (any throw statement) → blocked
    - Newly-added `Promise.race([..., watchdog])` where the watchdog branch throws → blocked
    - Newly-added `if (cond) throw ...` → blocked

    **If a behavioral guard genuinely needs to throw, it MUST be a NEW method with a new name** — leaving the existing method's contract untouched for other scenarios that consume it. The new method goes in the same page-object class with a distinct name (e.g., `clickLoginWithAuthErrorDetection()`), and only the scenario that needs the guard calls it. Existing scenarios continue calling the unchanged `clickLogin()`.

    **Why:** page-object methods have implicit contracts that other scenarios depend on. New throws added to a shared method become cross-scenario regressions whenever the watchdog condition coincidentally fires on a different scenario's flow — a `[role=alert]` watchdog meant to detect login-failure also fires on benign notification toasts or session warnings; an `if (!visible) throw` guard meant to handle one missing element fires on every scenario where that element is intentionally absent. The original method's contract was "do the action"; adding "do the action and also throw on X" breaks every consumer that didn't expect X.

---

## 3. File-Edit Scope — HARD BOUNDARIES

**HARD STOP: The Executor MUST check the file path BEFORE editing ANY file. This table defines what the Executor is allowed to touch.**

| Files | Executor Access | Notes |
|-------|----------------|-------|
| `output/tests/**/*.spec.ts` | **Edit** — timing waits, import fixes, assertion structure, ad blocking | Primary fix target |
| `output/pages/*.ts` | **Edit** — interaction method fixes (hover, pressSequentially, wait) | Page object fixes |
| `output/locators/*.json` | **Edit** — selector refinement only (narrow, not wholesale replace) | Selector refinement |
| `output/playwright.config.ts` | **Edit** — timeout values, browser config | **Config changes go HERE** |
| `framework-config.json` | **Edit** — timeout values only | **Config changes go HERE** |
| `output/test-data/{type}/*.json` | **Edit — CONSTRAINED** (see §4 Scenario-Locked Values below) | Data fixes — NOT scenario-stated values |
| `scenarios/app-contexts/*.md` | **Edit** — add discovered patterns | Pacing patterns |
| `output/core/*` | **READ ONLY** | Framework core — NEVER modify |
| `output/pages/*.helpers.ts` | **READ ONLY** | Team-owned — NEVER modify |
| `output/test-data/shared/*` | **READ ONLY** | Cross-scenario — NEVER modify |
| `scenarios/*.md` | **READ ONLY** | User-owned scenario — NEVER modify |
| All other files | **NO ACCESS** | Out of scope for Executor |

**PRE-EDIT GATE — before EVERY file edit:**
1. Check the file path against the table above
2. If file is READ ONLY or NO ACCESS → **STOP**, do NOT edit, document as escalation in the report
3. If file is editable → proceed with the fix

---

## 4. Scenario-Locked Test Data Values — HARD RULE

**The Executor MUST NOT change a test-data JSON value when that value is stated verbatim in the scenario's `## Test Data` table or `## Steps` text.** Changing a scenario-stated value to match what the app actually renders is a guardrail violation: it silently converts a real POTENTIAL BUG into a "green" test that now verifies the wrong thing.

**This rule was added because a real incident (OrangeHRM run, April 2026) showed Executor silently changing `expenseAmount1: "2,100.12"` → `"2100.12"` to make a soft assertion pass, when the scenario explicitly specified the comma-formatted value. The correct response was a `test.fixme('POTENTIAL BUG: ...')` annotation preserving the scenario value.**

**Gate — before editing ANY key in `output/test-data/{type}/*.json`:**

1. **Read the scenario .md file's `## Test Data` table** (and the `## Steps` block where the value may also appear inline).
2. For the key you are about to modify, check: is the current value present verbatim in the scenario?
   - YES → **STOP. DO NOT modify the JSON value.** Instead, fix the spec step: wrap it with `test.fixme('POTENTIAL BUG: scenario says "{expected}", app renders "{actual}" — {description}')` AND add `test.info().annotations.push({ type: 'potentialBug', description: '...' })`. Preserve the original value in both the JSON and the scenario.
   - NO (the key is scenario-internal — e.g., a generated product ID, a CAPTURE'd value, a derived field not in the scenario's Test Data table) → **EDIT is permitted.** Proceed with the fix and document it in the Executor report.

3. **If unsure:** default to NO EDIT. Fix via `test.fixme` pattern.

**What this rule does NOT forbid:**
- Editing keys for scenario-internal derived values not stated in the scenario (e.g., a `sessionId` generated at runtime).
- Adding a brand-new key the scenario didn't define but the spec needs.
- Fixing a typo in a JSON value that is itself a typo in the scenario's Test Data table (document this as a scenario bug report, don't silently "fix").

**Test Data guard evidence:** The review-precheck script surfaces diverged values as `dim9_testDataDivergence` evidence — if the Reviewer sees diverged test-data values without matching `test.fixme` / POTENTIAL BUG annotations in the spec, Dim 9 is capped below 4 and verdict is **NEEDS FIXES**.

---

## 5. Configuration Belongs in Config, NOT in Code — HARD RULE

**Timeouts, browser settings, retry counts, and infrastructure configuration MUST ONLY be set in `output/playwright.config.ts` or `framework-config.json`. NEVER in spec files or page objects.**

| WRONG (in spec — NEVER do this) | RIGHT (in config) |
|----------------------------------|-------------------|
| `test.setTimeout(180000)` | `timeout: 180000` in playwright.config.ts |
| `page.setDefaultTimeout(60000)` | `actionTimeout: 60000` in playwright.config.ts `use` section |
| `{ timeout: 120000 }` on individual actions | `actionTimeout` in playwright.config.ts `use` section |
| `page.setDefaultNavigationTimeout()` | `navigationTimeout` in playwright.config.ts `use` section |

**The ONLY exception:** `// PACING:` waits (`waitForTimeout(N)` with a comment) are permitted in specs because they are step-specific timing for slow components, not global configuration.

**When the Executor encounters a timeout issue:**
1. **First** check `framework-config.json` and `playwright.config.ts` for existing timeout values
2. **Adjust the config value** — NOT the spec
3. **Document:** "Updated playwright.config.ts actionTimeout from X to Y because [reason]"
4. **NEVER** use `test.setTimeout()` or `page.setDefaultTimeout()` in spec files

