---
name: web-codegen-pageobject
description: "How the Builder writes page-object methods: page object structure (extends BasePage), bounded-wait visibility assertions, grid row scoping (strict-mode safe), structural assertions (never data values for existence checks), and chart/graph assertions."
version: "1.0"
---

# web-codegen-pageobject

> Applied by the Builder when generating `output/pages/[{folder}/]{PageName}Page.ts` methods. Covers correct interaction, waiting, and assertion code. (Section numbers preserved from source.)

**TypeScript pattern precedence:** Section 2's typed locator, helper, and logging rules are mandatory for generated TypeScript. Older snippets in later sections may show `this.loc.get(...)` to illustrate assertion semantics only; do not copy that selector-access pattern. For getter methods, calculate the result into a local variable, log completion, then return it so the log remains the final statement.

## 2. Page Object Structure — MANDATORY

**File location:** `output/pages/[{folder}/]{PageName}Page.ts` — when the run has a `folder` parameter, nest the page object under `output/pages/{folder}/` (multi-app isolation; see §2a).

```typescript
import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { loginPageLocators } from '../locators/login-page.locators';
import { clickElementHasBtnLnkLocator, fillElementTxtLocator } from '../utils/abstract-page';
import logger from '../utils/logger';

export class LoginPage extends BasePage {
  private readonly usernameTxt: Locator;
  private readonly loginBtn: Locator;

  constructor(page: Page) {
    super(page, loginPageLocators);
    this.usernameTxt = this.page.locator(loginPageLocators.usernameTxt);
    this.loginBtn = this.page.locator(loginPageLocators.loginBtn);
    logger.info('LoginPage initialized');
  }

  async fillUsername(username: string): Promise<void> {
    await fillElementTxtLocator(this.usernameTxt, username);
    logger.info('Username filled');
  }

  async clickLogin(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.loginBtn);
    logger.info('Login clicked');
  }
}
```

**Rules — MUST follow ALL:**
- **MUST** extend `BasePage`
- **MUST** pass the matching typed locator object to `super()`; the JSON file remains the canonical pipeline artifact
- **MUST** import `Locator` and the page's typed locator object; declare a `private readonly` Locator field for each used element and initialize it in the constructor using `this.page.locator(pageLocators.propertyName)`
- **MUST** use cached Locator fields in methods; do not rebuild `this.page.locator(...)` in method bodies
- **MUST** keep the matching typed `.locators.ts` map synchronized with keys and primary selectors in the page's `.locators.json`
- **MUST** use `clickElementHasBtnLnkLocator(locator)` for clicks and `fillElementTxtLocator(locator, value)` for fills; do not call `.click()` or `.fill()` directly
- **MUST** use `logger.info(...)` as the final statement in every constructor and page-object method, after successful initialization/action/assertion; never log credentials or sensitive input values
- **MUST** place assertions in page-object methods and pass scenario-specific expected values from test-data as method parameters; do not hardcode expected UI text, placeholder text, CSS class patterns, or signs in page classes
- **MUST** keep locator keys and element assertions inside the owning page object; specs call semantic methods such as `verifyEmployeeIdInputVisible()`, never `getLocator('employeeIdInput')`
- Methods MUST be async with descriptive names: `fill*`, `click*`, `get*`, `is*`, `select*`, `wait*`
- Getter methods (for CAPTURE) MUST return the value
- One page object per distinct page/view
- **MUST** check if page object already exists before creating — REUSE existing, ADD methods if needed
- **MUST** check for `*.helpers.ts` files — if `LoginPage.helpers.ts` exists, import `LoginPageWithHelpers as LoginPage` in the spec

### BasePage vs PageObject — Method Placement Binary Test

**Before adding ANY method, apply this test:**

Does the method contain ANY of these?
- A CSS selector or element ID
- `page.locator()` with a specific selector
- `page.evaluate()` with DOM manipulation
- `frameLocator()` for a specific iframe
- `pressSequentially`/`fill`/`click` on a specific element
- Any app-specific or page-specific logic

**If YES → method belongs in `{PageName}Page.ts` (the page object), NOT `core/base-page.ts`.**

**If NO → method is generic and belongs in `core/base-page.ts`.**

BasePage MUST remain generic — it works for ANY app. Page objects contain app-specific logic.

---

## 2a. Foldered Runs — Locator Argument and Import Depth (multi-app)

When the run has a `folder` parameter, the page object nests under `output/pages/{folder}/{PageName}Page.ts`, both locator artifacts nest under `output/locators/{folder}/`, and the spec that imports it nests under `output/tests/{type}/{folder}/`.

1. **The typed locator import carries the folder.** Import the `.locators.ts` map from the matching folder and pass the map to `super()`:

   ```typescript
  // Flat run:     import { loginPageLocators } from '../locators/login-page.locators';
  //               super(page, loginPageLocators);
  // Foldered run: import { loginPageLocators } from '../../locators/atlas/login-page.locators';
  //               super(page, loginPageLocators);
   ```

  Keep the JSON locator file beside the typed map for pipeline discovery and selector auditing. No `core/*` change is needed.

2. **The relative `import` of `BasePage` stays the same depth-wise only because BasePage lives in `output/core/` (never foldered).** From `output/pages/{folder}/{PageName}Page.ts`, the import to core is `../../core/base-page` (one extra `../` versus the flat `../core/base-page`). Count the segments from the page object up to `output/`, then descend into `core/`.

The spec→page-object import depth is covered in the `web-codegen-spec` skill's import-path rule.

---

---

## 17. Visibility Assertions — MUST Have Bounded Wait (MANDATORY — HARD RULE)

**This is the single most common source of flaky tests and Executor cycle waste across enterprise apps (SPAs, server-rendered apps with JS hydration, apps with animated modals, slow-hydrating grids, and anything whose DOM paints after the initial load event).**

### 17.1 The Core Distinction — Snapshot vs Retrying Assertion

Playwright has two different "is this visible?" APIs with very different semantics. Builder MUST use the correct one based on intent:

| Intent (in the scenario) | Correct API | Reason |
|---|---|---|
| "Wait for the X page to load. VERIFY: X is displayed." | Page-object verification method calling the shared state assertion on its cached locator | Retrying assertion — waits up to timeout for the element to render. Correct for VERIFY / VERIFY_SOFT. |
| "VERIFY: X is NOT displayed (after an action)." | `await expect(loc).toBeHidden({ timeout })` or `.not.toBeVisible({ timeout })` | Retrying — waits for the transition. |
| "If optional banner X is present, dismiss it." (existence gate) | `await loc.isVisible().catch(() => false)` | Synchronous snapshot — "is it there RIGHT NOW?" |
| Inside a page-object `is{X}Visible(): Promise<boolean>` helper intended to drive branching control flow | `try { await loc.waitFor({state:'visible', timeout}); return true } catch { return false }` | Wrapped wait — returns bool only after bounded wait, not instant-false |

**HARD RULE: `locator.isVisible()` is a synchronous DOM snapshot — it does NOT wait.** It returns `false` the instant the element is not rendered yet. On any app where the DOM paints after navigation (which is almost all enterprise apps — SPAs, React/Vue/Angular hydration, slow-loading grids, animated transitions), bare `isVisible()` followed by `expect(bool).toBeTruthy()` is the #1 cause of "element not found" Executor cycles.

### 17.2 Spec File — How to Translate VERIFY Visibility Steps

When the scenario says *"VERIFY: Dashboard page is displayed"* or *"Wait for X page to load. VERIFY: X is displayed"*:

```typescript
// ✅ CORRECT — page object owns the cached locator and the assertion
async verifyDashboardHeadingVisible(): Promise<void> {
  await assertElementState(this.dashboardHeadingLbl, 'visible');
  logger.info('Dashboard heading is visible');
}

// Spec calls the semantic page-object method; no locator key in the spec.
await test.step('Step 5 — VERIFY: Dashboard page is displayed', async () => {
  await dashboardPage.verifyDashboardHeadingVisible();
});

// ❌ WRONG — snapshot-based helper; returns false on slow SPA render
// Page object:
async isDashboardHeadingVisible(): Promise<boolean> {
  return await this.page.locator(this.loc.get('dashboardHeading')).isVisible();
}
// Spec:
expect(await dashboardPage.isDashboardHeadingVisible()).toBeTruthy();
```

**Preferred style:** Keep element assertions and locator keys inside the owning page object. The spec calls a semantic method such as `verifyDashboardHeadingVisible()`; the method uses the cached typed locator field and the shared state assertion helper. Do not call `getLocator('key')` from a generated spec.

### 17.3 Page-Object `is{X}Visible()` Helpers — MANDATORY Wrapped Wait

When a page object does need a boolean helper (e.g., to branch on optional widget presence, or because multiple spec steps reuse the same boolean), the helper MUST wrap a bounded `waitFor` — **never** bare `isVisible()`.

```typescript
// ✅ CORRECT — wrapped waitFor; returns false only after real wait
async isDashboardHeadingVisible(timeoutMs?: number): Promise<boolean> {
  try {
    await this.page.locator(this.loc.get('dashboardHeading'))
      .waitFor({ state: 'visible', timeout: timeoutMs ?? 30000 });
    return true;
  } catch {
    return false;
  }
}

// ❌ WRONG — instant-false snapshot; masquerades as a visibility check
async isDashboardHeadingVisible(): Promise<boolean> {
  return await this.page.locator(this.loc.get('dashboardHeading')).isVisible();
}
```

**Timeout source:** read from config, do NOT hardcode in page objects where possible. If BasePage exposes `waitForReady`/`isReady` (added to the BasePage primitives), prefer those — they source the default timeout from one place and are trivially swappable to `expect(...).toBeVisible()` later. If BasePage primitives are not yet available in this project, the inline `waitFor` pattern above is fine.

### 17.4 When Bare `isVisible()` IS Permitted — The Only Exceptions

`locator.isVisible()` with NO wait is correct in exactly two cases:

1. **Existence gates with `.catch(() => false)` — optional element is present RIGHT NOW**, dismiss it if so:
   ```typescript
   const cookieBanner = page.locator('[data-testid="cookie-accept"]');
   if (await cookieBanner.isVisible({ timeout: 3000 }).catch(() => false)) {
     await cookieBanner.click();
   }
   ```
   The `{ timeout: 3000 }` makes this a **bounded** existence check, and `.catch(() => false)` makes it safe when the element is absent. This IS the correct pattern for optional popups, NOT a violation.

2. **Post-wait confirmation on the SAME element** — after a prior `waitFor` or `expect(...).toBeVisible()` on the same element has already succeeded, a subsequent `isVisible()` is purely informational and carries no timing risk.

**Everywhere else:** Use `expect(...).toBeVisible({ timeout })`, `locator.waitFor({ state: 'visible', timeout })`, or a page-object helper that wraps those.

### 17.5 The `isWidgetVisible(key)` Generic Helper — Same Rule

Generic multi-element helpers like `DashboardPage.isWidgetVisible(key)` follow the same rule. If VERIFY_SOFT steps call it, it MUST wait:

```typescript
// ✅ CORRECT
async isWidgetVisible(key: string, timeoutMs = 10000): Promise<boolean> {
  try {
    await this.page.locator(this.loc.get(key)).waitFor({ state: 'visible', timeout: timeoutMs });
    return true;
  } catch { return false; }
}
```

A shorter default timeout (e.g., 10s) is appropriate for VERIFY_SOFT widget checks where a fast-negative is desirable — a widget that isn't visible after 10s almost certainly isn't going to render.

### 17.5a Waiting for Async-Populated Input Values — Vue/React/Angular

Forms in SPA apps commonly render read-only inputs immediately (element present in DOM) but populate their values via an API call 1–3s later. `inputValue()` called on such an input returns `""` — not because the element is missing, but because its value hasn't arrived yet. This is a distinct case from visibility-wait (§17.1–17.5): the element IS visible, only its value is pending.

**MANDATORY idiom:** use Playwright's retrying value assertion directly — it polls until the predicate passes or the timeout elapses.

```typescript
// ✅ CORRECT — one line, uses LocatorLoader, auto-retries
await expect(this.page.locator(this.loc.get('referenceIdField')))
  .not.toHaveValue('', { timeout: 10000 });
return await this.page.locator(this.loc.get('referenceIdField')).inputValue();

// ❌ WRONG — raw DOM query inside waitForFunction, bypasses LocatorLoader (§12.3 here; selector externalization → the web-codegen-locators skill)
await this.page.waitForFunction(
  () => {
    const el = document.querySelector('input.oxd-input[disabled]') as HTMLInputElement | null;
    return el !== null && el.value !== '';
  },
  { timeout: 10000 },
);
```

The `.not.toHaveValue('', ...)` form works for any `<input>`, `<textarea>`, or `<select>` — Playwright retries the read every ~100ms until the value becomes non-empty or the timeout fires. No raw `document.querySelector`, no manual polling loop, selector lives in the JSON.

**When to use this idiom:** read methods on page objects where the source field is a disabled/read-only input whose value loads async (OrangeHRM Vue forms, Salesforce Lightning Locker, Angular reactive forms, Workday). If you're writing a `getX` method that calls `.inputValue()` and you have observed (or suspect) async population, prefix with this wait.

### 17.6 Summary — Builder Decision Tree

```
Scenario step is VERIFY / VERIFY_SOFT on an element's state?
  └── Call a semantic assertion method on the owning page object; it uses the cached locator and a retrying assertion/shared state helper
Page object needs a boolean is{X}Visible() helper?
  └── MUST wrap: try { await loc.waitFor({state:'visible', timeout}); return true } catch { return false }
Scenario step is "if optional X is present, do Y"?
  └── Use: loc.isVisible({ timeout: N }).catch(() => false)   ← bounded existence gate
Anywhere else?
  └── NEVER use bare isVisible()
```

**Executor / Reviewer cross-ref:** the Reviewer's Dim 2 now checks for bare `isVisible()` inside page-object methods whose name starts with `is` and ends with `Visible` or `Hidden`. A single occurrence is a Dim 2 finding. Executor's #1 observed cycle-waster (`expect(await isFooVisible()).toBeTruthy()` with a snapshot-only helper) is thereby caught at review time, not at runtime.

---

## 7. Grid Row Scoping — Avoiding Strict Mode Violations

When interacting with elements INSIDE grid/table rows (buttons, links, checkboxes in a row), Playwright's strict mode will fail with "locator resolved to N elements" if the selector matches across multiple rows.

**MANDATORY: Use two-step scoped locators for in-row elements:**

```typescript
// WRONG — matches the "Edit" button in EVERY row → strict mode violation
await page.locator('button:has-text("Edit")').click();

// CORRECT — scope to the specific row first, then find the element within it
const row = page.locator('tr', { hasText: targetData });
await row.locator('button:has-text("Edit")').click();

// CORRECT — using data-testid row anchor
const row = page.locator(`[data-row-id="${rowId}"]`);
await row.locator('[data-testid="delete-btn"]').click();
```

**Locator JSON for row-scoped elements:**
```json
{
  "dataGrid": {
    "primary": "[data-testid='data-grid']",
    "fallbacks": ["table.data-table", ".grid-container"],
    "type": "table"
  },
  "editButton": {
    "primary": "button:has-text('Edit')",
    "fallbacks": ["[data-testid='edit-btn']", ".btn-edit"],
    "type": "button",
    "scope": "row"
  }
}
```

The `"scope": "row"` field signals that this element MUST be accessed via a row-scoped locator chain, NOT directly. The page object method MUST accept a row identifier:

```typescript
async clickEditInRow(rowText: string): Promise<void> {
  const row = this.page.locator('tr', { hasText: rowText });
  await row.locator(this.loc.get('editButton')).click();
}
```

---

---

## 12. Structural Assertions — NEVER Use Data Values for Existence Checks — MANDATORY

**This is the automation engineer's mindset: verify STRUCTURE to confirm data exists, verify VALUES only when the scenario explicitly names them.**

### 12.1: Data Existence ≠ Data Match

When a scenario says **"widget is visible with data in the grid"**, it means: the grid has rendered and contains rows. It does NOT mean: check if a specific person's name appears.

```typescript
// ❌ WRONG — uses a specific person's name to check data exists. Breaks when data changes.
async isGridDataVisible(): Promise<boolean> {
  return await this.page.locator(this.loc.get('johnSmith')).isVisible();
}

// ✅ CORRECT — checks structural elements for data presence
async isGridDataVisible(): Promise<boolean> {
  const rowCount = await this.page.locator(this.loc.get('gridRows')).count();
  return rowCount > 0;
}

// ✅ ALSO CORRECT — checks that a cell in the first row has text content
async isGridDataVisible(): Promise<boolean> {
  const firstCell = this.page.locator(this.loc.get('gridFirstColumnCells')).first();
  const text = await firstCell.textContent();
  return text !== null && text.trim().length > 0;
}
```

**Rule: If the scenario says "data is visible" / "data is loaded" / "grid has data" — verify ROW COUNT > 0 or FIRST CELL HAS TEXT. NEVER check for a specific name, email, or phone number.**

### 12.2: Sort Verification — Read Dynamically, Don't Hardcode

When the scenario says **"sorted A–Z"** or **"sorted Z–A"**, verify the order programmatically:

```typescript
// ✅ CORRECT — reads all cells and verifies sort order dynamically
async verifyColumnSortedAscending(): Promise<boolean> {
  const cells = await this.page.locator(this.loc.get('gridFirstColumnCells')).allTextContents();
  const trimmed = cells.map(c => c.trim()).filter(c => c.length > 0);
  for (let i = 1; i < trimmed.length; i++) {
    if (trimmed[i].localeCompare(trimmed[i - 1]) < 0) return false;
  }
  return true;
}

// ❌ WRONG — hardcodes the expected first row from Explorer's DISCOVERED notes
expect(firstCell).toBe('Acme Corp'); // breaks when data changes
```

**Exception:** If the scenario ITSELF explicitly names an expected value (e.g., "VERIFY: first row shows 'Admin'"), then hardcoding that value is correct — it's a scenario requirement, not a data dependency.

### 12.3: Pagination — Parameterized Methods, Not Per-Page Methods

**NEVER create individual methods per page number.** An automation engineer builds ONE reusable method:

```typescript
// ❌ WRONG — one method per page, doesn't scale, hardcoded
async clickPageButton1(): Promise<void> { ... }
async clickPageButton2(): Promise<void> { ... }
async waitForPageButton1Active(): Promise<void> { ... }
async waitForPageButton2Active(): Promise<void> { ... }

// ✅ CORRECT — parameterized, reusable, works for any page count
async clickPageButton(pageNumber: number): Promise<void> {
  await this.page.getByRole('button', { name: String(pageNumber), exact: true }).click();
}

async waitForPageActive(pageNumber: number): Promise<void> {
  await expect(this.page.getByRole('button', { name: String(pageNumber), exact: true }))
    .toBeDisabled();
}

async isPageActive(pageNumber: number): Promise<boolean> {
  return await this.page.getByRole('button', { name: String(pageNumber), exact: true }).isDisabled();
}
```

**The spec then reads naturally:**
```typescript
await gridPage.clickPageButton(2);
await gridPage.waitForPageActive(2);
expect(await gridPage.isPageActive(2)).toBe(true);
```

Similarly for pagination with `waitForFunction` — use Playwright's built-in locator waits instead:

```typescript
// ❌ WRONG — raw document.querySelectorAll bypasses locator pattern
await this.page.waitForFunction(() => {
  const buttons = Array.from(document.querySelectorAll('button'));
  const btn = buttons.find(b => b.textContent?.trim() === '2');
  return btn?.disabled === true;
});

// ✅ CORRECT — uses Playwright locator API
await expect(this.page.getByRole('button', { name: '2', exact: true })).toBeDisabled();
```

### 12.4: Widget/Section Visibility — Use Structural Selectors

When verifying multiple widgets or sections exist on a page, use heading/container selectors — not data values inside them:

```typescript
// ❌ WRONG — verifies widget exists by checking if a specific person's name is visible
async isSectionGridDataVisible(): Promise<boolean> {
  return await this.page.locator(this.loc.get('johnSmith')).isVisible();
}

// ✅ CORRECT — verifies widget has rows with data
async isWidgetDataVisible(widgetLocatorKey: string): Promise<boolean> {
  const widget = this.page.locator(this.loc.get(widgetLocatorKey));
  const rows = widget.locator('tbody tr');
  return (await rows.count()) > 0;
}
```

### 12.5: Locator JSON — Structural Entries

When the Builder needs structural locators that weren't explicitly captured as individual ELEMENT annotations (e.g., `gridRows`, `gridFirstColumnCells`), it creates them in the locator JSON based on the structural ELEMENT annotations the Explorer captured (see the `web-element-capture` skill — structural capture). Use descriptive names:

```json
{
  "gridRows": {
    "primary": "tbody tr",
    "fallbacks": ["table tbody tr", ".grid-body tr"],
    "type": "text",
    "notes": "All data rows in the grid table. Used for row count and data existence checks."
  },
  "gridFirstColumnCells": {
    "primary": "tbody tr td:first-child",
    "fallbacks": ["table tbody tr td:nth-child(1)"],
    "type": "text",
    "notes": "First column cells in all grid rows. Used for sort verification."
  }
}
```

### 12.6: Div-Based Table Readers — MANDATORY When `role=row` Is Primary

When an ELEMENT annotation has `"type": "structural"` and its `primary` starts with `role=row`, the underlying element is an ARIA-role container div (common in OrangeHRM, Salesforce Lightning, Kendo/MUI/Ant Design data grids — apps where the table is built from `<div role="table">`, not native `<table><tr><td>`).

**Critical Playwright behavior:** `locator.textContent()` on a `role=row` div returns the container's direct text, which for ARIA divs is typically empty string — content lives in child `div[role="cell"]` elements. This silently produces `""`, which passed through `expect.soft(text).toContain(...)` would make the assertion fail softly forever without investigation.

**Rule — when generating a row-reader method for a `role=row` structural locator:**

```typescript
// ✅ CORRECT — collects text from child cells, works for div-based AND native <tr> tables
async getClaimRowText(rowKey: string): Promise<string> {
  const row = this.page.locator(this.loc.get(rowKey));
  await row.waitFor({ state: 'visible', timeout: this.timeouts?.actionTimeoutMs ?? 30000 });
  // ARIA div-tables: textContent on role=row is empty — collect from child cells
  const cells = await row.locator('div[role="cell"], td').allTextContents();
  return cells.map(c => c.trim()).filter(Boolean).join(' ');
}

// ❌ WRONG — returns "" on ARIA div-based tables; soft assertions then never verify
async getClaimRowText(rowKey: string): Promise<string> {
  return (await this.page.locator(this.loc.get(rowKey)).textContent()) ?? '';
}
```

**Decision rule for the Builder:**
- If primary selector starts with `role=row` → generate the child-cells reader above.
- If primary selector is `tr:has-text(...)`, `tbody tr`, or another native `<tr>` pattern → `.textContent()` is acceptable (native rows have direct text nodes).
- If unsure → default to the child-cells pattern. It works for BOTH native and ARIA tables, so it is the safer default.

This rule exists because a "green" test that reads `""` for every row is worse than a red test — it hides a real assertion gap. See Explorer's "Row-Scoped Interactive Elements" table in the explorer report for row anchors.

---

---

## 6. Chart and Graph Assertions

### SVG Charts (Readable)
SVG charts render as DOM elements — axis labels, data values, and legends are readable via `<text>` nodes:

```typescript
// SVG chart — read data labels
const labels = await page.locator('svg text.data-label').allTextContents();
expect(labels).toContain('Q1: $45,000');
```

### Canvas Charts (NOT Readable)
Canvas charts render as a single bitmap — **NEVER attempt to read pixel data or internal values.** Only these assertions are possible:

```typescript
// Canvas chart — ONLY these are valid
await expect(page.locator('canvas.chart')).toBeVisible(); // chart rendered
const title = await page.locator('.chart-title').textContent(); // title/legend outside canvas
expect(title).toContain('Revenue');
```

**If the scenario requires asserting chart DATA and the chart is Canvas:** Use the API endpoint that feeds the chart. Assert the API response instead of the visual chart. This is more reliable.

**If you cannot determine SVG vs Canvas during exploration:** Take a snapshot. If the element is `<svg>`, it's SVG. If `<canvas>`, it's Canvas. Record this in app-context.

---

