---
name: web-codegen-locators
description: "How the Builder creates locator JSON files from the Explorer's ELEMENT annotations: the locator JSON format, the primary-selector fidelity HARD RULE, merge + quality-floor + _healed preservation, and selector externalization (zero raw selectors in code)."
version: "1.0"
---

# web-codegen-locators

> Applied by the Builder when turning the enriched.md's `<!-- ELEMENT: … -->` annotations into paired `output/locators/[{folder}/]{page-name}.locators.json` and `.locators.ts` artifacts. JSON is canonical for pipeline discovery, merge, healing, and review; the typed TypeScript map mirrors each key's primary selector for page-class runtime use. (Section numbers preserved from source.)

The paired `.locators.ts` map is required for TypeScript output. For other configured language profiles, retain the canonical JSON and follow that language's locator representation; do not generate TypeScript-only page-class syntax.

## 1. Locator JSON Format — MANDATORY for ALL Web/Hybrid Scenarios

Every element you interact with MUST have an entry in a locator JSON file.

**File locations:** `output/locators/[{folder}/]{page-name}.locators.json` and `output/locators/[{folder}/]{page-name}.locators.ts` — when the run has a `folder` parameter, nest both under `output/locators/{folder}/`, matching the page object's folder. JSON merge, cross-run reuse checks, and `_healed` preservation operate on JSON; update the typed map to match the merged primary selectors. Page classes import and pass the typed map to `super()` (see `web-codegen-pageobject` §2a).

**Format — EVERY entry MUST have primary + at least 2 fallbacks + type + fingerprint:**

```json
{
  "submitButton": {
    "primary": "role=button[name='Submit']",
    "fallbacks": [
      "[data-testid='submit-btn']",
      "#submit-button"
    ],
    "type": "button",
    "fingerprint": {
      "tag": "button",
      "id": null,
      "testId": "submit-btn",
      "text": "Submit",
      "cssPath": "form > button"
    }
  },
  "usernameInput": {
    "primary": "label=Username",
    "fallbacks": [
      "[data-testid='username']",
      "input[name='username']"
    ],
    "type": "input",
    "fingerprint": {
      "tag": "input",
      "id": "username",
      "testId": "username",
      "text": null,
      "cssPath": "form > input:nth-of-type(1)"
    }
  }
}
```

**Rules — NO EXCEPTIONS:**
- Primary selector = extracted from the Explorer's `<!-- ELEMENT: {...} -->` annotation (`primary` field). The Explorer captured this from the MCP snapshot or DOM probe during live exploration. Use semantic prefixes (`role=`, `label=`, `testid=`, `text=`) — the LocatorLoader resolves them automatically
- **MUST** include at least 2 fallback selectors (from the ELEMENT annotation's `fallbacks` array)
- **MUST** include `type` field (`input` | `button` | `link` | `select` | `checkbox` | `radio` | `text` | `image` | `structural`) — helps Reviewer verify correct interaction patterns
- **MUST** include `fingerprint` field (all five sub-fields: `tag`, `id`, `testId`, `text`, `cssPath` — preserve `null` for absent fields). Used by the `web-element-capture` skill's cross-run key reuse check to deduplicate semantically-identical elements across scenarios
- Use descriptive camelCase element names (from the ELEMENT annotation's `key` field)
- One locator file per page object
- **NEVER** put selector literals directly in page objects or spec files; page objects initialize cached Locator fields from the typed map
- Selector priority (set by the Explorer during capture): data-testid > stable ID > href > native role+text > text > CSS. The Builder uses exactly what the Explorer captured — do NOT override.

**Backward compatibility:** existing locator JSONs that predate the `fingerprint` requirement remain valid — the LocatorLoader ignores the field and the Explorer's cross-run reuse check skips entries without a fingerprint. The Builder MUST write `fingerprint` on all new and updated entries; older entries get fingerprints written on their next merge.

---

### Extract ELEMENT Annotations and Create Locator JSONs — MANDATORY

**The Builder creates locator JSON and matching typed TypeScript locator files from the `<!-- ELEMENT: {...} -->` annotations in the enriched.md.** This is the first step of code generation.

**For each page section in the enriched.md:**

1. **Collect all ELEMENT annotations** belonging to that page (matching `"page": "PageName"`)
2. **Create/update both locator artifacts** at `output/locators/{page-name}.locators.json` and `output/locators/{page-name}.locators.ts`
3. **Map each ELEMENT to a locator entry:**

```json
// From: <!-- ELEMENT: {"page":"LoginPage","key":"signupButton","primary":"role=button[name='Signup']","fallbacks":["testid=signup-btn","button[type='submit']"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":"signup-btn","text":"Signup","cssPath":"#form > button"}} -->
// To: output/locators/login-page.locators.json
{
  "signupButton": {
    "primary": "role=button[name='Signup']",
    "fallbacks": ["testid=signup-btn", "button[type='submit']"],
    "type": "button",
    "fingerprint": {"tag":"button","id":null,"testId":"signup-btn","text":"Signup","cssPath":"#form > button"}
  }
}
```

**Page name → file name mapping:** `LoginPage` → `login-page.locators.json`, `ServicerHomePage` → `servicer-home-page.locators.json` (PascalCase → kebab-case).

**Primary-selector fidelity — HARD RULE:** The `primary` field in the locator JSON MUST be copied **verbatim** from the ELEMENT annotation's `primary` field. You MUST NOT reorder from the fallbacks, substitute a CSS alternative, or "improve" the primary. The Explorer used that exact selector to click/fill the element in the live browser — it is proven to work. Demoting it in favor of an untested CSS guess is the #1 cause of "element not found" Executor cycles on apps with non-standard table markup (ARIA div-tables, shadow DOM, Vue-bound inputs).

- Explorer's `primary` → locator JSON `primary` (byte-for-byte identical)
- Explorer's `fallbacks` (array, in order) → locator JSON `fallbacks` (same order)
- Explorer's `type` → locator JSON `type`
- Explorer's `fingerprint` → locator JSON `fingerprint` (verbatim, all five fields preserved including `null` values). Required for the `web-element-capture` skill's cross-run key reuse check.

If the Explorer's `primary` looks "odd" to you (e.g., `role=row[name*='12345']` instead of the `tr:has-text(...)` you'd expect), **that's Explorer telling you the app does NOT have standard `<tr>` markup**. Preserve the selector Explorer actually used. See the `web-codegen-pageobject` skill for div-based table readers.

**Fallbacks MUST be STRUCTURAL — never scenario-specific data — HARD RULE.** A fallback selector exists to find the *same UI element* when the primary strategy breaks across app versions. It must therefore key on the element's **structure or stable identity** (tag, role, `data-testid`, stable id, ARIA attribute, stable class name, structural position), NOT on the **scenario's runtime data** (a record name, silo/org name, an order number, a username, a date, a status value, or any value that came from the scenario's test-data or a CAPTURE).

A data-baked fallback is a silent landmine: it passes for the one scenario whose data happens to match, then mis-resolves (or resolves to the wrong row) the moment the data changes or another scenario reuses the page — exactly the failure the fallback was supposed to prevent.

```jsonc
// ❌ WRONG — fallback baked with scenario data ("Automation_Silo" is a record value, not structure)
"siloRow": {
  "primary": "role=row[name*='Automation_Silo']",
  "fallbacks": ["tr:has-text('Automation_Silo')", "[data-testid='silo-row']"],
  "type": "structural"
}

// ✅ CORRECT — primary may carry the runtime value (Explorer used it live); fallbacks stay structural
"siloRow": {
  "primary": "role=row[name*='Automation_Silo']",
  "fallbacks": ["[data-testid='silo-row']", "tbody[role='rowgroup'] tr"],
  "type": "structural"
}
```

The **primary** MAY contain a runtime value when that is genuinely how the Explorer located the element live (and the dynamic-value pattern in §11.1 governs runtime-templated access in code) — but the element is then row-scoped at call time via `.filter({ hasText: <value> })` in the page object (see the `web-codegen-pageobject` row-scoping rules), and the JSON's fallbacks still hold structural selectors only.

**Builder rule — apply on every fallback you write or merge:** if a fallback string embeds a literal that equals (or is derived from) a value in the scenario's test-data, a CAPTURE variable, or a scenario-stated record/identifier, DROP it and substitute a structural fallback (or, if none is available, leave only the genuinely-structural fallbacks and note the gap in the builder report). When the Explorer's ELEMENT annotation itself supplied a data-baked fallback, the Builder strips it during extraction — Explorer's `primary` is preserved verbatim (the fidelity rule above), but `fallbacks` are sanitized to structural-only.

**Reviewer cross-ref (Dim 1 — Locator Quality):** a fallback whose selector embeds scenario data is a Dim 1 finding.

**If a locator file already exists** (from a previous run or another scenario), READ it first and MERGE — add new keys, update existing keys with fresh Explorer data, but **preserve any key that has `"_healed": true`** (Executor-refined selectors). The `_healed` field means the Executor discovered this selector at runtime — it is proven to work and MUST NOT be overwritten with Explorer data. Only healed entries have this field; non-healed entries simply omit it.

**Quality-floor on `primary` during merge — MANDATORY when an existing entry's primary is semantic and the new capture's primary is structural-positional.**

When merging a new ELEMENT capture against an existing locator entry on the same page+key (and the existing entry does NOT have `_healed: true` — that takes precedence):

1. **Existing primary is semantic** if it contains any of: `role=` prefix, `label=` prefix, `testid=` prefix, `text=` prefix, an ARIA attribute selector (`[aria-label=`, `[aria-*=`), a `data-testid` attribute selector, OR a class selector (`.classname`) where the class name is alphabetic-with-hyphens (no digits, no auto-generated hash patterns like `_abc123`). AND
2. **New primary is structural-positional** if ALL of these hold: contains `:nth-of-type(` OR `:nth-child(`, AND has **≥4** `>` direct-child combinators in the chain, AND contains NONE of the semantic anchors listed in (1).

If both (1) and (2) hold:

- **Keep the existing `primary` unchanged.**
- **Insert the new capture's primary as the first entry of `fallbacks`** (deduplicate against existing fallbacks — if already present, leave fallback order unchanged).
- Update the rest of `fallbacks`, `type`, and `fingerprint` from the new capture as usual.
- Record in the builder report: `primary preserved for {key} on {page-file} — new capture was structural-positional (depth-{N} >-chain with nth-{type|child}), existing semantic primary kept.`

If the rule does NOT fire (either side fails its predicate), the standard merge applies — the new capture's `primary` replaces the existing one.

**Recovery if the preserved primary is genuinely broken:** the Executor agent's heal loop (Trigger A on element-not-found, Trigger B on same-root-cause-for-2-cycles) discovers a working selector at runtime and writes `_healed: true`. From that point on, neither this rule nor the standard merge will overwrite it.

**Why:** prevents a later scenario's deep-positional capture (e.g., a 5-level `>`-chain ending in `:nth-of-type(N)`) from silently replacing a stable semantic primary (e.g., a class-based selector with a meaningful class name) for the same element. The brittle positional path still travels into `fallbacks` so it remains reachable. The 5+-level `>`-chain pattern is the textbook brittle-selector anti-pattern: every level must match exactly, and the `nth-*` index assumes a sibling order that may not hold across views.

**If a step has no ELEMENT annotation and no BLOCKED flag**, it may be a navigation step, SCREENSHOT, CALCULATE, or REPORT step that doesn't interact with an element — this is normal.

---

## 14. Locator JSON Creation — How the Builder Extracts Element Data

**The Builder does NOT use MCP or open a browser.** All element selectors come from `<!-- ELEMENT: {...} -->` annotations that the Explorer embedded in the enriched.md during live browser exploration.

**The Builder's first task is to extract these annotations and create locator JSON files:**

```json
// Extracted from enriched.md ELEMENT annotations → output/locators/login-page.locators.json
{
  "signupEmailInput": {
    "primary": "testid=signup-email",
    "fallbacks": ["input[name='email']", "#signup-email"],
    "type": "input"
  }
}
```

The Builder generates page classes that initialize cached Locator fields from the matching typed locator map. If a step has `<!-- ELEMENT_CAPTURE_FAILED -->`, generate `test.fixme('ELEMENT CAPTURE FAILED: ...')`.

**Every locator entry traces back to an ELEMENT annotation.** The Builder does not invent selectors. If the Explorer didn't capture an element, the Builder cannot create a locator for it.

---

---

## 11. Selector Externalization — HARD STOP

**Every selector MUST be represented in the locator JSON and its matching typed TypeScript map.** JSON remains canonical for pipeline tools; the TS map is the runtime source used by page classes.

- Page objects initialize `private readonly Locator` fields in constructors from typed-map properties, then reuse those fields — NEVER embed selector literals in page classes
- Spec files NEVER contain selectors — they call page object methods
- Every JSON key must have a matching typed-map property whose value equals that entry's `primary`; retain JSON fallbacks, type, fingerprint, and `_healed` metadata for pipeline consumers

If you find yourself writing a selector directly in a page object or spec file — **STOP. Move it to the locator JSON first.**

### Typed-Map Locator Initialization — MANDATORY

**Every element-backed `page.locator()` call in a page object MUST be in the constructor and use the matching typed-map property.** Store it in a `private readonly Locator` field. Direct CSS/XPath literals in a page class bypass selector externalization.

**Exception — row-scoped chaining:** When operating on a specific row within a table, list, or grid, the page object MAY chain structural `.locator()` and `.filter()` calls from a cached typed-map Locator:

```typescript
// CORRECT — cached Locator field from the typed map, structural row scoping inline
async getProductPrice(productName: string): Promise<string> {
  const table = this.cartTable;
  const row = table.locator('tbody tr').filter({ hasText: productName });
  return (await row.locator(cartPageLocators.cartProductPrice).textContent()) ?? '';
}
```

The base element (`cartTable`) and target element (`cartProductPrice`) come from the typed map and matching JSON. Only structural scoping (`.locator('tbody tr').filter()`) is inline.

### 11.1 Dynamic-Value Locator Pattern — PERMITTED (clarification of "no raw selectors")

The "no raw selectors" rule means **no literal hardcoded selector strings in TypeScript code.** It does **NOT** forbid selectors that template a runtime value into a structural pattern. The distinction:

- **Raw selector (FORBIDDEN):** `await page.locator('//button[@id="submit-1234"]')` — literal string, no runtime variable, should be `submitButton` in the JSON.
- **Dynamic-value selector (PERMITTED with conditions below):** `` await this.driver.$(`//*[@text='${dayNorm}']`) `` — structure is fixed (`//*[@text='…']`), only the value is computed at runtime.

**When you MAY use a dynamic-value selector inline in a page/screen object** (ALL of the following must hold):

1. **The element identity depends on a runtime value** — today's date, a CAPTURE'd order number, a user-provided dropdown option, a parameterized test-data value. The value cannot be known when the locator JSON is written.
2. **The structural part of the selector is fixed.** Only the value field changes; the strategy (xpath template, UiSelector chain, role-based query) is constant.
3. **The construction is wrapped in a page/screen object method, never in the spec.** Specs call methods like `await screen.tapReasonOption(value)` — they do NOT construct selectors themselves.
4. **The method documents the dynamic value with a `// FRAGILE:` or `// DISCOVERED:` comment** explaining why the static pattern can't be captured as a locator JSON key.
5. **The corresponding static element has a related entry in the locator JSON.** E.g., for "Tap Reason dropdown then select option by value", the `reasonDropdown` itself is a static locator JSON key; only the option-cell selection uses the dynamic value.

**Examples — acceptable:**

```typescript
// Mobile — dynamic dropdown option (value at runtime)
async selectReason(value: string): Promise<void> {
  await this.tap('reasonDropdown');  // static — JSON key
  // FRAGILE: dropdown options are listed at runtime; value parameterizes the
  // selector. Static reasonDropdown is in event-change-adjust-form.locators.json.
  const option = await this.driver.$(`android=new UiSelector().text("${value}")`);
  await option.click();
}

// Mobile — today's date in a custom WebView calendar
async selectCurrentDay(): Promise<void> {
  // FRAGILE: day cells use @text=<dayNum-without-leading-zeros>; the WebView
  // does not expose stable resource-ids. dayNorm computed at runtime.
  const dayNorm = String(new Date().getDate());
  const dayCell = await this.driver.$(`//*[@text='${dayNorm}']`);
  await dayCell.click();
}

// Web — element identified by CAPTURE'd order number
async openCapturedOrder(orderNumber: string): Promise<void> {
  // FRAGILE: order number captured at runtime; structure is fixed.
  // Static orderRow base is in cart-page.locators.json.
  const row = this.orderRow.filter({ hasText: orderNumber });
  await row.click();
}
```

**Examples — NOT acceptable (still raw selector violations):**

```typescript
// Hardcoded literal — belongs in JSON
await this.driver.$('//*[@text="On Time"]');   // ❌ "On Time" is fixed, not dynamic

// Constructed-but-not-actually-dynamic — still hardcoded under template syntax
const fixedName = "Submit";
await this.driver.$(`//button[@aria-label='${fixedName}']`);  // ❌ fixedName never changes

// Inline in spec
await page.locator(`[data-testid='${productId}']`).click();  // ❌ belongs in page object
```

**Reviewer Dim 1 implications:** Dynamic-value selectors that meet ALL five conditions above are NOT counted as raw-selector violations. Selectors that violate ANY condition (especially #1 — value isn't actually dynamic, or #3 — construction in spec) ARE counted.

**Builder self-audit (§5 in the Builder agent):** When grepping for raw selectors, the Builder MUST distinguish:
- Inline `driver.$(\`...${variable}...\`)` or `page.locator(\`...${variable}...\`)` — check the five conditions; report PERMITTED if all hold, RAW VIOLATION if any fail
- Inline `driver.$('...')` or `page.locator('...')` with NO template variable — always RAW VIOLATION, move to JSON

---

