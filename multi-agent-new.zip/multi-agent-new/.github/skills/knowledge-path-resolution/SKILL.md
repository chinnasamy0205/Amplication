---
name: path-resolution
description: "Single source of truth for all qe-automation file paths: scenario inputs, generated-project outputs (specs/pages/locators/test-data/config/core), reports, metrics, transient/gitignored files, the canonical test-execution command, and the delivered script commands. Every agent resolves paths from here instead of hardcoding them."
version: "1.0"
---

# Path Resolution — Single Source of Truth

**MANDATORY: All agents MUST use these path patterns. DO NOT hardcode paths — look them up here. If a path changes, update THIS file and all agents automatically use the new path.**

The `[{folder}/]` segment is included whenever the run has a `folder` parameter; omit it when `folder` is unset.

**The `[{folder}/]` segment applies uniformly to ALL per-app generated artifacts — specs, reports, metrics, AND page objects, locators, and scenario test-data.** This keeps every app's generated code self-contained under its own folder, so two apps that both have (e.g.) a `LoginPage` never collide. The runtime loaders accept the folder transparently: the page object passes the foldered locator path to `super()` (`super(page, '{folder}/login-page.locators.json')`) and `loadTestData('{type}/{folder}/{scenario}', …)` carries the folder in its path argument — no `core/*` changes are needed (see the `web-codegen-*` skills for the exact codegen + relative-import rules). Shared, cross-app artifacts are NEVER foldered: `output/test-data/shared/`, `output/core/*`, and `output/locators/mobile/` stay flat.

---

## Scenario Input Paths

| Type | Pattern |
|------|---------|
| web | `scenarios/web/{scenario}.md` or `scenarios/web/{folder}/{scenario}.md` |
| api | `scenarios/api/{scenario}.md` or `scenarios/api/{folder}/{scenario}.md` |
| hybrid | `scenarios/hybrid/{scenario}.md` or `scenarios/hybrid/{folder}/{scenario}.md` |
| mobile | `scenarios/mobile/{scenario}.md` or `scenarios/mobile/{folder}/{scenario}.md` |
| Swagger specs | `scenarios/api/swagger-specs/{spec}.json` (raw) / `{spec}.parsed.json` (parsed) |
| Enriched scenarios | `scenarios/{type}/[{folder}/]{scenario}.enriched.md` (created by Explorer, user-owned after first creation) |
| App-contexts | `scenarios/app-contexts/{app-identifier}.md` (created by Explorer, updated by Executor) |

---

## Output Paths (Generated Test Project)

| File Type | Pattern |
|-----------|---------|
| Spec files | `output/tests/{type}/[{folder}/]{scenario}.spec.ts` |
| Page objects | `output/pages/[{folder}/]{PageName}Page.ts` |
| Helper files | `output/pages/[{folder}/]{PageName}Page.helpers.ts` (team-owned, read-only) |
| Locator JSONs | `output/locators/[{folder}/]{page-name}.locators.json` (created by Builder from Explorer ELEMENT annotations) |
| Mobile locators | `output/locators/mobile/{screen-name}.locators.json` (mobile is never foldered — platform dimension lives in the file) |
| Screen objects | `output/screens/{ScreenName}Screen.ts` (mobile) |
| Test data (scenario) | `output/test-data/{type}/[{folder}/]{scenario}.json` |
| Test data (shared) | `output/test-data/shared/{dataset}.json` (immutable) |
| Shared state | `output/test-data/shared-state.json` (runtime, gitignored) |
| External datasets | `output/test-data/datasets/{file}.csv` / `{file}.xlsx` / `{file}.json` |
| Config | `output/playwright.config.ts`, `output/tsconfig.json` |
| Package | `output/package.json` |
| Core framework | `output/core/base-page.ts`, `locator-loader.ts`, `test-data-loader.ts`, `shared-state.ts` |
| Grid utils | `output/utils/csv-grid-compare.ts`, `output/utils/grid-row-collector.ts` |
| Language profiles | `languages/{typescript\|javascript\|python}.profile.json` (project root — read by the Builder for the selected language) |
| Environment | `output/.env` (gitignored — real values; copied from `output/.env.example`; also `.env.qa.example`/`.env.stg.example`) |
| MCP config examples | `mcp/` (project root — per-IDE Playwright MCP config templates + `mcp/README.md`; user copies the right one to their IDE's MCP path) |
| Framework config | `framework-config.json` (project root — seeded by the setup-agent / qe-install; agents read `executor.maxCycles`, `exploration.maxAttemptsPerStep`, `timeouts.*`, `appContext.{type}`, etc.) |
| Auth state | `output/auth/storage-state.json` (gitignored — contains tokens) |

---

## Report Paths

| Report | Pattern |
|--------|---------|
| Enrichment report | `output/reports/[{folder}/]enrichment-report-{scenario}.md` |
| Explorer report | `output/reports/[{folder}/]explorer-report-{scenario}.md` |
| Builder report | `output/reports/[{folder}/]builder-report-{scenario}.md` |
| Executor report | `output/reports/[{folder}/]executor-report-{scenario}.md` |
| Review scorecard | `output/reports/[{folder}/]review-scorecard-{scenario}.md` |
| Healer report | `output/reports/[{folder}/]healer-report-{scenario}.md` |
| Precheck report | `output/reports/[{folder}/]precheck-report-{scenario}.json` |
| Pipeline summary | `output/reports/[{folder}/]pipeline-summary-{scenario}.md` |

---

## Metrics Paths

| Metric | Pattern |
|--------|---------|
| Per-agent metrics | `output/reports/metrics/{agent}-metrics-{scenario}.json` (enrichment, explorer, builder, executor, reviewer, healer, orchestrator) |
| Pipeline metrics | `output/reports/metrics/pipeline-metrics-{timestamp}.json` |
| Eval summary | `output/reports/metrics/eval-summary-{scenario}.json` |
| Stability history | `output/test-results/test-stability-history.json` |

---

## Transient Paths (Gitignored)

| File | Pattern | Purpose |
|------|---------|---------|
| Playwright results | `output/test-results/results.json` | Raw JSON reporter output |
| Parsed results | `output/test-results/last-run-parsed.json` | Structured failure data |
| Error context | `output/test-results/error-context.md` | DOM snapshot at failure |
| Failure screenshots | `output/test-results/test-failed-*.png` | Visual state at failure |
| HTML report | `output/playwright-report/` | Playwright HTML report |
| Classified changeset | `output/reports/classified-changeset.json` | From scenario-diff.js (section-aware diff + classification) |
| Builder instructions | `output/reports/builder-instructions.json` | From builder-incremental.js (FIRST_RUN/INCREMENTAL/NO_CHANGES mode) |

---

## Script Commands (delivered with the stack — under `scripts/` at the project root)

| Script | Command |
|--------|---------|
| Scenario diff (incremental detection) | `node scripts/scenario-diff.js --scenario={path} --spec={path} --output=output/reports/classified-changeset.json` |
| Builder incremental (annotate + instructions) | `node scripts/builder-incremental.js --scenario={scenario} --type={type} [--folder={folder}]` |
| Cleanup annotations (post-Builder) | `node scripts/cleanup-annotations.js --file={enriched.md path}` |
| Explorer post-check | `node scripts/explorer-post-check.js --scenario={scenario} --type={type} [--folder={folder}]` |
| Review precheck | `node scripts/review-precheck.js --scenario={name} --type={type} [--folder={folder}]` |
| Parse test results | `node scripts/test-results-parser.js --results-dir=output/test-results` |
| Swagger parser | `node scripts/swagger-parser.js --spec={path} [--output={path}]` |
| Failure classifier | `node scripts/failure-classifier.js --results={path} [--scenario={name}]` |
| Metrics collector | `node scripts/metrics-collector.js --run-type={pipeline\|nightly}` |
| Eval summary | `node scripts/eval-summary.js --scenario={name} [--folder={folder}]` |

---

## Test Execution Command

```bash
cd output && npx playwright test tests/{type}/[{folder}/]{scenario}.spec.ts --project=chrome --reporter=json,list
```

**MUST specify the exact spec file.** NEVER run `npx playwright test` without a file path — it executes ALL tests.

---

## Platform Notes

- ALL paths use forward slashes in this document for readability
- In code, **MUST** use `path.join()` — NEVER hardcode `/` or `\`
- Windows: use `npm.cmd`/`npx.cmd` instead of `npm`/`npx`

