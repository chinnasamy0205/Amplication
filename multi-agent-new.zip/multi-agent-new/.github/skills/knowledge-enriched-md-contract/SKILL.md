---
name: enriched-md-contract
description: The contract for the Explorer's enriched.md output — page-section headers + the variable-path rule, provenance tags, ELEMENT annotation JSON schema, DISCOVERED notes (behavior not data values), key-naming, and the Detail Level / App Behavior headers. The Explorer produces it; the Builder consumes it.
version: "1.0"
---

# enriched-md-contract

> The `*.enriched.md` is a scenario file for humans AND the routing table for the Builder. This convention defines its exact shape. The **Explorer** writes it; the **Builder** reads it. (Section numbers preserved from source for internal cross-reference.)

## 5. Enriched.md — MANDATORY Output

### Creation Rules

| Condition | Mode | Action |
|-----------|------|--------|
| `{scenario}.enriched.md` does NOT exist | FULL | **MUST create it** |
| `{scenario}.enriched.md` exists, NO changeset | FULL | **MUST NOT modify it** — user owns it. Read it as input only |
| `{scenario}.enriched.md` exists, changeset present | INCREMENTAL | **Update in-place** — only update annotations for DEEP-verified steps. Preserve all existing annotations for FAST/SKIP steps. |

Save to: `scenarios/{type}/[{folder}/]{scenario}.enriched.md`

### Content Rules — HARD STOP

**The enriched.md is a SCENARIO file for humans AND a routing table for the Builder. It describes WHAT to test with page-step mappings and embedded element data.**

**MUST include:**
- Page section headers mapping steps to pages (e.g., `### LoginPage (/login)`)
- Provenance tags on every step (`<!-- ORIGINAL -->`, `<!-- EXPANDED -->`, `<!-- DISCOVERED -->`)
- `<!-- ELEMENT: {JSON} -->` annotations for every interacted element (built via the `web-element-capture` skill)
- `<!-- BLOCKED: reason -->` for steps that couldn't be verified
- `<!-- DISCOVERED: behavioral note -->` for UI behavior the Builder needs to understand (HOW things work, NOT data values)

**MUST NOT include:**
- Playwright code or wait strategies
- Page object method names or code patterns
- Data values from the grid/table as expected assertion values (see Section 5.1)

### 5.1: DISCOVERED Notes — Behavior Only, Never Data Values

`<!-- DISCOVERED: ... -->` notes inform the Builder about HOW the UI works. They must describe UI behavior, NOT specific data values:

**CORRECT — describes behavior:**
```markdown
<!-- DISCOVERED: Sort arrows are SVG elements inside th. Active sort arrow has fill="#E52020" (red), inactive has fill="#003B5C" (blue). -->
<!-- DISCOVERED: Filter is a custom multi-checkbox tooltip panel, not a native HTML select. -->
<!-- DISCOVERED: Pagination buttons become disabled when their page is active. Grid re-renders in-place (no URL change). -->
```

**WRONG — describes data values (DO NOT do this):**
```markdown
<!-- DISCOVERED: First row shows "John Smith" -->
<!-- DISCOVERED: Sorted descending: Zebra Inc → Omega Ltd → Alpha LLC -->
<!-- DISCOVERED: Grid has 52 total entries -->
```

### 5.2: ELEMENT Annotation Format

Every `<!-- ELEMENT: {...} -->` annotation MUST be valid JSON with these fields:

```json
{
  "page": "PageName",
  "key": "descriptiveCamelCaseKey",
  "primary": "the primary selector string",
  "fallbacks": ["fallback1", "fallback2"],
  "type": "button|input|link|select|checkbox|radio|text|image|structural",
  "fingerprint": {
    "tag": "button",
    "id": "submit-btn",
    "testId": "submit-btn",
    "text": "Submit",
    "cssPath": "#form > button:nth-of-type(1)"
  }
}
```

**Key naming rules:**
- Use descriptive camelCase: `signupLoginLink`, `passwordInput`, `sortAscendingArrow`
- For structural selectors: `gridRows`, `firstColumnCells`, `specialtyColumnCells`
- NEVER use data values as key names (no `cathyKuehl`, no `8473856808P`)
- Keys must be unique within a page

### Detail Level Header

```markdown
## Detail Level: EXPLORER-VERIFIED
Steps verified during live exploration on {date}.
Element data captured from the accessibility snapshot (role, name, href) with DOM probe fallback for non-accessible elements.
Page sections map steps to pages for the Builder agent.
ORIGINAL/EXPANDED/DISCOVERED tags show provenance.
User may edit this file. Explorer will NOT modify it on future runs.
```

### App Behavior Header — MANDATORY (see §4.8a)

```markdown
## App Behavior: {spa-async | server-rendered | hybrid-hydration | unknown}
{One or two sentences summarizing rendering timing observed during exploration,
including the specific post-action transitions that informed the classification.}
```

The App Behavior header MUST appear after `## Detail Level` and before `## Common Setup`. Missing it on a web scenario is a Builder ambiguity — Builder defaults to `spa-async` (safer) and the Explorer report notes the omission.

### Example

```markdown
## Detail Level: EXPLORER-VERIFIED
Steps verified during live exploration on 2026-04-20.
...

## App Behavior: spa-async
Route URL changes instantly on navigation; landmark elements render 1–3s later.
Observed on login → /dashboard (2s) and Claim nav → /claim/viewAssignClaim (2s).
Builder: implement VERIFY assertions in the owning page object's semantic method using
a bounded retrying assertion; use waitForURL+landmark for post-click navigation and
avoid waitForLoadState('networkidle') — analytics prevent it.

## Steps

### LoginPage (/login)
1. Navigate to {{ENV.BASE_URL}} <!-- ORIGINAL -->
2. Click on "Signup / Login" link <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"LoginPage","key":"signupLoginLink","primary":"text=Signup / Login","fallbacks":["a[href='/login']","role=link[name='Signup / Login']"],"type":"link","fingerprint":{"tag":"a","id":null,"testId":null,"text":"Signup / Login","cssPath":"#header > nav > ul > li:nth-of-type(4) > a"}} -->
3. Enter "QA Demo" as name in signup form <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"LoginPage","key":"signupNameInput","primary":"testid=signup-name","fallbacks":["input[name='name']","#name"],"type":"input","fingerprint":{"tag":"input","id":"name","testId":"signup-name","text":null,"cssPath":"#form > input:nth-of-type(1)"}} -->
4. Click "Signup" button <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"LoginPage","key":"signupButton","primary":"role=button[name='Signup']","fallbacks":["testid=signup-btn","button[type='submit']"],"type":"button","fingerprint":{"tag":"button","id":null,"testId":"signup-btn","text":"Signup","cssPath":"#form > button"}} -->

### DashboardPage (/dashboard)
5. VERIFY: Dashboard heading is visible <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"DashboardPage","key":"dashboardHeading","primary":"role=heading[name='Dashboard']","fallbacks":["h1:has-text('Dashboard')","testid=dashboard-title"],"type":"text","fingerprint":{"tag":"h1","id":null,"testId":"dashboard-title","text":"Dashboard","cssPath":"#content > h1"}} -->
6. VERIFY: Data grid is visible with data <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"DashboardPage","key":"gridRows","primary":"tbody tr","fallbacks":["table tbody tr",".grid-body tr"],"type":"structural","fingerprint":{"tag":"tr","id":null,"testId":null,"text":null,"cssPath":"#data-grid > table > tbody > tr"}} -->
   <!-- DISCOVERED: Grid uses standard HTML table. Rows load async after page load — Builder use waitFor on gridRows or waitForURL on the page route; do NOT default to networkidle. -->
```

---

### 4.8: Record Page Transitions

When you navigate to a new page (URL changes or significant DOM change), record it as a **section header** in the enriched.md. This creates the routing table the Builder uses:

```markdown
### LoginPage (/login)
1. Navigate to {{ENV.BASE_URL}} <!-- ORIGINAL -->
2. Click on "Signup / Login" link <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"LoginPage","key":"signupLoginLink","primary":"text=Signup / Login","fallbacks":["a[href='/login']","role=link[name='Signup / Login']"],"type":"link","fingerprint":{"tag":"a","id":null,"testId":null,"text":"Signup / Login","cssPath":"#header > nav > ul > li:nth-of-type(4) > a"}} -->

### SignupPage (/signup)
5. Enter password <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"SignupPage","key":"passwordInput","primary":"testid=password-field","fallbacks":["input[name='password']","#password"],"type":"input","fingerprint":{"tag":"input","id":"password","testId":"password-field","text":null,"cssPath":"#form > input:nth-of-type(3)"}} -->
```

**Page naming convention:** Use PascalCase page names that describe the page's purpose (e.g., `LoginPage`, `DashboardPage`, `CheckoutPage`). These become the page object class names in the Builder.

**Variable-path rule — MANDATORY.** The Explorer MUST emit the URL as `<variable>` in the page section header if ANY of the three triggers below fires. If none fires, emit the single observed path.

**Trigger 1 — Multiple paths observed.** The Explorer reached the SAME PascalCase page name (e.g., `DashboardPage`) under two or more distinct URL paths during THIS exploration run (e.g., `/admin/dashboard` and `/manager/dashboard` both land on `DashboardPage`).

**Trigger 2 — Scenario test data signals multi-tenant/multi-role access.** The scenario's test data table contains two or more users/roles/tenants AND the scenario steps do not separate them into distinct page sections — i.e., the same page is expected to serve all of them. This trigger fires even if the Explorer only walked one user during exploration (the others imply path variance).

**Trigger 3 — Scenario step text contains an explicit URL-negation directive.** The scenario's step text for any assertion on the page contains a literal instruction against URL-based assertions. The Explorer MUST grep the scenario step text for ALL of these phrase fragments (case-insensitive):
- `do not assert by URL`
- `do NOT assert by URL`
- `not by URL`
- `assert by visible page content`
- `assert by content, not URL`
- `do not rely on URL`

If any phrase matches for a step targeting this page, Trigger 3 fires — emit `<variable>` AND quote the matched phrase verbatim in the `OBSERVED_PATHS` comment so the Builder sees the source directive.

**Format:**

```markdown
### DashboardPage (<variable>)
<!-- OBSERVED_PATHS: /admin/dashboard, /manager/dashboard, /user/dashboard — varies by role. -->
<!-- SCENARIO_DIRECTIVE: "do NOT assert by URL — assert by visible page content" (Trigger 3, quoted from scenario step 3). -->
3. VERIFY: Dashboard page is loaded and visible <!-- ORIGINAL -->
   <!-- ELEMENT: {"page":"DashboardPage","key":"dashboardHeading", ... } -->
```

Include only the comment lines that apply to the fired triggers. If Triggers 1 and 3 both fire, emit both comments.

**Builder contract when page URL is `<variable>` — HARD RULE:**
- Post-login/post-transition navigation waits MUST use content-based or change-relative patterns: `page.waitForURL((url) => url.href !== prevUrl, { waitUntil: 'commit' })` OR a landmark wait on a post-action element. Hardcoding a specific path (e.g., `waitForURL('**/admin/**')`) is a fidelity violation.
- Page-load and state assertions MUST target visible DOM content (heading text, section visibility). `expect(page).toHaveURL(...)` on this page is a fidelity violation.
- The Builder self-audit MUST grep the spec and page-object files for `toHaveURL(` and `waitForURL(/\w+/` (literal path fragment) scoped to steps targeting this page — any match is a violation to fix or escalate.

**Reviewer check:** when enriched.md header reads `<variable>`, the Reviewer MUST grep the spec and page objects for `toHaveURL` and literal-string `waitForURL` calls on the affected page. Any such call is a Dim 9 fidelity violation regardless of whether the test passes at runtime.

