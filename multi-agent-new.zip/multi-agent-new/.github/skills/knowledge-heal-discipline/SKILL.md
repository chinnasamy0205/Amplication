---
name: heal-discipline
description: "The Healer's fix-rule boundaries when repairing Reviewer-flagged issues: the MUST-NOT list (no changing expected values, no step reordering, no force:true, no editing helpers/core/shared/scenarios, no setTimeout in spec), the MUST-DO list (tsc + tests after fixes, document every fix, preserve test.fixme), and the Healer's File-Edit-Scope table. The Healer's contract for every fix."
version: "1.0"
---

# Heal Discipline — Fix Rules for the Healer

These rules govern WHAT the Healer may change while repairing the issues a Reviewer scorecard flagged, and what it must escalate instead. The Healer is a **repair agent, not a rewrite agent** — fix what the Reviewer flagged, break nothing else. Closely related to the Executor's `[[fix-discipline]]` (the Executor fixes test *failures*; the Healer fixes Reviewer-*flagged* issues) — the edit scopes differ slightly (the Healer may edit `output/.env.example`; `output/test-data/shared/` is fixed via scenario-level overrides rather than edited).

---

## Fix Rules — HARD STOP

### MUST NOT — EVER:
1. **MUST NOT change expected values in assertions** — if the value is wrong, it's a POTENTIAL BUG, not a fix
2. **MUST NOT alter scenario step order or skip steps** — fidelity is sacred
3. **MUST NOT add `{ force: true }`** — EVER
4. **MUST NOT modify `*.helpers.ts` files** — team-owned, document with `test.fixme('HELPER ISSUE: ...')`
5. **MUST NOT modify `output/test-data/shared/`** — create scenario-level overrides instead
6. **MUST NOT modify `output/core/*`** — framework core, report as framework issue
7. **MUST NOT modify `scenarios/*.md`** — user-owned scenarios
8. **MUST NOT add `test.setTimeout()` or `page.setDefaultTimeout()` in spec** — timeouts go in playwright.config.ts

### MUST DO:
1. **MUST run TypeScript check** (`npx tsc --noEmit`) after all fixes before running tests
2. **MUST run tests** after all fixes to verify no regressions:
   - web/api/hybrid: `npx playwright test`
   - mobile/mobile-hybrid (Phase 2): `node scripts/mobile-runner.js ...` (NEVER `npx wdio` directly — see the Healer's Phase 3 marker-polling protocol)
3. **MUST document every fix** in the Fixes Applied table with file, line, and change summary
4. **MUST preserve all test.fixme() markers** — these document known issues, not code to delete

### File Edit Scope

| Files | Healer Access | Notes |
|-------|--------------|-------|
| `output/tests/**/*.spec.ts` | **Edit** | Fix imports, raw selectors, test data usage |
| `output/pages/*.ts` | **Edit** | Fix raw selectors, LocatorLoader usage |
| `output/locators/*.json` | **Edit** | Add missing fallbacks, fix types |
| `output/playwright.config.ts` | **Edit** | Fix config issues |
| `output/test-data/{type}/*.json` | **Edit** | Fix test data |
| `output/.env.example` | **Edit** | Add missing placeholder entries |
| `output/core/*` | **READ ONLY** | Framework core — NEVER modify |
| `output/pages/*.helpers.ts` | **READ ONLY** | Team-owned — NEVER modify |
| `output/test-data/shared/*` | **READ ONLY** | Cross-scenario — NEVER modify |
| `scenarios/*.md` | **READ ONLY** | User-owned — NEVER modify |

