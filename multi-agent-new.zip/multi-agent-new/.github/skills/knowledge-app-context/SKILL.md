---
name: app-context
description: Resolve the per-app, per-type app-context file from framework-config.json (appContext block), and append-or-create learned patterns after a run (behavior, not data values). Shared by the Explorer and the Executor (symmetric rules).
version: "1.0"
---

# app-context

> The app-context store is the Voyager-style self-improvement layer: agents read known application patterns before working and write new ones after. The **Explorer** and **Executor** follow these SAME rules (resolution + append-or-create). (Section numbers preserved from source.)

### 2.1: App-Context Resolution — MANDATORY

`framework-config.json` has a per-type `appContext` block. The Explorer MUST resolve the correct filename by the scenario's type (and platform, for mobile). **Do NOT use a single flat `appContext.filename` — that shape was retired; agents reading it will find nothing.**

| Scenario type | Config path | If empty |
|---|---|---|
| `web` | `appContext.web` | Proceed without app-context |
| `api` | `appContext.api` | Proceed without app-context (often empty by design) |
| `hybrid` | Primary: `appContext.web`. Optionally also merge `appContext.api` if set. | Proceed without app-context |
| `mobile` | `appContext.mobile.{android\|ios}` — pick the sub-key matching the `PLATFORM` env var at runtime | Try the OTHER mobile sub-key as fallback. If both empty, proceed without app-context and log: `NO_MOBILE_APP_CONTEXT_CONFIGURED — framework-config.json appContext.mobile.{android,ios} are both empty` |
| `mobile-hybrid` | Primary: `appContext.mobile.{android\|ios}` (same rule as mobile). Optionally also merge `appContext.api`. | Same as mobile |

**Platform: both scenarios** — at runtime the `PLATFORM` env var resolves to exactly one platform (the agent is running one pass at a time), so `appContext.mobile.{that platform}` is what gets loaded. If your `Platform: both` scenario runs on Android today and iOS tomorrow, each run loads a different app-context — that's correct behavior.

**Hybrid merge semantics** (when `hybrid` or `mobile-hybrid` also has an `appContext.api` set): read both files into context, treating the API file as supplementary. Web/mobile patterns take precedence on conflicts — API context adds things the UI context doesn't cover (auth quirks, rate limits, pagination, error-code idioms).

**Forbidden:**
- Guessing the filename from the scenario's name, folder, URL, domain, or app name. The config is authoritative.
- Reading `appContext.filename` as if it were a flat string. That legacy key is no longer present.
- Creating a new app-context file for a type whose config slot is EMPTY (`""`). Absence of a configured filename means the user has not authorized persistence for that type.

**Permitted (and required by §7.2):**
- Creating the app-context file at `scenarios/app-contexts/{resolved-filename}` when the config slot is NON-EMPTY, the file does not yet exist on disk, AND new patterns were discovered during this run. The user's non-empty filename in `framework-config.json → appContext.{type}` IS the onboarding signal — the file does NOT need to pre-exist for the Explorer to create it. See §7.2 for the full append-or-create rule table, symmetric with the Executor agent's app-context rule.

---

---

## 7. App-Context Updates

If the Explorer discovers new patterns during flow verification (e.g., a modal appears after clicking a button, a page redirects unexpectedly, a custom component library has non-standard DOM), write them to the app-context file:

```markdown
## Learned Pattern: Add-to-Cart Modal Dialog
- **Component:** Modal dialog (#cartModal) after adding item to cart
- **Expected:** Item added silently
- **Actual:** Modal appears with "Continue Shopping" and "View Cart" options
- **Discovered:** {date}
```

### 7.1: Resolve the app-context filename (identical to Executor §4.9)

Resolve by scenario type from `framework-config.json → appContext` (see §2.1 for the full resolution table). If the resolved slot is empty, skip the write and log `NO_APP_CONTEXT_CONFIGURED_FOR_TYPE_{type}`. The user will onboard by setting the filename in config if they want patterns persisted for that type.

### 7.2: Create-on-missing — MANDATORY when new patterns were discovered

**If the resolved slot is NON-EMPTY, perform a filesystem check on `scenarios/app-contexts/{resolved-filename}` (use the `Bash` tool — e.g., `test -f path && echo YES || echo NO`). Do NOT infer existence from the config value alone — "configured" ≠ "exists".**

| Slot configured? | File exists on disk? | New patterns discovered this run? | Action |
|---|---|---|---|
| Empty (`""`) | — | — | Skip. Log `NO_APP_CONTEXT_CONFIGURED_FOR_TYPE_{type}`. |
| Non-empty | YES | YES | **APPEND** the new patterns (DO NOT overwrite existing content). |
| Non-empty | YES | NO | No-op. Report `0 new patterns written, N existing patterns applied`. |
| Non-empty | NO | YES | **CREATE** the file at `scenarios/app-contexts/{resolved-filename}` and write the discovered patterns. **The user's configuration of a filename IS the authorization to create it** — do not treat "file doesn't exist" as a blocker when new patterns are available to persist. |
| Non-empty | NO | NO | No-op. Report `NO_APP_CONTEXT_FILE_YET — run more scenarios on this app to accumulate patterns`. |

**Rationale:** the Explorer and the Executor share the same app-context write rules. When you configured a filename in `framework-config.json → appContext.{type}`, you signalled intent to persist patterns for that app. If Explorer discovers patterns but the file is missing, and Explorer does NOT create it, the patterns get lost whenever a run has no Executor pacing fixes (the only other writer). This rule closes that gap. See the Executor agent for the symmetric logic — both agents follow the same append-or-create branch table.

### 7.3: What to write

Every pattern entry should describe HOW the app behaves, not WHAT specific data appears (see §5.1 — DISCOVERED notes, same separation). Pattern categories worth persisting:

- Post-login redirect behavior (role-based routing, non-deterministic landing)
- Cookie/consent/overlay dismissal selectors and timing
- Custom component libraries (Frontier, Kendo, MUI, PCF, etc.) with non-standard DOM
- SPA pacing idioms (which waits work, which don't — especially `networkidle` anti-patterns)
- Logout/session-cleanup URL patterns
- Localization or locale-dependent patterns

### 7.4: Report the action taken

In the Explorer report's `## App-Context Updates` section, state exactly which action the rule table above triggered, filename involved, and count of patterns written or skipped. Do NOT paraphrase "user responsibility" — the rule above is authoritative.

---

