---
name: web-verify
description: Assert page or element state (text, visible/hidden, count, attribute, url, title, value, enabled, checked, class, css); supports soft assertions.
version: "1.0"
---

# web-verify

## Input
- **assertion** ('text' | 'visible' | 'hidden' | 'count' | 'attribute' | 'url' | 'title' | 'value' | 'enabled' | 'disabled' | 'checked' | 'class' | 'css', required)
- **selector** (string, optional): Not needed for url/title assertions
- **expected** (any, required): Expected value
- **soft** (boolean, default: false): If true, use `expect.soft()` instead of `expect()`

## Output
- **passed** (boolean), **actual** (any)

## Rules — MUST Follow
- **MUST** use `expect()` for VERIFY (hard assertion — test stops on failure)
- **MUST** use `expect.soft()` in block scope `{ }` for VERIFY_SOFT (test continues on failure)
- **MUST** attach screenshot on VERIFY_SOFT failure — with descriptive name
- **MUST NOT** convert VERIFY to VERIFY_SOFT or vice versa — EVER
- **MUST NOT** change expected values to make assertions pass — if element found but wrong value, this is a POTENTIAL BUG → use `test.fixme('POTENTIAL BUG: ...')`

## Code Patterns

### VERIFY (Hard Assertion)
```typescript
expect(await page.locator(loc.get('cartBadge')).textContent()).toBe('2');
await expect(page).toHaveURL(/\/dashboard/);
await expect(page.locator(loc.get('heading'))).toBeVisible();
await expect(page.locator(loc.get('items'))).toHaveCount(5);
await expect(page.locator(loc.get('input'))).toHaveAttribute('required', '');
await expect(page.locator(loc.get('button'))).toBeEnabled();
```

### VERIFY_SOFT (Soft Assertion)
```typescript
{
  const result = await page.locator(loc.get('cartBadge')).textContent();
  expect.soft(result).toBe('2');
  if (result !== '2') {
    const screenshot = await page.screenshot({ fullPage: true });
    await test.info().attach('VERIFY_SOFT-failed-cart-badge', {
      body: screenshot, contentType: 'image/png'
    });
  }
}
```

## Robust Assertions for Dynamic / Time-Sensitive Values — app-agnostic

These idioms make assertions resilient to values that legitimately vary at runtime **for reasons unrelated to the behavior under test** — wall-clock time, timezone offset between the app server and the test runner, server-generated IDs, and data-dependent row counts. They are NOT a license to loosen an assertion the scenario explicitly pins (see CRITICAL GUARDRAIL). Apply them ONLY when the varying part is environmental/non-deterministic and the scenario did NOT name an exact value.

**Decision gate:** Did the scenario state the exact expected value (e.g., *"VERIFY: date shows 2026-06-15"*, *"VERIFY: exactly 3 rows"*)? → assert it exactly. Is the value instead "today's date", "the generated reference", "the rows that exist"? → use the robust idiom below.

### 1. Timezone-safe date / timestamp / filename assertions — accept today OR yesterday
The app may stamp a date in the server's timezone while the test runner is in another; at certain hours these differ by one calendar day. When the scenario means "the current date" (not a pinned date), accept **today or yesterday** (a ±1-day window), computed without hardcoding a format the app may not use.

```typescript
// Build candidate date strings in the format the app renders (YYYY-MM-DD shown; adapt to the observed format)
const fmt = (d: Date) => d.toISOString().slice(0, 10);
const today = new Date();
const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
const acceptable = [fmt(today), fmt(yesterday)];

const shown = (await page.locator(loc.get('createdDate')).textContent())?.trim() ?? '';
expect(acceptable, `date "${shown}" should be today or yesterday (TZ-tolerant)`).toContain(shown);

// Same principle for a downloaded filename containing a date stamp:
expect(acceptable.some(d => downloadedName.includes(d)),
  `filename "${downloadedName}" should contain today's or yesterday's date`).toBe(true);
```

### 2. Match on the stable SUFFIX (or stable substring) of dynamic text
When rendered text has a non-deterministic prefix (a generated counter, session id, or greeting) but a stable, meaningful tail — assert the stable part, not the whole string.

```typescript
// e.g. app renders "Order #A7F3K9 confirmed" — the id varies, "confirmed" is the stable signal
const msg = (await page.locator(loc.get('statusBanner')).textContent())?.trim() ?? '';
expect(msg).toMatch(/confirmed$/);                 // stable suffix
// or, stable substring when the suffix itself varies:
expect(msg).toContain('confirmed');
```

Prefer Playwright's retrying locator form when asserting against the element directly: `await expect(loc).toContainText('confirmed')` / `await expect(loc).toHaveText(/confirmed$/)`.

### 3. Relax exact-count → at-least-N when the count is data-dependent
When the scenario means "the grid has data" / "results are shown" rather than a pinned count, assert a lower bound, not equality — a fixed `toHaveCount(N)` breaks whenever the backing data set grows or shrinks.

```typescript
// Scenario: "VERIFY: search returns results"  (no exact number stated)
expect(await page.locator(loc.get('resultRows')).count()).toBeGreaterThanOrEqual(1);

// Scenario: "VERIFY: exactly 3 items in the cart" (count IS scenario-stated) → keep exact:
await expect(page.locator(loc.get('cartRows'))).toHaveCount(3);
```

(See the `web-codegen-spec` VERIFY count/comparison table for the canonical Playwright idioms — `toBeGreaterThanOrEqual` for "at least N", `toHaveCount` for exact.)

### 4. Downloaded-file persistence — verify it actually landed on disk
After a download, verify the file exists at the saved path with `fs.existsSync(downloadPath)` before any content check — a download event can fire without the file persisting. The full pattern (capture the download event, `saveAs`, then `expect(fs.existsSync(path)).toBe(true)`) lives in the `web-codegen-spec` skill's **File Download** section; use it whenever a scenario verifies a download.

## CRITICAL GUARDRAIL
**NEVER modify expected values in assertions.** If the element is found but shows the wrong value → `test.fixme('POTENTIAL BUG: expected "X" but found "Y"')`. This is an application defect, NOT a test issue. The robustness idioms above are for values that are *environmentally* variable (time, TZ, generated ids, data-dependent counts) and were NOT pinned by the scenario — they do NOT override this guardrail for scenario-stated values.

