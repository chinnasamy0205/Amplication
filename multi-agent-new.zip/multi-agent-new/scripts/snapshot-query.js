#!/usr/bin/env node

/**
 * snapshot-query.js — Compact, targeted retrieval over Playwright-CLI aria snapshots.
 *
 * WHY THIS EXISTS (token discipline):
 *   The Explorer drives the browser via playwright-cli, which writes each page's
 *   accessibility tree to a `.playwright-cli/page-*.yml` file. On data-heavy pages
 *   (grids, tables, long lists) a single snapshot can be 20,000+ tokens. Reading the
 *   whole file into the agent's context is the Explorer's single largest token cost:
 *   once a 20k-token blob is in context it is re-sent as INPUT on every subsequent
 *   model turn (context accumulation), amplifying one Read into hundreds of k tokens.
 *
 *   This script lets the Explorer pull ONLY the handful of nodes it needs for a step
 *   (the target element + its ancestor path for scoping + its immediate child
 *   metadata like /url, /placeholder) instead of the entire tree. Typical reduction
 *   on a large page: ~20,000 tokens -> a few hundred. Zero LLM tokens are spent
 *   deriving the subtree — same source of truth (the real snapshot), retrieved
 *   surgically. Framework principle: scripts for evidence, LLMs for judgment.
 *
 * QUALITY IS PRESERVED: the refs, roles, names, /url, /placeholder, and state flags
 * returned here are byte-for-byte the same lines the full snapshot contains. The
 * Explorer / web-element-capture skill get exactly the data they need to derive a
 * selector — just without the 1,400 unrelated grid-cell lines.
 *
 * Usage:
 *   # Find target element(s) by accessible-name / text substring (case-insensitive):
 *   node scripts/snapshot-query.js --file=<snapshot.yml> --find="Add Missing Load"
 *
 *   # Find by role (optionally + name):
 *   node scripts/snapshot-query.js --file=<snapshot.yml> --role=button [--find="Apply"]
 *
 *   # Cheap page overview — list ONLY interactive elements (button/link/textbox/...):
 *   node scripts/snapshot-query.js --file=<snapshot.yml> --interactive
 *
 *   # Structural summary of a grid/list without dumping rows (counts + first samples):
 *   node scripts/snapshot-query.js --file=<snapshot.yml> --structure
 *
 * Options:
 *   --children=N   include up to N indented child lines under each match (default 4;
 *                  captures /url, /placeholder, nested name text). Use 0 for none.
 *   --max=N        cap the number of matches returned (default 25) — a guard so a
 *                  generic term can't accidentally dump the whole tree.
 *   --quiet        suppress the reduction-stats header (stats go to stderr regardless).
 *
 * Output: compact text to stdout (the matched nodes with ancestor context). A one-line
 *   reduction summary is printed to stderr always (measurable proxy for the token win).
 */

const fs = require('fs');

// ---------------------------------------------------------------------------
// CLI argument parsing (matches the repo convention in explorer-post-check.js)
// ---------------------------------------------------------------------------
const args = {};
const finds = []; // --find is repeatable so one call can retrieve N targets from ONE snapshot (batching)
process.argv.slice(2).forEach(arg => {
  const kv = arg.match(/^--(\w+)=(.*)$/);
  if (kv) {
    if (kv[1] === 'find') { finds.push(kv[2]); return; }
    args[kv[1]] = kv[2];
    return;
  }
  const flag = arg.match(/^--(\w+)$/);
  if (flag) args[flag[1]] = true;
});

const file = args.file;
if (!file) {
  console.error('Usage: node scripts/snapshot-query.js --file=<snapshot.yml> (--find=<text> [--find=<text> ...] | --role=<role> | --interactive | --structure) [--children=N] [--max=N] [--quiet]');
  console.error('  --find is repeatable: retrieve MANY targets from ONE snapshot in a single call (batching — fewer tool round-trips).');
  process.exit(1);
}
if (!fs.existsSync(file)) {
  console.error(`snapshot-query: file not found: ${file}`);
  process.exit(1);
}

const childrenN = args.children !== undefined ? parseInt(args.children, 10) : 4;
const maxMatches = args.max !== undefined ? parseInt(args.max, 10) : 25;
const role = args.role ? String(args.role).toLowerCase() : null;

const raw = fs.readFileSync(file, 'utf8');
const lines = raw.split(/\r?\n/);
const totalBytes = Buffer.byteLength(raw, 'utf8');

// Indentation depth of a line (spaces before the leading "- " or content).
function indentOf(line) {
  const m = line.match(/^(\s*)/);
  return m ? m[1].length : 0;
}

// Recognised interactive/structural roles in the aria snapshot.
const INTERACTIVE = /^\s*-\s+(button|link|textbox|checkbox|radio|combobox|tab|menuitem|option|spinbutton|switch|slider|searchbox|listbox|treeitem)\b/i;
const ROW_LIKE = /^\s*-\s+(row|gridcell|cell|listitem|rowheader|columnheader)\b/i;

// Parse a node line into {role, name} when possible.
function parseNode(line) {
  const m = line.match(/^\s*-\s+([a-zA-Z]+)\s*(?:"([^"]*)")?/);
  if (!m) return null;
  return { role: m[1].toLowerCase(), name: m[2] || null };
}

// Build the ancestor chain (lines with strictly-decreasing indentation above idx).
function ancestors(idx) {
  const chain = [];
  let need = indentOf(lines[idx]);
  for (let i = idx - 1; i >= 0 && need > 0; i--) {
    const ind = indentOf(lines[i]);
    if (lines[i].trim() === '') continue;
    if (ind < need) { chain.unshift({ i, line: lines[i] }); need = ind; }
  }
  return chain;
}

// Collect up to n child lines (strictly greater indentation) directly under idx.
function children(idx, n) {
  if (n <= 0) return [];
  const base = indentOf(lines[idx]);
  const out = [];
  for (let i = idx + 1; i < lines.length && out.length < n; i++) {
    if (lines[i].trim() === '') continue;
    const ind = indentOf(lines[i]);
    if (ind <= base) break;
    out.push({ i, line: lines[i] });
  }
  return out;
}

let outBlocks = [];
let matchCount = 0;

function emitMatch(idx) {
  if (matchCount >= maxMatches) return;
  matchCount++;
  const anc = ancestors(idx).filter(a => {
    // keep only ancestors that name a region/section (skip anonymous generics for brevity)
    const p = parseNode(a.line);
    return p && (p.name || /navigation|main|dialog|tabpanel|region|form|table|grid|list|banner|complementary/i.test(p.role));
  });
  const kids = children(idx, childrenN);
  const block = [];
  anc.forEach(a => block.push(`  ${a.line.trim()}`));
  block.push(`> ${lines[idx].trim()}   (line ${idx + 1})`);
  kids.forEach(k => block.push(`    ${k.line.trim()}`));
  outBlocks.push(block.join('\n'));
}

// ---------------------------------------------------------------------------
// Modes
// ---------------------------------------------------------------------------
if (args.structure) {
  // Structural summary: counts of row-like nodes + first few first-cell samples.
  const counts = {};
  let firstCells = [];
  lines.forEach((line) => {
    const m = line.match(ROW_LIKE);
    if (m) {
      const r = m[1].toLowerCase();
      counts[r] = (counts[r] || 0) + 1;
    }
    if (firstCells.length < 5) {
      const cm = line.match(/^\s*-\s+(?:gridcell|cell|rowheader)\s+"([^"]+)"/i);
      if (cm) firstCells.push(cm[1]);
    }
  });
  outBlocks.push('STRUCTURE SUMMARY (no rows dumped):');
  Object.entries(counts).forEach(([k, v]) => outBlocks.push(`  ${k}: ${v}`));
  if (firstCells.length) outBlocks.push(`  firstCellSamples: ${JSON.stringify(firstCells)}`);
} else if (args.interactive) {
  // List only interactive elements with their ref — a cheap page overview.
  lines.forEach((line, _idx) => {
    if (INTERACTIVE.test(line)) {
      const ref = (line.match(/\[ref=([a-z0-9]+)\]/i) || [])[1] || '?';
      const node = parseNode(line);
      if (node) outBlocks.push(`  ${node.role} "${node.name || ''}" [ref=${ref}]`);
    }
  });
  if (outBlocks.length > maxMatches) {
    const shown = outBlocks.slice(0, maxMatches);
    shown.push(`  ... (${outBlocks.length - maxMatches} more interactive elements; narrow with --find/--role)`);
    outBlocks = shown;
  }
  matchCount = outBlocks.length;
} else if (finds.length || role) {
  // Targeted find — one or MANY targets in a single call (batching). Each --find gets its
  // own labelled block so the caller can tell which target matched which node.
  const targets = finds.length ? finds : [null]; // role-only query when no --find given
  for (const t of targets) {
    const needle = t ? String(t).toLowerCase() : null;
    if (t !== null) outBlocks.push(`### target: "${t}"`);
    const before = matchCount;
    for (let idx = 0; idx < lines.length; idx++) {
      const node = parseNode(lines[idx]);
      if (!node) continue;
      if (role && node.role !== role) continue;
      if (needle) {
        const hay = (node.name || '') + ' ' + (lines[idx] || '');
        if (!hay.toLowerCase().includes(needle)) continue;
      }
      emitMatch(idx);
    }
    if (t !== null && matchCount === before) outBlocks.push('  (no match — re-snapshot or widen)');
  }
} else {
  console.error('snapshot-query: specify one of --find=<text> (repeatable), --role=<role>, --interactive, or --structure');
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Output + reduction stats
// ---------------------------------------------------------------------------
const body = outBlocks.length ? outBlocks.join('\n\n') : '(no matches — re-snapshot or widen the query)';
const outBytes = Buffer.byteLength(body, 'utf8');
const pct = totalBytes > 0 ? Math.round((1 - outBytes / totalBytes) * 100) : 0;
const stats = `snapshot-query: ${lines.length} lines / ~${Math.round(totalBytes / 4)} tok in snapshot -> ${matchCount} match(es), ~${Math.round(outBytes / 4)} tok returned (${pct}% smaller)`;

if (!args.quiet) console.log(`# ${stats}`);
console.log(body);
console.error(stats);
