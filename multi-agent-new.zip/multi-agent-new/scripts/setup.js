#!/usr/bin/env node
/**
 * setup.js — runtime install for a qe-automation project (`npm run setup`).
 *
 * Scope: installs the TEST RUNTIME only. Delivery (framework files) and
 * configuration (framework-config.json, .env, package.json scripts) are handled
 * by `agent-hub install` / `qe-install.js` and the Setup Agent respectively —
 * this script deliberately does NOT re-scaffold dirs or seed config.
 *
 * It does three things:
 *   1. `npm install` in output/                — the generated test project's deps
 *   2. `npx playwright install chromium`        — the shared browser build (test runner + CLI driver)
 *   3. `npm install -g @playwright/cli`         — the Explorer/Executor browser DRIVER (`playwright-cli`)
 *
 * Uses only built-in Node modules. Run from the PROJECT ROOT:
 *   node scripts/setup.js                 # full runtime install (default: typescript)
 *   node scripts/setup.js --validate-only # check only, install nothing
 *   node scripts/setup.js --skip-cli      # skip the Playwright CLI install step
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');

const isWin = process.platform === 'win32';
const npmCmd = isWin ? 'npm.cmd' : 'npm';
const npxCmd = isWin ? 'npx.cmd' : 'npx';
const S = isWin
  ? { ok: '[OK]', fail: '[FAIL]', skip: '[--]', arrow: '=>', info: '[i]', warn: '[!]', run: '[..]' }
  : { ok: '✅', fail: '❌', skip: '⏭️', arrow: '➡️', info: 'ℹ️', warn: '⚠️', run: '⏳' };

const ROOT = path.resolve(process.cwd());
const OUTPUT = path.join(ROOT, 'output');
const FLAGS = {
  validateOnly: process.argv.includes('--validate-only'),
  skipCli: process.argv.includes('--skip-cli'),
};

// Playwright is driven by the CLI (`playwright-cli`), NOT an MCP server, so there is no Playwright
// MCP config to auto-provision. The BDD trackers + (Phase-2) Appium are external, credentialed MCPs
// the user configures manually per mcp/README.md — never auto-copied.

function runCommand(cmd, cwd, label) {
  console.log(`  ${S.run} ${label}...`);
  if (FLAGS.validateOnly) { console.log(`  ${S.skip} ${label} (validate-only)`); return true; }
  try {
    execSync(cmd, { cwd, stdio: ['pipe', 'pipe', 'pipe'], timeout: 600000 });
    console.log(`  ${S.ok} ${label}`);
    return true;
  } catch (err) {
    console.error(`  ${S.fail} ${label} — failed`);
    const first = err.stderr && err.stderr.toString().trim().split('\n')[0];
    if (first) console.error(`      ${first}`);
    return false;
  }
}

function detectLanguage() {
  try {
    const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'framework-config.json'), 'utf8'));
    if (cfg.language) return String(cfg.language).toLowerCase();
  } catch { /* fall through */ }
  try { return fs.readFileSync(path.join(ROOT, 'output', '.language'), 'utf8').trim().toLowerCase() || 'typescript'; }
  catch { return 'typescript'; }
}

// Install @playwright/cli (the Explorer/Executor browser DRIVER — the bare `playwright-cli` command).
// The browser binaries come from step 2 (`playwright install chromium`); the CLI reuses that build.
// Installed GLOBALLY so the agents' bare `playwright-cli …` calls resolve on PATH. Non-fatal.
// NOTE: left UNPINNED. The old Playwright MCP was pinned (0.0.74) to share ONE Chromium build with
// output's @playwright/test 1.60; whether @playwright/cli needs the same locking is UNVERIFIED and
// must be checked at the first execution round — pin here only if a browser-build mismatch surfaces.
function installPlaywrightCli() {
  if (FLAGS.skipCli) { console.log(`${S.info} --skip-cli: Playwright CLI install skipped`); return; }
  console.log(`\n${S.arrow} Installing the Playwright CLI (playwright-cli — the Explorer/Executor browser driver)...`);
  process.env.npm_config_yes = 'true';
  const cmd = `${npmCmd} install -g @playwright/cli`;
  if (runCommand(cmd, ROOT, 'npm install -g @playwright/cli')) return;
  console.log(`  ${S.warn} Playwright CLI install failed — the Explorer/Executor drive the browser via 'playwright-cli'.`);
  console.log(`     Re-run manually:  ${npmCmd} install -g @playwright/cli`);
}

// Seed output/.env from the example (v2 parity) — copy ONLY if .env does not exist; never overwrite.
function seedEnvFile() {
  const example = path.join(OUTPUT, '.env.example');
  const envFile = path.join(OUTPUT, '.env');
  if (fs.existsSync(envFile)) { console.log(`  ${S.skip} output/.env already exists — left as-is`); return; }
  if (!fs.existsSync(example)) { console.log(`  ${S.skip} output/.env.example not found — skipping .env seed`); return; }
  if (FLAGS.validateOnly) { console.log(`  ${S.skip} would copy output/.env.example → output/.env (validate-only)`); return; }
  fs.copyFileSync(example, envFile);
  console.log(`  ${S.ok} created output/.env from .env.example — fill in real values`);
}

// Create output/.gitignore (v2 parity) so secrets (.env) + run artifacts are never committed. Only if absent.
function seedGitignore() {
  const gi = path.join(OUTPUT, '.gitignore');
  if (fs.existsSync(gi)) { console.log(`  ${S.skip} output/.gitignore already exists — left as-is`); return; }
  if (FLAGS.validateOnly) { console.log(`  ${S.skip} would create output/.gitignore (validate-only)`); return; }
  fs.writeFileSync(gi, ['node_modules/', '.env', '.env.qa', '.env.stg', 'test-results/', 'playwright-report/', 'blob-report/', 'screenshots/', 'allure-results/', 'allure-report/', '.playwright-cli/', ''].join('\n'));
  console.log(`  ${S.ok} created output/.gitignore (ignores .env + test artifacts)`);
}

function main() {
  console.log('\n=== qe-automation — runtime setup ===\n');
  console.log(`${S.info} Platform: ${os.platform()} ${os.arch()}  |  Node: ${process.version}`);
  console.log(`${S.info} Root:     ${ROOT}`);
  const nodeMajor = parseInt(process.version.slice(1).split('.')[0], 10);
  if (Number.isFinite(nodeMajor) && nodeMajor < 18) {
    console.error(`\n${S.fail} Node.js >= 18 is required (Playwright needs it). Found: ${process.version}. Upgrade Node, then re-run.`);
    process.exit(1);
  }
  const language = detectLanguage();
  console.log(`${S.info} Language: ${language}`);
  if (FLAGS.validateOnly) console.log(`${S.info} Mode:     validate-only (no install)`);

  if (!fs.existsSync(OUTPUT)) {
    console.error(`\n${S.fail} output/ not found. Run the installer + Setup Agent first (deliver + configure), then re-run setup.`);
    process.exit(1);
  }

  let ok = true;
  if (language === 'typescript' || language === 'javascript') {
    console.log(`\n${S.arrow} Installing test project dependencies (output/)...`);
    ok = runCommand(`${npmCmd} install`, OUTPUT, 'npm install (output/)') && ok;
    console.log(`\n${S.arrow} Installing the Executor's browser (Chromium)...`);
    ok = runCommand(`${npxCmd} playwright install chromium`, OUTPUT, 'playwright install chromium') && ok;
  } else if (language === 'python') {
    console.log(`\n${S.warn} Python runtime scaffolding (requirements.txt / pytest) is a Phase-2 deliverable — install manually for now:`);
    console.log(`     pip install -r output/requirements.txt && playwright install chromium`);
  }

  installPlaywrightCli();   // the Explorer/Executor browser driver (playwright-cli)
  seedEnvFile();            // copy output/.env.example → output/.env (v2 parity; never overwrites an existing .env)
  seedGitignore();          // v2 parity: gitignore .env + test artifacts in output/

  console.log(`\n${ok ? S.ok : S.warn} Runtime setup ${ok ? 'complete' : 'finished with warnings'}.`);
  if (!ok) console.log(`${S.info} Review the failures above. You can re-run \`npm run setup\` (it is idempotent).`);
  console.log(`${S.info} Next: fill output/.env with real values, then run a scenario (see qe-run-guide).`);
}

main();
