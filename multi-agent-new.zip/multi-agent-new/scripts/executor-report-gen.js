#!/usr/bin/env node
/**
 * executor-report-gen.js — Deterministic Executor metrics + in-place stats injection.
 *
 * Runs AFTER the Executor's FINAL test cycle, once the agent has written the report's
 * JUDGMENT sections (Cycle History, Fixes prose, Escalations, App-Context) + the
 * structural markers. Sibling of explorer-report-gen.js; "scripts for evidence,
 * LLMs for judgment" applied to the Executor's reporting:
 *
 *   - Test results (pass/fail/skip/fixme, durations) come straight from Playwright's
 *     JSON reporter (output/<resultsDir>/results.json) — the LLM never self-reports them.
 *   - Counts (fix cycles, auth re-runs, fixes, escalations) are computed from
 *     LLM-emitted markers (### Cycle N / AUTH_RERUN / FIX) + the spec's test.fixme()
 *     calls — the script only COUNTS, never fabricates.
 *   - The script writes the full metrics JSON AND injects the computed stat block
 *     IN-PLACE into the report, between <!-- EXEC-STATS:BEGIN --> / <!-- EXEC-STATS:END -->
 *     delimiters (idempotent — re-running replaces the region). ONE report file; no
 *     separate scaffold to clean up. The LLM owns everything OUTSIDE that region.
 *
 * Single-scenario model: the Executor runs ONE spec (one test()), so suite metrics
 * (firstRunPassRate/fixSuccessRate) are meaningless; we emit a deterministic
 * passedFirstRun boolean instead (= 1 cycle && no failures && no fixme).
 *
 * Usage:
 *   node scripts/executor-report-gen.js --scenario=<name> --type=web [--folder=<f>] \
 *        [--start=<ISO>] [--end=<ISO>] [--resultsDir=test-results]
 *
 * Writes:
 *   output/reports/metrics/executor-metrics-<scenario>.json        (full, deterministic)
 *   output/reports/[<folder>/]executor-report-<scenario>.md        (injects the EXEC-STATS region in-place)
 */
'use strict';
const fs = require('fs');
const path = require('path');

// ---- args ----
const args = {};
process.argv.slice(2).forEach((a) => { const m = a.match(/^--([\w]+)=(.*)$/); if (m) args[m[1]] = m[2]; });
const scenario = args.scenario;
const type = args.type || 'web';
const folder = args.folder || null;
if (!scenario) { console.error('Usage: node scripts/executor-report-gen.js --scenario=<name> --type=web [--folder=<f>]'); process.exit(1); }

// ---- paths ----
const projectRoot = path.resolve(__dirname, '..');
const outputDir = path.join(projectRoot, 'output');
const folderSeg = folder ? `${folder}/` : '';
const resultsDir = args.resultsDir || 'test-results';
const paths = {
  results: path.join(outputDir, resultsDir, 'results.json'),
  specTs: path.join(outputDir, 'tests', type, folderSeg, `${scenario}.spec.ts`),
  specJs: path.join(outputDir, 'tests', type, folderSeg, `${scenario}.spec.js`),
  scenarioFile: path.join(projectRoot, 'scenarios', type, folderSeg, `${scenario}.md`),
  report: path.join(outputDir, 'reports', folderSeg, `executor-report-${scenario}.md`),
  metrics: path.join(outputDir, 'reports', 'metrics', `executor-metrics-${scenario}.json`),
  config: path.join(projectRoot, 'framework-config.json'),
};
const read = (p) => (fs.existsSync(p) ? fs.readFileSync(p, 'utf-8') : null);
const readJSON = (p) => { try { return JSON.parse(read(p)); } catch { return null; } };
const countRe = (s, re) => { const m = s && s.match(re); return m ? m.length : 0; };

// ---- config ----
const config = readJSON(paths.config) || {};
const execCfg = config.executor || {};
const maxCyclesFromConfig = execCfg.maxCycles != null ? execCfg.maxCycles : null;
const maxAuthReRuns = execCfg.maxAuthReRuns != null ? execCfg.maxAuthReRuns : 1;
const preFlightEnabled = execCfg.preFlightEnabled !== false;

// ---- 1. Playwright results.json (GROUND TRUTH — authoritative test results) ----
const results = readJSON(paths.results);
let testResults = null, testDurationMs = null, resultsStart = null;
if (results) {
  const stats = results.stats || {};
  let total = 0, fixme = 0;
  const walk = (suite) => {
    (suite.specs || []).forEach((sp) => (sp.tests || []).forEach((t) => {
      total++;
      if ((t.annotations || []).some((a) => a.type === 'fixme')) fixme++;
    }));
    (suite.suites || []).forEach(walk);
  };
  (results.suites || []).forEach(walk);
  const passed = stats.expected || 0, failed = stats.unexpected || 0, flaky = stats.flaky || 0, skipped = stats.skipped || 0;
  if (!total) total = passed + failed + flaky + skipped;
  testResults = { total, passed, failed, flaky, skipped, fixme };
  testDurationMs = stats.duration != null ? Math.round(stats.duration) : null;
  resultsStart = stats.startTime || null;
}
const failed = testResults ? testResults.failed : null;
const fixme = testResults ? testResults.fixme : 0;

// ---- 2. report markers (LLM evidence; script COUNTS only — anti-fabrication) ----
const report = read(paths.report) || '';
const cycleLabels = [];
(report.match(/^###\s+Cycle\s+(\d+)\b/gm) || []).forEach((h) => {
  const n = Number(h.match(/(\d+)/)[1]); if (!cycleLabels.includes(n)) cycleLabels.push(n);
});
cycleLabels.sort((a, b) => a - b);
const testExecutionCount = cycleLabels.length;
const authReRunCount = countRe(report, /<!--\s*AUTH_RERUN:\s*\d+\s*-->/g);
const stopOnUserSide = /<!--\s*STOP_ON_USER_SIDE\s*-->/.test(report);
const appContextUpdated = /<!--\s*APPCONTEXT_UPDATED\s*-->/.test(report);
const sameRootCauseDetections = countRe(report, /<!--\s*SAME_ROOT_CAUSE\s*-->/g);

// FIX markers: <!-- FIX: cycle=N phase=preflight|runtime category=... [file=...] [key=...] -->
const fixes = [];
let preFlightFixes = 0, runtimeFixes = 0;
const FIX_RE = /<!--\s*FIX:\s*([^>]*?)-->/g;
let fm;
while ((fm = FIX_RE.exec(report)) !== null) {
  const body = fm[1];
  const field = (k) => { const m = body.match(new RegExp('\\b' + k + '=([^\\s]+)')); return m ? m[1] : null; };
  const phase = field('phase') === 'preflight' ? 'preflight' : 'runtime';
  fixes.push({ cycle: field('cycle') ? Number(field('cycle')) : null, phase, category: field('category'), file: field('file') || undefined, key: field('key') || undefined });
  if (phase === 'preflight') preFlightFixes++; else runtimeFixes++;
}
const totalFixes = preFlightFixes + runtimeFixes;
const preFlightResult = !preFlightEnabled ? 'DISABLED' : (preFlightFixes === 0 ? 'PASS' : `FIXED (${preFlightFixes})`);

// ---- 3. spec file: test.fixme escalations by category + test.step count ----
const specPath = fs.existsSync(paths.specTs) ? paths.specTs : (fs.existsSync(paths.specJs) ? paths.specJs : null);
const spec = (specPath && read(specPath)) || '';
const potentialBugs = countRe(spec, /test\.fixme\(\s*['"`]POTENTIAL BUG:/g);
const unfixableIssues = countRe(spec, /test\.fixme\(\s*['"`]UNFIXABLE:/g);
const helperIssues = countRe(spec, /test\.fixme\(\s*['"`]HELPER ISSUE:/g);
const escalatedIssues = potentialBugs + unfixableIssues + helperIssues;
const specSteps = countRe(spec, /\btest\.step\(\s*[`'"]Step\s+\d+/g)
  + countRe(spec, /\btitle\s*:\s*[`'"]Step\s+\d+/g);

// ---- 4. scenario step count ----
const scenarioMd = read(paths.scenarioFile) || '';
let scenarioSteps = 0;
const stepsSec = scenarioMd.match(/## Steps[\s\S]*$/m);
if (stepsSec) scenarioSteps = countRe(stepsSec[0], /^\d+\./gm);
const stepCountVerification = { scenarioSteps, specSteps, match: scenarioSteps === specSteps };

// ---- 5. duration + outcome + derived ----
const startISO = args.start || resultsStart || null;
const endISO = args.end || null;
const durationMs = (args.start && args.end) ? (new Date(args.end) - new Date(args.start)) : null; // agent wall-clock — orchestrator-supplied only
const fmtDur = (ms) => (ms == null ? null : `${Math.floor(ms / 60000)}m ${Math.round((ms % 60000) / 1000)}s`);
const outcome = failed == null ? 'UNKNOWN' : (failed === 0 ? 'PASSING' : 'FAILING');
const passedFirstRun = testResults != null && testExecutionCount === 1 && failed === 0 && fixme === 0;

// ---- 6. metrics JSON (deterministic) ----
const metrics = {
  schemaVersion: '2.1.0',
  metricsVersion: '2.2.0-cli',
  agent: 'executor',
  scenario, type, folder: folder || null,
  date: endISO || startISO || new Date().toISOString(),
  startTime: startISO, endTime: endISO, durationMs, durationFormatted: fmtDur(durationMs),
  outcome, stopOnUserSide,
  testExecutionCount, maxCyclesFromConfig, cycleLabels,
  authReRunCount, maxAuthReRuns,
  preFlightEnabled, preFlightResult, preFlightFixes, runtimeFixes, totalFixes,
  escalatedIssues, potentialBugs, unfixableIssues, helperIssues,
  passedFirstRun,
  testResults: testResults || null,
  testDurationMs,
  stepCountVerification,
  appContextUpdated,
  sameRootCauseDetections,
  fixes,
  source: 'executor-report-gen.js (deterministic)',
  observabilityNote: results
    ? 'testResults/testDurationMs from Playwright results.json (authoritative). Counts (cycles/auth/fixes/escalations) computed from LLM-emitted ### Cycle / AUTH_RERUN / FIX markers + spec test.fixme() — script COUNTS, never fabricates. passedFirstRun derived from cycle count + final results (single-scenario equivalent of first-run quality). durationMs (agent wall-clock) is null unless --start/--end supplied.'
    : `results.json NOT FOUND at ${path.relative(projectRoot, paths.results)} — testResults null (Executor may have failed before a run, or the file was cleaned). Marker/spec counts still valid; re-run after a test execution to populate testResults.`,
};

// ---- 7. eval metrics (per-scenario meaningful only) ----
const evalMetrics = {
  cycleEfficiency: maxCyclesFromConfig != null ? `${testExecutionCount} of ${maxCyclesFromConfig}` : `${testExecutionCount}`,
  passedFirstRun, preFlightFixes, runtimeFixes, totalFixes, escalatedIssues, sameRootCauseDetections,
};

// ---- 8. computed stats region (script-owned; injected in-place) ----
const tr = testResults || { total: '?', passed: '?', failed: '?', skipped: '?', fixme: '?', flaky: 0 };
const testDurStr = testDurationMs != null ? `${Math.round(testDurationMs / 1000)}s` : 'n/a';
const maxC = maxCyclesFromConfig != null ? maxCyclesFromConfig : '?';
const BEGIN = '<!-- EXEC-STATS:BEGIN -->';
const END = '<!-- EXEC-STATS:END -->';
const statsBody = `${BEGIN}
<!-- AUTO-GENERATED by executor-report-gen.js — do NOT hand-edit; re-running the script regenerates this region. -->
**Outcome:** ${outcome}
**Test Results:** ${tr.passed}/${tr.total} tests passing (${tr.failed} failed, ${tr.fixme} test.fixme)
**Test Duration:** ${testDurStr} (final run wall-clock)
**Duration (agent):** ${fmtDur(durationMs) || 'n/a — orchestrator supplies --start/--end'}
**Fix Cycles:** ${testExecutionCount} of ${maxC} max (${preFlightFixes} pre-flight, ${runtimeFixes} runtime)
**Escalated Issues:** ${escalatedIssues} (${potentialBugs} potential bugs, ${unfixableIssues} unfixable, ${helperIssues} helper)
**Passed First Run:** ${passedFirstRun ? 'YES' : 'NO'}
**Step Count:** scenario ${scenarioSteps} vs spec ${specSteps} → ${stepCountVerification.match ? 'MATCH' : 'MISMATCH'}

### Final Test Results
- **Passed:** ${tr.passed} · **Failed:** ${tr.failed} · **Flaky:** ${tr.flaky || 0} · **Skipped:** ${tr.skipped} · **test.fixme (blocked):** ${tr.fixme}
- **Test duration:** ${testDurStr} · **Status:** ${outcome}

### Summary Metrics
| Metric | Value |
|--------|-------|
| Total tests | ${tr.total} |
| Passed | ${tr.passed} |
| Failed | ${tr.failed} |
| test.fixme (blocked) | ${tr.fixme} |
| Fix cycles used | ${testExecutionCount} of ${maxC} |
| Pre-flight fixes | ${preFlightFixes} |
| Runtime fixes | ${runtimeFixes} |
| Escalated issues | ${escalatedIssues} |
| Passed first run | ${passedFirstRun ? 'Yes' : 'No'} |
| App-context updated | ${appContextUpdated ? 'Yes' : 'No'} |
| Final status | ${outcome} |

### Observability
| Metric | Value |
|--------|-------|
| Duration (agent) | ${fmtDur(durationMs) || 'n/a'} |
| Test executions (fix cycles) | ${testExecutionCount} of ${maxC} |
| Auth re-runs | ${authReRunCount} of ${maxAuthReRuns} |
| Token usage | N/A — platform does not expose token counts |

### Eval Metrics
| Metric | Value |
|--------|-------|
| Cycle efficiency | ${evalMetrics.cycleEfficiency} |
| Passed first run | ${passedFirstRun ? 'Yes' : 'No'} |
| Pre-flight fixes | ${preFlightFixes} |
| Runtime fixes | ${runtimeFixes} |
| Escalated issues | ${escalatedIssues} |
| Same-root-cause detections | ${sameRootCauseDetections} |
${END}`;

// ---- 9. inject in-place (idempotent) — ONE report file, no scaffold ----
const REGION_RE = /<!-- EXEC-STATS:BEGIN -->[\s\S]*?<!-- EXEC-STATS:END -->/;
let reportText = read(paths.report);
let injectMode;
if (reportText && REGION_RE.test(reportText)) {
  reportText = reportText.replace(REGION_RE, statsBody);          // re-run / template-provided region → replace
  injectMode = 'replaced-region';
} else if (reportText) {
  if (/^#\s.*$/m.test(reportText)) reportText = reportText.replace(/^(#\s.*)$/m, `$1\n\n${statsBody}`); // insert after H1
  else reportText = `${statsBody}\n\n${reportText}`;
  injectMode = 'inserted-region';
} else {
  // report not written yet — create a minimal one with the stats region + narrative stubs
  reportText = `# Executor Report: ${scenario}

**Key Fixes:** <!-- LLM: 1-line summary of the most impactful fix -->

${statsBody}

## Pre-Flight Fidelity Audit
<!-- LLM: TypeScript check + keyword spot-check, or "All checks passed." (step count ${scenarioSteps}/${specSteps} ${stepCountVerification.match ? 'MATCH' : 'MISMATCH'}) -->

## Cycle History
<!-- LLM: per-cycle diagnosis + Failures/Fixes tables, with ### Cycle {N} + CYCLE_COMPLETE/FIX markers. -->

## Auth Re-Runs
${authReRunCount === 0 ? 'None — no auth re-runs.' : `${authReRunCount} of ${maxAuthReRuns}.`}

## Fixes Summary
${totalFixes === 0 ? 'No fixes needed — tests passed on first run.' : '<!-- LLM: table of all fixes (file | line | change | category | reason). -->'}

## Escalated Issues (Not Fixed)
${escalatedIssues === 0 ? 'None — no escalated issues.' : '<!-- LLM: detail each escalation. -->'}

## App-Context Check
- App-context updated this run: ${appContextUpdated ? 'YES' : 'NO'}
<!-- LLM: PACING comments / patterns, or "None." -->
`;
  injectMode = 'created-report';
}

// ---- write ----
fs.mkdirSync(path.dirname(paths.metrics), { recursive: true });
fs.mkdirSync(path.dirname(paths.report), { recursive: true });
fs.writeFileSync(paths.metrics, JSON.stringify(metrics, null, 2), 'utf-8');
fs.writeFileSync(paths.report, reportText, 'utf-8');

console.log(JSON.stringify({
  wrote: { metrics: path.relative(projectRoot, paths.metrics), report: path.relative(projectRoot, paths.report) },
  injectMode,
  groundTruth: { testResults, testExecutionCount, cycleLabels, preFlightFixes, runtimeFixes, totalFixes, escalatedIssues, passedFirstRun, outcome },
  resultsJsonFound: !!results,
}, null, 2));
