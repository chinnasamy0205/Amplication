#!/usr/bin/env node
/**
 * explorer-report-gen.js — Deterministic post-Explorer metrics + report (written in place, no scaffold temp).
 *
 * Runs AFTER the Explorer finishes and BEFORE the Builder. Complements
 * explorer-post-check.js (which runs after the Builder). Embodies the same
 * principle — "Scripts for evidence, LLMs for judgment" — applied to REPORTING:
 *
 *   - The MECHANICAL parts of the explorer report + the whole metrics JSON are
 *     computed here from GROUND TRUTH (the playwright-cli .yml trail + the
 *     enriched.md LEDGER/ELEMENT markers + the scenario step count), so the
 *     LLM no longer hand-writes them (saves output tokens) and the counts are
 *     accurate (the LLM self-reported 12 snapshots last run; the real count is
 *     the number of .playwright-cli/page-*.yml files).
 *   - The LLM keeps only the JUDGMENT sections (Key Decisions, Dynamic Content
 *     Map insights, Issues) — emitted as <!-- LLM: ... --> placeholders below.
 *
 * It does NOT fabricate LEDGER markers (those stay LLM-emitted in the enriched.md
 * for anti-fabrication integrity); it only COUNTS them.
 *
 * Usage:
 *   node scripts/explorer-report-gen.js --scenario=<name> --type=web [--folder=<f>] \
 *        [--cliDir=.playwright-cli] [--start=<ISO>] [--end=<ISO>]
 *
 * Writes:
 *   output/reports/metrics/explorer-metrics-<scenario>.json   (full, deterministic)
 *   output/reports/[<folder>/]explorer-report-<scenario>.md  (mechanical sections + LLM placeholders, filled IN PLACE by the agent — no scaffold temp file)
 */
'use strict';
const fs = require('fs');
const path = require('path');

// ---- args ----
const args = {};
process.argv.slice(2).forEach((a) => { const m = a.match(/^--([\w]+)=(.*)$/); if (m) args[m[1]] = m[2]; });
const scenario = args.scenario;
const type = args.type || 'web';
const folder = args.folder || null;
if (!scenario) { console.error('Usage: node scripts/explorer-report-gen.js --scenario=<name> --type=web [--folder=<f>]'); process.exit(1); }

// ---- paths ----
const projectRoot = path.resolve(__dirname, '..');
const outputDir = path.join(projectRoot, 'output');
const folderPrefix = folder || '';
const cliDir = path.resolve(projectRoot, args.cliDir || '.playwright-cli');
const paths = {
  scenarioFile: path.join(projectRoot, 'scenarios', type, folderPrefix, `${scenario}.md`),
  enrichedFile: path.join(projectRoot, 'scenarios', type, folderPrefix, `${scenario}.enriched.md`),
  report: path.join(outputDir, 'reports', folderPrefix, `explorer-report-${scenario}.md`),       // FINAL file — agent fills <!-- LLM: --> in place
  reportSource: path.join(outputDir, 'reports', folderPrefix, `explorer-report-${scenario}.md`),  // same file; read (pre-overwrite) only for the legacy LEDGER fallback
  metrics: path.join(outputDir, 'reports', 'metrics', `explorer-metrics-${scenario}.json`),
};
const read = (p) => (fs.existsSync(p) ? fs.readFileSync(p, 'utf-8') : null);
const count = (s, re) => { const m = s && s.match(re); return m ? m.length : 0; };
// Strip HTML comments robustly: [\s\S] matches across newlines, loop until stable so
// overlapping/nested markers leave no residual <!-- (clears CodeQL js/bad-tag-filter +
// js/incomplete-multi-character-sanitization on the prior /<!--.*?-->/g form).
function stripHtmlComments(str) {
  let prev;
  do { prev = str; str = str.replace(/<!--[\s\S]*?-->/g, ''); } while (str !== prev);
  return str;
}

const enriched = read(paths.enrichedFile) || '';
const scenarioMd = read(paths.scenarioFile) || '';

// ---- 1. scenario total steps (mechanical) ----
let totalSteps = 0;
const stepsSec = scenarioMd.match(/## Steps[\s\S]*$/m);
if (stepsSec) totalSteps = count(stepsSec[0], /^\d+\./gm);

// ---- 2. enriched.md ground truth ----
// LEDGER markers are the LLM's anti-fabrication evidence. In the OPTIMIZED flow they
// live in the enriched.md (LLM emits one cheap line per step after the real interaction);
// fall back to the explorer-report.md for the current agent that still writes them there.
const LEDGER_RE = /<!--\s*LEDGER:END\s+step=(\d+)\s*-->/g;
const ledgerSteps = new Set();
const ledgerSource = (enriched.match(LEDGER_RE) ? enriched : (read(paths.reportSource) || enriched));
(ledgerSource.match(LEDGER_RE) || []).forEach((m) => ledgerSteps.add(Number(m.match(/step=(\d+)/)[1])));
const blockedSteps = new Set();
let currentStep = null;
for (const line of enriched.split(/\r?\n/)) {
  const stepMatch = line.match(/^\s*(\d+)\.\s+/);
  if (stepMatch) currentStep = Number(stepMatch[1]);
  if (currentStep !== null && /<!--\s*BLOCKED:/.test(line)) blockedSteps.add(currentStep);
}
const stepsVerified = ledgerSteps.size;
const stepsBlocked = blockedSteps.size;
const captureFailed = count(enriched, /<!--\s*ELEMENT_CAPTURE_FAILED/g);
const elementsCaptured = count(enriched, /<!--\s*ELEMENT:/g);
const discovered = count(enriched, /<!--\s*DISCOVERED:/g);
const pagesDiscovered = count(enriched, /^###\s+/gm);
const appBehavior = (enriched.match(/##\s*App Behavior:\s*([a-z-]+)/i) || [])[1] || 'unknown';

// selector-strategy distribution (from ELEMENT primaries)
const strat = { idBased: 0, roleAndName: 0, cssAttribute: 0, hasText: 0, href: 0, testId: 0 };
(enriched.match(/"primary"\s*:\s*"([^"]*)"/g) || []).forEach((m) => {
  const p = m.replace(/.*"primary"\s*:\s*"/, '').replace(/"$/, '');
  if (p.startsWith('testid=')) strat.testId++;
  else if (p.startsWith('#')) strat.idBased++;
  else if (p.startsWith('role=')) strat.roleAndName++;
  else if (/:has-text\(/.test(p) || p.startsWith('text=')) strat.hasText++;
  else if (/^a?\[?href/.test(p) || p.includes("href=")) strat.href++;
  else strat.cssAttribute++;
});

// ---- 3. playwright-cli ground truth (the token-cost evidence) ----
let cliFiles = [];
try { cliFiles = fs.readdirSync(cliDir).map((f) => ({ f, full: path.join(cliDir, f) })); } catch { /* no dir */ }
const snapshotFiles = cliFiles.filter((x) => /^page-.*\.ya?ml$/.test(x.f));
const requestedStartMs = args.start ? new Date(args.start).getTime() : NaN;
const requestedEndMs = args.end ? new Date(args.end).getTime() : NaN;
const runSnapshotFiles = snapshotFiles.filter((x) => {
  if (!Number.isFinite(requestedStartMs) || !Number.isFinite(requestedEndMs)) return true;
  try {
    const modifiedAt = fs.statSync(x.full).mtimeMs;
    return modifiedAt >= requestedStartMs && modifiedAt <= requestedEndMs;
  } catch { return false; }
});
const mcpSnapshotCount = runSnapshotFiles.length; // GROUND TRUTH (beats LLM self-report)
// Snapshot byte mass — a non-fabricatable proxy for the Explorer's dominant token cost.
// Large full-page snapshots (unscoped grid pages) are the #1 driver; scoping snapshots +
// querying them via snapshot-query.js (instead of reading whole) is what cuts the cost.
// Lower bytes here = fewer tokens pulled into context. Track it so the win is measurable.
let snapshotBytesTotal = 0, snapshotBytesMax = 0;
for (const x of runSnapshotFiles) {
  try { const b = fs.statSync(x.full).size; snapshotBytesTotal += b; if (b > snapshotBytesMax) snapshotBytesMax = b; } catch { /* skip */ }
}
const snapshotTokenEstTotal = Math.round(snapshotBytesTotal / 4); // ~4 chars/token
const snapshotBytesAvg = mcpSnapshotCount ? Math.round(snapshotBytesTotal / mcpSnapshotCount) : 0;
// duration: explicit args win; else min→max mtime of cli artifacts
let durationMs = null, startISO = args.start || null, endISO = args.end || null;
if (startISO && endISO) durationMs = new Date(endISO) - new Date(startISO);
else if (cliFiles.length) {
  const ts = cliFiles.map((x) => { try { return fs.statSync(x.full).mtimeMs; } catch { return NaN; } }).filter((n) => !isNaN(n));
  if (ts.length) { durationMs = Math.round(Math.max(...ts) - Math.min(...ts)); startISO = new Date(Math.min(...ts)).toISOString(); endISO = new Date(Math.max(...ts)).toISOString(); }
}
const fmtDur = (ms) => (ms == null ? null : `${Math.floor(ms / 60000)}m ${Math.round((ms % 60000) / 1000)}s`);
// mcpInteractions: the CLI does not log a single command stream we can read, so we
// report a deterministic LOWER BOUND (snapshots + ledgered steps) and flag it — never fabricate.
const mcpInteractionsLowerBound = mcpSnapshotCount + stepsVerified;

// ---- 4. metrics JSON (deterministic) ----
const metrics = {
  metricsVersion: '2.2.0-cli',
  agent: 'explorer',
  scenario, folder: folder || null, type, mode: 'FULL',
  startTime: startISO, endTime: endISO, durationMs, durationFormatted: fmtDur(durationMs),
  stepsTotal: totalSteps, stepsVerified, stepsBlocked, stepsSkipped: Math.max(0, totalSteps - stepsVerified - stepsBlocked),
  pagesDiscovered, elementsCaptured, capturesFailed: captureFailed, discoveredNotes: discovered,
  mcpSnapshotCount,                              // GROUND TRUTH from .playwright-cli/page-*.yml
  snapshotBytesTotal,                            // token-cost proxy: total bytes of page-*.yml (lower = cheaper)
  snapshotBytesMax,                              // largest single snapshot (unscoped grids blow this up)
  snapshotBytesAvg,                              // avg snapshot size — scoping drives this down
  snapshotTokenEstTotal,                         // ~snapshotBytesTotal/4; NOT model tokens, a retrieval-cost proxy
  mcpInteractions: mcpInteractionsLowerBound,    // lower bound — see observabilityNote
  browserTouchingSteps: stepsVerified + stepsBlocked,
  ledgerMarkersEmitted: stepsVerified,
  selectorStrategies: strat,
  appBehavior,
  observabilityNote: 'snapshots/duration/steps computed deterministically from .playwright-cli trail + enriched LEDGER/ELEMENT markers. mcpInteractions is a lower bound (snapshots + ledgered steps); playwright-cli does not emit a single readable command log. LEDGER markers remain LLM-emitted (anti-fabrication) — this script only COUNTS them.',
  source: 'explorer-report-gen.js (deterministic)',
};

// ---- 5. eval metrics ----
const pct = (n, d) => (d ? Math.round((n / d) * 1000) / 10 : 0);
const evalMetrics = {
  explorationAccuracy: pct(stepsVerified, totalSteps),
  blockedRate: pct(stepsBlocked, totalSteps),
  captureCoverage: pct(elementsCaptured, elementsCaptured + captureFailed || 1),
};

// ---- 6. Step Results table (mechanical: step text + status + ledger) ----
// Associate each numbered step with verified/blocked status. Selector/Notes are
// left to the LLM/enriched (the enriched already carries ELEMENT primaries).
const stepLines = (stepsSec ? stepsSec[0] : scenarioMd).split(/\r?\n/);
let rows = '';
let n = 0;
for (const line of stepLines) {
  const m = line.match(/^\s*(\d+)\.\s+(.*)$/);
  if (!m) continue;
  n = Number(m[1]);
  const desc = stripHtmlComments(m[2]).replace(/\\/g, '\\\\').replace(/\|/g, '\\|').trim().slice(0, 120);
  const status = blockedSteps.has(n) ? 'BLOCKED' : (ledgerSteps.has(n) ? 'VERIFIED' : (n <= totalSteps ? 'SKIPPED/UNVERIFIED' : 'VERIFIED'));
  rows += `| ${n} | ${desc} | ${status} | <!-- LLM: selector + notes from enriched ELEMENT --> |\n`;
}

// ---- 7. report (mechanical sections filled; narrative = LLM placeholders, filled IN PLACE by the agent) ----
const reportMd = `# Explorer Report: ${scenario}

**Scenario:** ${scenario}
**Type:** ${type}
**Date:** ${endISO || new Date().toISOString()}
**Pipeline Stage:** Stage 1 — Explorer (Playwright CLI)
**Duration:** ${fmtDur(durationMs) || '<!-- LLM -->'}
**Outcome:** ${stepsBlocked === 0 && captureFailed === 0 ? 'COMPLETE' : 'PARTIAL'}
**Steps:** ${stepsVerified}/${totalSteps} verified (${stepsBlocked} blocked)
**Pages Discovered:** ${pagesDiscovered}
**Elements Captured:** ${elementsCaptured}
**App Behavior:** ${appBehavior}

> NOTE: mechanical sections below are computed by explorer-report-gen.js from the
> .playwright-cli trail + enriched LEDGER/ELEMENT markers. Fill only the <!-- LLM: ... --> parts.

## Step Results
| Step | Description | Status | Selector Used / Notes |
|------|-------------|--------|-----------------------|
${rows}
## Observability
- **Duration:** ${fmtDur(durationMs) || 'n/a'}
- **Snapshots taken:** ${mcpSnapshotCount} (ground truth — .playwright-cli/page-*.yml)
- **MCP/CLI interactions:** ≥ ${mcpInteractionsLowerBound} (lower bound)
- **Elements captured:** ${elementsCaptured}  |  **Pages:** ${pagesDiscovered}
- **Selector strategies:** ${JSON.stringify(strat)}

## Eval Metrics
| Metric | Value |
|--------|-------|
| Exploration accuracy | ${evalMetrics.explorationAccuracy}% |
| Blocked rate | ${evalMetrics.blockedRate}% |
| Capture coverage | ${evalMetrics.captureCoverage}% |

## Key Decisions Made
<!-- LLM: document non-obvious decisions (pacing, row-scoping, strict-mode picks). The script cannot infer these. -->

## Dynamic Content Map
<!-- LLM: which actions triggered async loads + the wait that worked. -->

## Issues and Warnings
<!-- LLM: blocked steps, potential bugs, app quirks. Or "None." -->
`;

// ---- write ----
fs.mkdirSync(path.dirname(paths.metrics), { recursive: true });
fs.mkdirSync(path.dirname(paths.report), { recursive: true });
fs.writeFileSync(paths.metrics, JSON.stringify(metrics, null, 2), 'utf-8');
fs.writeFileSync(paths.report, reportMd, 'utf-8');
// Defensive: remove any legacy *.scaffold.md left by the pre-in-place flow so it never lingers.
const legacyScaffold = path.join(outputDir, 'reports', folderPrefix, `explorer-report-${scenario}.scaffold.md`);
try { if (fs.existsSync(legacyScaffold)) fs.unlinkSync(legacyScaffold); } catch { /* best effort */ }

console.log(JSON.stringify({
  wrote: { metrics: paths.metrics, report: paths.report },
  groundTruth: { mcpSnapshotCount, stepsVerified, totalSteps, elementsCaptured, durationMs },
  note: 'Report is written to the FINAL .md (no scaffold temp). The agent fills the <!-- LLM: --> placeholders IN PLACE. LLM also writes the enriched.md ELEMENT + LEDGER markers. Mechanical report + metrics are deterministic.',
}, null, 2));
