import { test } from '../web/fixtures';
import { readFileSync } from 'node:fs';
import { basename, join } from 'node:path';

const testDataPath = join(__dirname, '../../test-data/web', `${basename(__filename, '.spec.ts')}.json`);
const testData = JSON.parse(readFileSync(testDataPath, 'utf-8')) as {
  quantity: string;
  successMessage: string;
};

test.describe('Create Inventory Adjustment - Theft - Manual Type Mode', () => {
  test('Create a Theft inventory adjustment in Type Mode', { tag: ['@P1', '@inventory-adjustment'] }, async ({ loginPage, homePage, inventoryAdjustmentPage }) => {

    const steps: Array<{ title: string; action: () => Promise<void> }> = [
      { title: 'Step 1 — Navigate to the application', action: () => loginPage.navigateToApp(process.env.BASE_URL!) },
      { title: 'Step 2 — VERIFY the login page is displayed', action: () => loginPage.verifyEmployeeIdInputVisible() },
      { title: 'Step 3 — Log in with Employee ID and passcode', action: () => loginPage.login(process.env.GOODFOOD_EMPLOYEE_ID!, process.env.GOODFOOD_PASSCODE!) },
      { title: 'Step 4 — Click Choose the Store dropdown list', action: () => homePage.openStoreDropdown() },
      { title: 'Step 5 — Select the Department 000006 - Long Beach', action: () => homePage.selectLongBeachStore() },
      { title: 'Step 6 — Click the Adjust Inventory option', action: () => homePage.openAdjustInventory() },
      { title: 'Step 7 — Select Theft', action: () => inventoryAdjustmentPage.selectTheftReason() },
      { title: 'Step 8 — Switch to Type Mode', action: () => inventoryAdjustmentPage.switchToTypeMode() },
      { title: 'Step 9 — Enter a valid UPC', action: () => inventoryAdjustmentPage.fillUpc(process.env.GOODFOOD_UPC!) },
      { title: 'Step 10 — Press Enter to search', action: () => inventoryAdjustmentPage.submitUpcLookup() },
      { title: 'Step 11 — VERIFY the item details are displayed', action: () => inventoryAdjustmentPage.verifyItemDetailsVisible() },
      { title: 'Step 12 — Enter the adjustment quantity', action: () => inventoryAdjustmentPage.fillQuantity(testData.quantity) },
      { title: 'Step 13 — VERIFY the quantity is accepted', action: () => inventoryAdjustmentPage.verifyQuantityAccepted(testData.quantity) },
      { title: 'Step 14 — Click the Submit button', action: () => inventoryAdjustmentPage.submitAdjustment() },
      { title: 'Step 15 — VERIFY the success modal/message is displayed', action: () => inventoryAdjustmentPage.verifySuccessMessage(testData.successMessage) },
    ];

    for (const step of steps) {
      await test.step(step.title, step.action);
    }
  });
});