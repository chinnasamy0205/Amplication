import { expect, test } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { StoreSelectionPage } from '../../pages/StoreSelectionPage';
import { StoreHomePage } from '../../pages/StoreHomePage';
import { AdjustInventoryPage } from '../../pages/AdjustInventoryPage';
import { SpoilagePage } from '../../pages/SpoilagePage';
import testData from '../../test-data/web/tc_inv_spoilage_001.json';

test.describe('Verify Default UI of Inventory Spoilage Screen', () => {
  test('Verify default UI elements displayed on Inventory Spoilage screen', { tag: ['@web', '@P1', '@UI-validation', '@inventory-spoilage'] }, async ({ page }) => {
    test.skip(!process.env.GOODFOOD_EMPLOYEE_ID || !process.env.GOODFOOD_PASSCODE, 'USER FIX REQUIRED: EMPLOYEE_ID and PASSCODE must be set in output/.env; see executor report');
    const loginPage = new LoginPage(page);
    const storeSelectionPage = new StoreSelectionPage(page);
    const storeHomePage = new StoreHomePage(page);
    const adjustInventoryPage = new AdjustInventoryPage(page);
    const spoilagePage = new SpoilagePage(page);

    await test.step('Step 1 — Navigate to {{ENV.BASE_URL}}', async () => {
      await loginPage.navigateToApp(process.env.BASE_URL!);
    });

    await test.step('Step 2 — Log in using Employee ID {{ENV.GOODFOOD_EMPLOYEE_ID}} and Passcode {{ENV.GOODFOOD_    PASSCODE}}', async () => {
      await loginPage.fillEmployeeId(process.env.GOODFOOD_EMPLOYEE_ID!);
      await loginPage.fillPasscode(process.env.GOODFOOD_PASSCODE!);
      await loginPage.clickLogin();
      await storeSelectionPage.waitForStoreSelection();
    });

    await test.step(`Step 3 — Select the ${testData.department} department`, async () => {
      await storeSelectionPage.selectLongBeachStore();
    });

    await test.step('Step 4 — VERIFY: The department is selected and the dashboard/home screen is displayed', async () => {
    await expect(storeHomePage.getLocator('activeStoreTxt')).toBeVisible({ timeout: 30000 });
    });

    await test.step('Step 5 — Navigate to the Adjust Inventory menu', async () => {
      await storeHomePage.openInventoryAdjustment();
    });

    await test.step('Step 6 — VERIFY: Adjust Inventory options are displayed', async () => {
    await expect(adjustInventoryPage.getLocator('theftBtn')).toBeVisible({ timeout: 30000 });
    });

    await test.step('Step 7 — Select the Spoilage option', async () => {
      await adjustInventoryPage.clickSpoilage();
    });

    await test.step('Step 8 — VERIFY: The Spoilage screen is opened', async () => {
      await spoilagePage.assertTitleVisible();
    });

    await test.step('Step 9 — VERIFY: The title bar displays a Back Arrow button on the left, "Spoilage" text in the center, and a Help (Question Mark) icon on the right', async () => {
      await spoilagePage.assertBackArrowVisible();
      await spoilagePage.assertTitleVisible();
      await spoilagePage.assertHelpIconVisible();
    });

    await test.step('Step 10 — VERIFY: The UPC text field is displayed with Scan and Type toggle options', async () => {
      await spoilagePage.assertUpcInputVisible();
      await spoilagePage.assertScanModeSwitchVisible();
    });

    await test.step('Step 11 — VERIFY: Scan is selected by default', async () => {
      await spoilagePage.assertScanModeSelected();
    });

    await test.step('Step 12 — VERIFY: The UPC field placeholder text is "Scan upc"', async () => {
      await spoilagePage.assertUpcPlaceholder(testData.upcPlaceholder);
    });

    await test.step('Step 13 — VERIFY: Shrink and Correction radio buttons are displayed, if i Correction choose Minus (-) controls', async () => {
      await spoilagePage.assertShrinkRadioVisible();
      await spoilagePage.assertCorrectionRadioVisible();
      await spoilagePage.assertShrinkSelected();
      await spoilagePage.selectCorrection();
      await spoilagePage.assertQuantitySign(testData.correctionQuantitySign);
      await spoilagePage.selectShrink();
    });

    await test.step('Step 14 — VERIFY: Shrink is selected by default', async () => {
      await spoilagePage.assertShrinkSelected();
    });

    await test.step('Step 15 — VERIFY: The quantity text box is displayed', async () => {
      await spoilagePage.assertQuantityInputVisible();
    });

    await test.step('Step 16 — VERIFY: Minus (-) controls are displayed along with the quantity field', async () => {
      await spoilagePage.assertQuantitySign(testData.shrinkQuantitySign);
    });

    await test.step('Step 17 — VERIFY: The Submit button is displayed with a Tailwind teal-500 background and remains disabled by default', async () => {
      await spoilagePage.assertSubmitButtonVisible();
      await spoilagePage.assertSubmitButtonTeal(testData.submitButtonClassPattern);
      await spoilagePage.assertSubmitButtonDisabled();
    });

    await test.step('Step 18 — VERIFY: All specified UI elements are displayed and default selections and states match the requirements', async () => {
      await spoilagePage.assertBackArrowVisible();
      await spoilagePage.assertTitleVisible();
      await spoilagePage.assertHelpIconVisible();
      await spoilagePage.assertUpcPlaceholder(testData.upcPlaceholder);
      await spoilagePage.assertScanModeSelected();
      await spoilagePage.assertShrinkSelected();
      await spoilagePage.assertCorrectionRadioVisible();
      await spoilagePage.assertQuantityInputVisible();
      await spoilagePage.assertQuantitySign(testData.shrinkQuantitySign);
      await spoilagePage.assertSubmitButtonVisible();
      await spoilagePage.assertSubmitButtonTeal(testData.submitButtonClassPattern);
      await spoilagePage.assertSubmitButtonDisabled();
    });

    await test.step('Step 19 — VERIFY: No UI component is missing or incorrectly displayed or labeled, and no default selection or state differs from the expected behavior', async () => {
      await spoilagePage.assertShrinkAccessibleName(testData.shrinkText);
      await spoilagePage.assertCorrectionAccessibleName(testData.correctionText);
      await spoilagePage.assertUpcPlaceholder(testData.upcPlaceholder);
      await spoilagePage.assertScanModeSelected();
      await spoilagePage.assertShrinkSelected();
      await spoilagePage.assertSubmitButtonDisabled();
    });
  });
});