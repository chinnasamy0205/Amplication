import { expect, test as base } from '@playwright/test';
import { HomePage } from '../../pages/HomePage';
import { InventoryAdjustmentPage } from '../../pages/InventoryAdjustmentPage';
import { LoginPage } from '../../pages/LoginPage';

type WebFixtures = {
  loginPage: LoginPage;
  homePage: HomePage;
  inventoryAdjustmentPage: InventoryAdjustmentPage;
};

export const test = base.extend<WebFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },
  homePage: async ({ page }, use) => {
    await use(new HomePage(page));
  },
  inventoryAdjustmentPage: async ({ page }, use) => {
    await use(new InventoryAdjustmentPage(page));
  },
});

export { expect };