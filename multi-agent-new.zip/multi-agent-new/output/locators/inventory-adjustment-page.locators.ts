export interface IInventoryAdjustmentPageLocators extends Record<string, string> {
  theftBtn: "role=button[name='Theft']";
  spoilageBtn: "role=button[name='Spoilage']";
  scanTypeChk: "role=switch[name='Scan Type']";
  upcTxt: "role=textbox[name='Enter upc']";
  itemDetailsLbl: 'text=COKE DIET FR 12 PK';
  quantityTxt: "role=textbox[name='0']";
  submitAdjustmentBtn: "role=button[name='Submit']";
  adjustmentSuccessPopUp: 'role=dialog';
  recentAdjustmentsTbl: 'text=Theft';
  theftAdjustmentBtn: "role=button[name='Theft']";
  upcErrorMessageLbl: 'text=Item not in file';
  submitBtn: "role=button[name='Submit']";
  theftButton: "role=button[name='Theft']";
  scanTypeSwitch: "role=switch[name='Scan Type']";
  upcInput: "role=textbox[name='Enter upc']";
  itemDetails: 'text=Recent Adjustments';
  quantityInput: "role=textbox[name='0']";
  submitButton: "role=button[name='Submit']";
  adjustmentSuccessMessage: 'text=Inventory adjustment added successfully';
}

export const inventoryAdjustmentPageLocators: IInventoryAdjustmentPageLocators = {
  theftBtn: "role=button[name='Theft']",
  spoilageBtn: "role=button[name='Spoilage']",
  scanTypeChk: "role=switch[name='Scan Type']",
  upcTxt: "role=textbox[name='Enter upc']",
  itemDetailsLbl: 'text=COKE DIET FR 12 PK',
  quantityTxt: "role=textbox[name='0']",
  submitAdjustmentBtn: "role=button[name='Submit']",
  adjustmentSuccessPopUp: 'role=dialog',
  recentAdjustmentsTbl: 'text=Theft',
  theftAdjustmentBtn: "role=button[name='Theft']",
  upcErrorMessageLbl: 'text=Item not in file',
  submitBtn: "role=button[name='Submit']",
  theftButton: "role=button[name='Theft']",
  scanTypeSwitch: "role=switch[name='Scan Type']",
  upcInput: "role=textbox[name='Enter upc']",
  itemDetails: 'text=Recent Adjustments',
  quantityInput: "role=textbox[name='0']",
  submitButton: "role=button[name='Submit']",
  adjustmentSuccessMessage: 'text=Inventory adjustment added successfully',
};
