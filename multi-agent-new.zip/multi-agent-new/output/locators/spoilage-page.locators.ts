export interface ISpoilagePageLocators extends Record<string, string> {
  lblSpoilageTitle: 'text=Spoilage';
  iconBackArrow: string;
  iconHelp: string;
  txtUpcInput: '#txtupc';
  chkManualMode: '#manual-mode';
  rdoShrink: '#r1';
  rdoCorrection: '#r2';
  txtQuantity: string;
  lblQuantitySign: string;
  btnSubmit: "role=button[name='Submit']";
}

export const spoilagePageLocators: ISpoilagePageLocators = {
  lblSpoilageTitle: 'text=Spoilage',
  iconBackArrow: 'svg.lucide-circle-arrow-left',
  iconHelp: 'svg.lucide-circle-question-mark',
  txtUpcInput: '#txtupc',
  chkManualMode: '#manual-mode',
  rdoShrink: '#r1',
  rdoCorrection: '#r2',
  txtQuantity: "input[placeholder='0']",
  lblQuantitySign: "label:has-text('(-)'), label:has-text('(+)')",
  btnSubmit: "role=button[name='Submit']",
};
