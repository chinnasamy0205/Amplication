export interface IAdjustInventoryPageLocators extends Record<string, string> {
  theftBtn: "role=button[name='Theft']";
  spoilageBtn: "role=button[name='Spoilage']";
}

export const adjustInventoryPageLocators: IAdjustInventoryPageLocators = {
  theftBtn: "role=button[name='Theft']",
  spoilageBtn: "role=button[name='Spoilage']",
};
