export interface IStoreSelectionPageLocators extends Record<string, string> {
  storeDropdownSel: string;
  longBeachStoreOptn: string;
  activeStoreTxt: string;
  activeDepartmentTxt: string;
  adjustInventoryBtn: string;
  storeSelectorSel: string;
  storeSelectionHeadingLbl: string;
}

export const storeSelectionPageLocators: IStoreSelectionPageLocators = {
  storeDropdownSel: 'role=combobox',
  longBeachStoreOptn: "role=option[name='000006 - Long Beach']",
  activeStoreTxt: 'text=Long Beach',
  activeDepartmentTxt: 'text=02 - Grocery',
  adjustInventoryBtn: "role=button[name='Adjust Inventory']",
  storeSelectorSel: 'role=combobox',
  storeSelectionHeadingLbl: "role=heading[name='Choose Your Store Location']",
};
