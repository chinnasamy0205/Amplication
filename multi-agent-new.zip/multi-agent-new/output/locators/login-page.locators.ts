export interface ILoginPageLocators extends Record<string, string> {
  employeeIdTxt: string;
  passcodeTxt: string;
  loginBtn: string;
  employeeIdInput: string;
  passcodeInput: string;
  loginButton: string;
}

export const loginPageLocators: ILoginPageLocators = {
  employeeIdTxt: "role=textbox[name='Employee Id']",
  passcodeTxt: "role=textbox[name='Passcode']",
  loginBtn: "role=button[name='Log in']",
  employeeIdInput: "role=textbox[name='Employee Id']",
  passcodeInput: "role=textbox[name='Passcode']",
  loginButton: "role=button[name='Log in']",
};
