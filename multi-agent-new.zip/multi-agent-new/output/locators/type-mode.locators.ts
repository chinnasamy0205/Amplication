export interface ITypeModeLocators extends Record<string, string> {}

export const typeModeLocators: ITypeModeLocators = {};
