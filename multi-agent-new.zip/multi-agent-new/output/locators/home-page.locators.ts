export interface IHomePageLocators extends Record<string, string> {
  chooseStoreCombobox: 'role=combobox';
  longBeachOption: "role=option[name='000006 - Long Beach']";
  adjustInventoryButton: "role=button[name='Adjust Inventory']";
}

export const homePageLocators: IHomePageLocators = {
  chooseStoreCombobox: 'role=combobox',
  longBeachOption: "role=option[name='000006 - Long Beach']",
  adjustInventoryButton: "role=button[name='Adjust Inventory']",
};