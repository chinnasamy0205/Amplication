export interface IScanModeLocators extends Record<string, string> {
  scanTypeChk: "role=switch[name='Scan Type']";
}

export const scanModeLocators: IScanModeLocators = {
  scanTypeChk: "role=switch[name='Scan Type']",
};
