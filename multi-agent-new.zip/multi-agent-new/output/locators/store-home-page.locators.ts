export interface IStoreHomePageLocators extends Record<string, string> {
  activeStoreNameTxt: string;
  activeStoreTxt: string;
  adjustInventoryBtn: string;
}

export const storeHomePageLocators: IStoreHomePageLocators = {
  activeStoreNameTxt: 'text=Long Beach',
  activeStoreTxt: 'text=Long Beach',
  adjustInventoryBtn: "role=button[name='Adjust Inventory']",
};
