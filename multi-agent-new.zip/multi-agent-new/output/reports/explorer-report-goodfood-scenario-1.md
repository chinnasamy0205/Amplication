# Explorer Report: goodfood-scenario-1

**Scenario:** goodfood-scenario-1
**Type:** web
**Date:** 2026-10-27T06:26:11Z
**Pipeline Stage:** Stage 1 — Explorer (Playwright CLI)
**Duration:** 3m 51s
**Outcome:** COMPLETE
**Steps:** 15/15 verified (0 blocked)
**Pages Discovered:** 3
**Elements Captured:** 16
**App Behavior:** unknown

> Mechanical counts below are computed by explorer-report-gen.js from the .playwright-cli trail and enriched LEDGER/ELEMENT markers.

## Step Results
| Step | Description | Status | Selector Used / Notes |
|------|-------------|--------|-----------------------|
| 1 | Navigate to https://test.storeiq.goodfoodholdings.com/ | VERIFIED | N/A (navigation); landed on StoreIQ login page |
| 2 | VERIFY the login page is displayed | VERIFIED | `role=textbox[name='Employee Id']`; login form visible |
| 3 | Log in with Employee ID `10205` and passcode `123456` | VERIFIED | Employee Id + Passcode textboxes, `role=button[name='Log in']`; home view loaded |
| 4 | Click Choose the Store dropdown list | VERIFIED | `role=combobox`; opened Stores list |
| 5 | Select the Department `000006 - Long Beach` | VERIFIED | `role=option[name='000006 - Long Beach']`; UI labels choice as a store |
| 6 | Click the "Adjust Inventory" option | VERIFIED | `role=button[name='Adjust Inventory']`; navigated to `/adjust-inventory` |
| 7 | Select "Theft" | VERIFIED | `role=button[name='Theft']` |
| 8 | Switch to "Type Mode" | VERIFIED | `role=switch[name='Scan Type']`; Type mode became active |
| 9 | Enter a valid UPC `049000028911` | VERIFIED | `role=textbox[name='Enter upc']` |
| 10 | Press Enter or click Search | VERIFIED | Enter pressed; item details loaded, no separate Search button observed |
| 11 | VERIFY the item details are displayed (item loaded correctly) | VERIFIED | Item detail and Recent Adjustments content visible |
| 12 | Enter quantity `5` | VERIFIED | `role=textbox[name='0']`; value entered |
| 13 | VERIFY the quantity is accepted | VERIFIED | Value remained visible and Submit was enabled |
| 14 | Click the Submit button | VERIFIED | `role=button[name='Submit']`; form submitted |
| 15 | VERIFY the success modal/message is displayed | VERIFIED | Dialog showed "Inventory adjustment added successfully" |

## Observability
- **Duration:** 3m 51s
- **Snapshots taken:** 10 (ground truth — .playwright-cli/page-*.yml)
- **MCP/CLI interactions:** ≥ 25 (lower bound)
- **Elements captured:** 16  |  **Pages:** 3
- **Selector strategies:** {"idBased":0,"roleAndName":14,"cssAttribute":0,"hasText":2,"href":0,"testId":0}

## Eval Metrics
| Metric | Value |
|--------|-------|
| Exploration accuracy | 100% |
| Blocked rate | 0% |
| Capture coverage | 100% |

## Key Decisions Made
The requested `000006 - Long Beach` choice was selected as listed in the Store picker. The application labels the control/value as a store, while the scenario describes it as a department; the following department displayed as `02 - Grocery`. Type Mode was confirmed by the switch becoming checked and the UPC placeholder changing to "Enter upc". The UPC lookup was submitted with Enter because no Search button was present. No credentials or UPC values were copied into the enriched scenario; it references the configured environment variables.

## Dynamic Content Map
| Action | Step | Content That Loads | Wait Strategy Used | Approx Duration |
|--------|------|-------------------|-------------------|-----------------|
| Login submit | 3 | Authenticated home view and store picker | Fresh snapshot after click | Not timed |
| Select Long Beach | 5 | Operational home view and department selector | Fresh snapshot after selection | Not timed |
| Adjust Inventory | 6 | Inventory adjustment page | URL change to `/adjust-inventory` and fresh snapshot | Not timed |
| Enter UPC and press Enter | 10 | Item details and Recent Adjustments | Fresh snapshot after Enter | Not timed |
| Submit adjustment | 14 | Success dialog | Fresh snapshot after submit | Not timed |

## Issues and Warnings
No blocked steps. Scenario wording calls `000006 - Long Beach` a department, but the live app presents it as a store selection and shows `02 - Grocery` as the department. No alternate selection was attempted. The adjustment completed and the success dialog was observed.
