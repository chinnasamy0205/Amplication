# Builder Report: tc_inv_spoilage_001

**Scenario:** tc_inv_spoilage_001
**Type:** web
**Date:** October 26, 2026, 08:54 AM UTC
**Pipeline Stage:** Stage 1b — Builder
**Duration:** 1m 26s
**Outcome:** PARTIAL
**Pages Generated:** 0 page objects from 5 enriched.md sections (all reused)
**Spec Steps:** 19 `test.step()` blocks matching 19 scenario steps
**Fidelity:** 14 VERIFY, 0 CAPTURE, 0 SCREENSHOT, 0 REPORT, 0 CALCULATE
**Missing Elements:** 0 steps flagged with `test.fixme()` for capture gaps
**Blocked Steps:** 1 Explorer-blocked step (step 2 login); steps 12-13 were not live-verified

---

## Files Generated
| File | Status | Details |
|------|--------|---------|
| output/tests/web/tc_inv_spoilage_001.spec.ts | updated | Steps 12-13 only; step 12 already matched the current expectation, step 13 now checks Correction and the annotated minus control. Steps 18-19 preserved unchanged. |
| output/reports/builder-report-tc_inv_spoilage_001.md | updated | This incremental run report. |
| output/reports/metrics/builder-metrics-tc_inv_spoilage_001.json | updated | Metrics for this Builder run. |
| Page objects, locator JSONs, test data | unchanged | Reused; no locator JSON was overwritten. |

---

## Locator JSON Usage
| Locator File | Page Object | Keys Used | Keys Available | Coverage |
|-------------|-------------|-----------|----------------|----------|
| login-page.locators.json | LoginPage.ts | 3 | 3 | 100% |
| store-selection-page.locators.json | StoreSelectionPage.ts | 3 | 7 | 43% |
| store-home-page.locators.json | StoreHomePage.ts | 2 | 3 | 67% |
| adjust-inventory-page.locators.json | AdjustInventoryPage.ts | 2 | 2 | 100% |
| spoilage-page.locators.json | SpoilagePage.ts | 10 | 10 | 100% |
| **Total** | | **20** | **25** | **80%** |

---

## Missing Elements (Capture Gaps)
All scenario elements used by the generated checks have existing annotations. No capture-gap `test.fixme()` blocks were added. Explorer records authentication blocked at step 2; later steps, including 12 and 13, were not live-verified.

---

## Decisions Made
1. Step 12 retains the scenario expectation `Scan upc` and its placeholder assertion. Explorer did not check this exact placeholder in this partial run, so the assertion is not described as live-confirmed.
2. Step 13 checks both annotated radio controls, selects the annotated Correction control, then checks the existing annotated minus label. This implements the enriched scenario's control expectation without claiming Explorer observed the resulting behavior.
3. Existing step 18 and step 19 assertions remain unchanged, including their scenario expectations; no expected app behavior was altered.
4. `App Behavior: unknown` uses the existing bounded visibility assertions; no locator or page-object changes were needed.

---

## Self-Audit Results
- Step count match: YES (19 scenario steps vs 19 spec steps)
- VERIFY count match: YES (14 VERIFY scenario steps; 14 implemented)
- CAPTURE count match: YES (0 vs 0)
- SCREENSHOT count match: YES (0 vs 0)
- REPORT count match: YES (0 vs 0)
- CALCULATE count match: YES (0 vs 0)
- Raw selectors in spec: 0 (target: 0)
- Raw selectors in page objects: 0 (target: 0)

---

## Observability
| Metric | Value |
|--------|-------|
| Duration | 1m 26s |
| Pages generated | 0 (5 existing page objects reused) |
| Methods generated | 0 |
| Locator keys used | 20 of 25 |
| Token usage | N/A — platform does not expose token counts |

## Eval Metrics
| Metric | Value |
|--------|-------|
| Step count match | YES (19 vs 19) |
| Locator coverage | 80% (20 keys used / 25 available) |
| Raw selector leakage | 0 in spec, 0 in page objects (target: 0) |
| Capture-gap rate | 0% (0 `test.fixme()` capture gaps / 19 steps) |
| Incremental mode hit rate | 89.5% (17 unchanged / 19 total; 2 marked modified) |
