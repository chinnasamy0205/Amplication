# Explorer Report: tc_inv_spoilage_001

**Scenario:** tc_inv_spoilage_001
**Type:** web
**Date:** 2026-10-26T08:51:56.716Z
**Pipeline Stage:** Stage 1 — Explorer (Playwright CLI)
**Duration:** 0m 46s
**Outcome:** PARTIAL
**Steps:** 1/19 verified (1 blocked; 17 unverified)
**Pages Discovered:** 1 (LoginPage)
**Elements Captured:** 0 in this run
**App Behavior:** unknown

> NOTE: the enriched file contains pre-existing LEDGER/ELEMENT annotations. This run's counts below are scoped to this session; prior annotations were not treated as newly verified evidence.

## Step Results
| Step | Description | Status | Selector Used / Notes |
|------|-------------|--------|-----------------------|
| 1 | Navigate to {{ENV.BASE_URL}} | VERIFIED | StoreIQ login form rendered |
| 2 | Log in using Employee ID {{ENV.EMPLOYEE_ID}} and Passcode {{ENV.PASSCODE}} | BLOCKED | Required credential keys absent from output/.env and process environment; values were not displayed |
| 3 | Select the `000006 - Long Beach` department | SKIPPED/UNVERIFIED | Authentication blocked |
| 4 | VERIFY: The department is selected and the dashboard/home screen is displayed | SKIPPED/UNVERIFIED | Authentication blocked |
| 5 | Navigate to the Adjust Inventory menu | SKIPPED/UNVERIFIED | Authentication blocked |
| 6 | VERIFY: Adjust Inventory options are displayed | SKIPPED/UNVERIFIED | Authentication blocked |
| 7 | Select the Spoilage option | SKIPPED/UNVERIFIED | Authentication blocked |
| 8 | VERIFY: The Spoilage screen is opened | SKIPPED/UNVERIFIED | Authentication blocked |
| 9 | VERIFY: The title bar displays a Back Arrow button on the left, "Spoilage" text in the center, and a Help (Question Mark | SKIPPED/UNVERIFIED | Authentication blocked |
| 10 | VERIFY: The UPC text field is displayed with Scan and Type toggle options | SKIPPED/UNVERIFIED | Authentication blocked |
| 11 | VERIFY: Scan is selected by default | SKIPPED/UNVERIFIED | Authentication blocked |
| 12 | VERIFY: The UPC field placeholder text is "Scan upc" | SKIPPED/UNVERIFIED | Required exact placeholder was not checked live |
| 13 | VERIFY: Shrink and Correction radio buttons are displayed, if i Correction choose Minus (-) controls | SKIPPED/UNVERIFIED | Correction was not selected; resulting control behavior was not observed |
| 14 | VERIFY: Shrink is selected by default | SKIPPED/UNVERIFIED | Authentication blocked |
| 15 | VERIFY: The quantity text box is displayed | SKIPPED/UNVERIFIED | Authentication blocked |
| 16 | VERIFY: Minus (-) controls are displayed along with the quantity field | SKIPPED/UNVERIFIED | Authentication blocked |
| 17 | VERIFY: The Submit button is displayed with a Tailwind teal-500 background and remains disabled by default | SKIPPED/UNVERIFIED | Authentication blocked |
| 18 | VERIFY: All specified UI elements are displayed and default selections and states match the requirements | SKIPPED/UNVERIFIED | Authentication blocked |
| 19 | VERIFY: No UI component is missing or incorrectly displayed or labeled, and no default selection or state differs from t | SKIPPED/UNVERIFIED | Authentication blocked |

## Observability
- **Duration:** 0m 46s
- **Snapshots taken:** 2 (ground truth — .playwright-cli/page-*.yml)
- **MCP/CLI interactions:** 3 lower-bound units (2 current-run snapshots + 1 verified step)
- **Elements captured:** 0 in this run  |  **Pages:** 1
- **Selector strategies:** {"idBased":8,"roleAndName":10,"cssAttribute":4,"hasText":3,"href":0,"testId":0}

## Eval Metrics
| Metric | Value |
|--------|-------|
| Exploration accuracy | 5.3% |
| Blocked rate | 5.3% |
| Capture coverage | n/a (no elements captured) |

## Key Decisions Made
Used only configured headless Chromium and the configured 1920x1080 viewport. No credentials were printed or exposed. The login page was present, so no scenario steps after navigation were attempted.

## Dynamic Content Map
| Action | Step | Content That Loads | Wait Strategy Used | Approx Duration |
|--------|------|--------------------|-------------------|-----------------|
| Navigate to configured application URL | 1 | StoreIQ login form | CLI navigation then accessibility snapshot | Under 1 minute |

## Issues and Warnings
Missing Employee ID and Passcode values prevented authentication. Step 12's exact placeholder expectation ("Scan upc") and Step 13's Correction-selected control behavior, including whether Minus (-) controls appear, were not verified. No scenario intent or enriched.md content was changed.
