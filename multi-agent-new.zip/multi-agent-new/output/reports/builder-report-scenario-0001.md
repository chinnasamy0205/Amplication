# Builder Report: scenario-0001

**Scenario:** scenario-0001
**Type:** web
**Date:** October 23, 2026, 10:10 AM UTC
**Pipeline Stage:** Stage 1b — Builder
**Duration:** 3m 25s
**Outcome:** PARTIAL
**Pages Generated:** 6 page objects from 6 enriched.md sections
**Spec Steps:** 25 test.step() blocks matching 25 scenario steps
**Fidelity:** 4 VERIFY assertions, 0 CAPTURE, 0 SCREENSHOT, 0 REPORT, 0 CALCULATE
**Missing Elements:** 16 steps represented with test.fixme due to the Explorer blocker
**Blocked Steps:** 16 (steps 9, 11-25)

## Files Generated
| File | Status | Details |
|------|--------|---------|
| output/tests/web/scenario-0001.spec.ts | new | All 25 steps in source order; 16 blocked steps use test.fixme |
| output/test-data/web/scenario-0001.json | new | Exact department; unknown UPC and date remain null |
| output/pages/LoginPage.ts | reused | Existing verified login methods |
| output/pages/StoreSelectionPage.ts | reused | Existing verified department selection method |
| output/pages/StoreHomePage.ts | new | 2 methods for captured active-store and Adjust Inventory controls |
| output/pages/InventoryAdjustmentPage.ts | updated | Added the captured Spoilage action |
| output/pages/ScanModePage.ts | new | 1 method for the captured Scan Type switch |
| output/pages/TypeModePage.ts | new | Empty page object for the blocked-only TypeMode section |
| output/locators/login-page.locators.json | updated | Existing keys aligned to the current Explorer annotations |
| output/locators/store-selection-page.locators.json | updated | Added store-selection heading and aligned department selector |
| output/locators/store-home-page.locators.json | new | 2 annotated elements |
| output/locators/inventory-adjustment-page.locators.json | updated | Added Spoilage button and screen-title annotations |
| output/locators/scan-mode.locators.json | new | 1 annotated element |
| output/locators/type-mode.locators.json | new | Empty; the section has no captured elements |
| output/reports/builder-report-scenario-0001.md | new | This report |
| output/reports/metrics/builder-metrics-scenario-0001.json | new | Builder metrics |

## Locator JSON Usage
| Locator File | Page Object | Keys Used | Keys Available | Coverage |
|-------------|-------------|-----------|----------------|----------|
| login-page.locators.json | LoginPage.ts | 3 | 3 | 100% |
| store-selection-page.locators.json | StoreSelectionPage.ts | 2 | 7 | 29% |
| store-home-page.locators.json | StoreHomePage.ts | 2 | 2 | 100% |
| inventory-adjustment-page.locators.json | InventoryAdjustmentPage.ts | 2 | 13 | 15% |
| scan-mode.locators.json | ScanModePage.ts | 1 | 1 | 100% |
| type-mode.locators.json | TypeModePage.ts | 0 | 0 | N/A |
| **Total** |  | **10** | **26** | **38%** |

Coverage counts every key in reused locator JSON files, including keys owned by other scenarios. The nine keys referenced here all trace to ELEMENT annotations in the supplied enriched scenario.

## Missing Elements (Capture Gaps)
| Step | Description | Page | Action Needed |
|------|-------------|------|--------------|
| 9 | VERIFY weighted Type 2 UPC availability | InventoryAdjustmentPage | Provide/verify the prerequisite UPC, then rerun Explorer |
| 11 | Search for prerequisite weighted Type 2 UPC | ScanMode | Unblocked only after step 9 prerequisite is verified |
| 12 | VERIFY loaded weighted Type 2 item | ScanMode | Unblocked only after verified item is loaded |
| 13 | Click date picker icon | ScanMode | Rerun Explorer after verified item is available |
| 14 | Select a prior date | ScanMode | Rerun Explorer after verified item is available |
| 15 | VERIFY selected date is earlier than today | ScanMode | Rerun Explorer after date selection is available |
| 16 | Submit/create spoilage entry | ScanMode | Rerun Explorer after verified item and date are available |
| 17 | VERIFY Scan Mode entry creation | ScanMode | Rerun Explorer after a valid entry can be created |
| 18 | Switch to Type Mode | TypeMode | Rerun Explorer after prerequisite is verified |
| 19 | Search for the same weighted Type 2 UPC | TypeMode | Unblocked only after step 9 prerequisite is verified |
| 20 | VERIFY loaded weighted Type 2 item | TypeMode | Unblocked only after verified item is loaded |
| 21 | Click date picker icon | TypeMode | Rerun Explorer after verified item is available |
| 22 | Select a prior date | TypeMode | Rerun Explorer after verified item is available |
| 23 | VERIFY selected date is earlier than today | TypeMode | Rerun Explorer after date selection is available |
| 24 | Submit/create spoilage entry | TypeMode | Rerun Explorer after verified item and date are available |
| 25 | VERIFY Type Mode entry creation | TypeMode | Rerun Explorer after a valid entry can be created |

## Decisions Made
1. Kept steps 9 and 11-25 as explicit `test.fixme(true, ...)` blocks. Explorer saw “No records found” and did not verify a weighted Type 2 UPC; no value, selector, date, or alternative flow was supplied.
2. The first blocked fixme marks the test skipped at runtime; all later scenario steps remain present, ordered, and individually documented in the generated spec for fidelity and future unblocking.
3. Used existing LoginPage and StoreSelectionPage interaction methods; new app-specific locators were kept in page objects that own the matching enriched page section.
4. Scenario data preserves the given department and stores `weightedType2Upc` and `previousDate` as null rather than fabricating values.
5. The incremental helper returned `INCREMENTAL/EXPLORER_REQUIRED` with `specFile: null` and an unrelated prior baseline. Because this request explicitly specifies FIRST_RUN and no scenario-0001 spec existed, a fresh spec was generated; `incrementalMode` is false.

## Self-Audit Results
- Step count match: YES (25 source steps, 25 test.step() blocks)
- VERIFY representation: YES (4 assertions for verified steps; 7 blocked VERIFY steps explicitly represented by fixme)
- CAPTURE count match: YES (0 / 0)
- SCREENSHOT count match: YES (0 / 0)
- Raw selectors in spec: 0 (target: 0)
- Raw selectors in page objects: 0 (target: 0)
- Blocked/MISSING fixme count: 16

## Observability
| Metric | Value |
|--------|-------|
| Duration | 3m 25s (205000 ms) |
| Pages generated | 6 |
| Methods generated | 4 new methods; existing login/store selection methods reused |
| Locator keys used | 10 of 26 available |
| Token usage | N/A — platform does not expose token counts |

## Eval Metrics
| Metric | Value |
|--------|-------|
| Step count match | YES (25 vs 25) |
| Locator coverage | 38% (10 / 26, including unused entries in reused files) |
| Raw selector leakage | 0 in spec, 0 in page objects (target: 0) |
| Capture-gap rate | 64% (16 / 25 steps represented with test.fixme) |
| Incremental mode hit rate | N/A — FIRST_RUN full generation |