/**
 * Utility functions for Playwright tests
 */

import { type Page, type Locator, expect } from "@playwright/test";

// ===========================================
// LOCATOR SELECTORS
// ===========================================

/**
 * Common locator selectors used across helper functions
 */
const LOCATORS = {
  loaderIcn: 'div[class="spinner"]',
  spinnerIcn: 'div[class="app-loader"]',
  matOptionSel: "mat-option",
  toastPopUp:
    ".ngx-toastr, .toast-success, .toast-error, .toast-warning, .toast-info, #toast-container > div",
  closeBtn: 'button, [data-testid*="close"]',
  angularToastCloseBtn:
    'div[ng-click*="click"][role="button"] i.material-icons',
  extendSessionBtn: 'button:has-text("Extend Session")',
} as const;
/**
 * Cap on the Extend Session click, deliberately well below the 60s `actionTimeout` it would otherwise
 * inherit: this click runs inside a locator handler, which Playwright re-invokes on every actionability
 * retry of the action it blocked, and none of that time counts against the blocked action's own
 * timeout. @see handleSessionExpiryDialog
 */
const EXTEND_SESSION_CLICK_TIMEOUT = 10000;
// ===========================================
// HELPER FUNCTIONS
// ===========================================

/**
 * Decodes a Base64-encoded password
 * @param encodedPassword - The Base64-encoded password
 * @returns The decoded password string
 */
import logger from "./logger";
import {
  RetryExhaustedError,
  NavigationError,
  ConfigurationError,
} from "./errors";
import { profileButtonClick, isProfilingEnabled } from "./button-profiler";

export function decodePassword(encodedPassword: string): string {
  try {
    // Check if the password is actually Base64 encoded
    const binaryString = atob(encodedPassword);
    const bytes = Uint8Array.from(binaryString, (char) => char.charCodeAt(0));
    const decoded = new TextDecoder().decode(bytes);
    // If decoding produces the same string, it might not be Base64 encoded
    if (decoded === encodedPassword) {
      return encodedPassword;
    }
    return decoded;
  } catch (error) {
    logger.warn(
      "Failed to decode password, using as plain text",
      error instanceof Error ? error : undefined,
    );
    return encodedPassword;
  }
}

/**
 * Generates a unique name with timestamp
 * @param prefix - The prefix for the name
 * @returns A unique name in format: {prefix}_Org_{timestamp}
 */
export function generateUniqueName(prefix: string): string {
  const timestamp = Date.now();
  return `${prefix}_${timestamp}`;
}

/**
 * Wait for a specific amount of time
 * @param ms - Milliseconds to wait
 */
export async function waitForSpecificTime(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Click an element
 * @param locator - The locator to click
 * @param profileOptions - Optional profiling configuration
 * @param clickOptions - Optional Playwright click options (e.g. a shorter timeout for elements
 *   that start detaching as soon as the click registers, where the default actionTimeout would
 *   otherwise retry against a stale element for the full duration)
 */
export async function clickElement(
  locator: Locator,
  profileOptions?: {
    page: Page;
    buttonLabel: string;
    testFile: string;
    pageObject: string;
  },
  clickOptions?: Parameters<Locator["click"]>[0],
): Promise<void> {
  // Profile button if enabled
  if (profileOptions && isProfilingEnabled()) {
    await profileButtonClick(
      profileOptions.page,
      locator,
      profileOptions.buttonLabel,
      {
        testFile: profileOptions.testFile,
        pageObject: profileOptions.pageObject,
      },
    );
  }

  await locator.click(clickOptions);
}

/**
 * Click an element with optional label for logging
 * @param locator - The locator to click
 * @param label - Optional label for logging context
 * @param profileOptions - Optional profiling configuration
 */
export async function clickElementWithLabel(
  locator: Locator,
  label?: string,
  profileOptions?: {
    page: Page;
    buttonLabel: string;
    testFile: string;
    pageObject: string;
  },
): Promise<void> {
  if (label) {
    logger.debug(`Clicking: ${label}`);
  }

  // Profile button if enabled
  if (profileOptions && isProfilingEnabled()) {
    await profileButtonClick(
      profileOptions.page,
      locator,
      profileOptions.buttonLabel,
      {
        testFile: profileOptions.testFile,
        pageObject: profileOptions.pageObject,
      },
    );
  }

  await locator.click();
}

/**
 * Fill input with text
 * @param locator - The input locator
 * @param text - Text to fill
 */
export async function fillInput(locator: Locator, text: string): Promise<void> {
  await locator.fill(text);
}

/**
 * Select dropdown option
 * @param locator - The select locator
 * @param value - Value to select
 */
export async function selectDropdown(
  locator: Locator,
  value: string,
): Promise<void> {
  await locator.selectOption(value);
}

/**
 * Wait for element to be visible
 * @param locator - The locator to wait for
 */
export async function waitForElement(locator: Locator): Promise<void> {
  await expect(locator).toBeVisible();
}

/**
 * Press key on element
 * @param locator - The locator to press key on
 * @param key - Key to press
 */
export async function pressKey(locator: Locator, key: string): Promise<void> {
  await locator.press(key);
}

/**
 * Move keyboard focus to an element without activating it.
 *
 * Useful for form validation that only renders once a field has been left: focusing a later control
 * blurs the field being tested, which is what triggers its inline message. A click would submit or
 * toggle the control instead of merely moving focus.
 * @param locator - The locator to focus
 */
export async function focusElement(locator: Locator): Promise<void> {
  await locator.focus();
}

/**
 * Double click an element
 * @param locator - The locator to double click
 */
export async function doubleClickElement(locator: Locator): Promise<void> {
  await locator.dblclick();
}

/**
 * Search and verify results
 * @param searchLocator - The search input locator
 * @param searchText - Text to search for
 * @param resultLocator - The result locator to verify
 */
export async function searchAndVerify(
  searchLocator: Locator,
  searchText: string,
  resultLocator: Locator,
): Promise<void> {
  await clickElement(searchLocator);
  await fillInput(searchLocator, searchText);
  await waitForElement(resultLocator);
}

export type ElementState = 'visible' | 'hidden' | 'enabled' | 'disabled' | 'checked' | 'unchecked';

export async function assertElementState(
  locator: Locator,
  state: ElementState,
  timeout?: number,
): Promise<void> {
  const options = timeout === undefined ? undefined : { timeout };

  switch (state) {
    case 'visible':
      await expect(locator).toBeVisible(options);
      break;
    case 'hidden':
      await expect(locator).toBeHidden(options);
      break;
    case 'enabled':
      await expect(locator).toBeEnabled(options);
      break;
    case 'disabled':
      await expect(locator).toBeDisabled(options);
      break;
    case 'checked':
      await expect(locator).toBeChecked(options);
      break;
    case 'unchecked':
      await expect(locator).not.toBeChecked(options);
      break;
  }
}

/**
 * Assert element is visible
 * @param locator - The locator to check
 * @param timeout - Optional timeout in milliseconds
 */
export async function assertVisible(
  locator: Locator,
  timeout?: number,
): Promise<void> {
  if (timeout) {
    await expect(locator).toBeVisible({ timeout });
  } else {
    await expect(locator).toBeVisible();
  }
}

/**
 * Assert element is enabled
 * @param locator - The locator to check
 * @param timeout - Optional timeout in milliseconds (default: 30000)
 */
export async function assertEnabled(
  locator: Locator,
  timeout: number = 30000,
): Promise<void> {
  await expect(locator).toBeEnabled({ timeout });
}

/**
 * Assert element is visible and enabled
 * @param locator - The locator to check
 * @param timeout - Optional timeout in milliseconds (default: 30000)
 */
export async function assertVisibleAndEnabled(
  locator: Locator,
  timeout: number = 30000,
): Promise<void> {
  await assertVisible(locator, timeout);
  await assertEnabled(locator, timeout);
}

/**
 * Assert element is disabled
 * @param locator - The locator to check
 */
export async function assertDisabled(locator: Locator): Promise<void> {
  await expect(locator).toBeDisabled();
}

/**
 * Assert element has a specific class
 * @param locator - The locator to check
 * @param className - The class name or regex pattern to check for
 * @param timeout - Optional max time to wait for the class to appear
 */
export async function assertHasClass(
  locator: Locator,
  className: string | RegExp,
  timeout?: number,
): Promise<void> {
  await expect(locator).toHaveClass(
    className,
    timeout === undefined ? undefined : { timeout },
  );
}

/**
 * Assert element does not have a specific class
 * @param locator - The locator to check
 * @param className - The class name or regex pattern to check for absence
 * @param timeout - Optional max time to wait for the class to be absent
 */
export async function assertNotHasClass(
  locator: Locator,
  className: string | RegExp,
  timeout?: number,
): Promise<void> {
  await expect(locator).not.toHaveClass(
    className,
    timeout === undefined ? undefined : { timeout },
  );
}

/**
 * Assert element is hidden (not visible)
 * @param locator - The locator to check
 * @param timeout - Optional timeout in milliseconds
 */
export async function assertHidden(
  locator: Locator,
  timeout?: number,
): Promise<void> {
  if (timeout) {
    await expect(locator).toBeHidden({ timeout });
  } else {
    await expect(locator).toBeHidden();
  }
}

/**
 * Assert page title matches expected pattern
 * @param page - The page instance
 * @param expectedTitle - Expected title as string or regex pattern
 * @param timeout - Optional timeout in milliseconds
 */
export async function assertPageTitle(
  page: Page,
  expectedTitle: string | RegExp,
  timeout?: number,
): Promise<void> {
  if (timeout) {
    await expect(page).toHaveTitle(expectedTitle, { timeout });
  } else {
    await expect(page).toHaveTitle(expectedTitle);
  }
}

/**
 * Assert that two strings are equal
 * @param actual - The actual string value
 * @param expected - The expected string value
 */
export function assertStringEquals(
  actual: string | null,
  expected: string,
): void {
  expect(actual).toBe(expected);
}

/**
 * Fill element text after clearing
 * @param locator - The locator to fill
 * @param value - Value to fill
 */
export async function fillElementText(
  locator: Locator,
  value: string,
): Promise<void> {
  await assertVisible(locator);
  await assertEnabled(locator);
  await clickElement(locator);
  await locator.clear();
  await locator.fill(value);
}

/**
 * Click element with optional text verification
 * @param locator - The locator to click
 * @param expectedText - Optional text to verify
 */
export async function clickElementWithText(
  locator: Locator,
  expectedText?: string,
): Promise<void> {
  await assertVisible(locator);
  await assertEnabled(locator);
  if (expectedText) {
    await expect(locator).toContainText(expectedText);
  }
  await clickElement(locator);
}

/**
 * Clicks an element (button/link) with optional text verification and index
 * @param elementControl - The locator of the element to click
 * @param toHaveText - Optional text to verify the element contains
 * @param elementIndex - Optional index if working with multiple matching elements
 * @param clickOptions - Optional click options (e.g., { force: true })
 */
export async function clickElementHasBtnLnkLocator(
  elementControl: Locator,
  toHaveText?: string,
  elementIndex?: number,
  clickOptions?: Parameters<Locator["click"]>[0],
): Promise<void> {
  let element = elementControl;
  if (elementIndex !== undefined && elementIndex >= 0) {
    element = elementControl.nth(elementIndex);
  }
  await assertVisibleAndEnabled(element);
  if (toHaveText && toHaveText.trim() !== "") {
    await expect(element).toContainText(toHaveText);
  }
  await element.click(clickOptions);
}

/**
 * Fills an input element with a value and verifies the input
 * @param elementControl - The locator of the input element
 * @param inputValue - The value to fill
 * @param elementIndex - Optional index if working with multiple matching elements
 */
export async function fillElementTxtLocator(
  elementControl: Locator,
  inputValue: string,
  elementIndex?: number,
): Promise<void> {
  let element = elementControl;
  if (elementIndex !== undefined && elementIndex >= 0) {
    element = elementControl.nth(elementIndex);
  }
  await assertVisibleAndEnabled(element);
  await element.click({ force: true });
  await element.clear({ force: true });
  await element.fill("");
  await element.fill(inputValue);
  await expect(element).toHaveValue(inputValue);
}

/**
 * Fills a contenteditable rich-text body (e.g. a TinyMCE "Rich Text Area" iframe body) and verifies
 * the text landed. A contenteditable element has no `value`, so fillElementTxtLocator's toHaveValue
 * check can never pass against one - this asserts on its text content instead.
 * @param elementControl - The locator of the contenteditable body element
 * @param inputValue - The text to type into the editor
 */
export async function fillRichTextLocator(
  elementControl: Locator,
  inputValue: string,
): Promise<void> {
  await assertVisible(elementControl);
  await elementControl.click();
  await elementControl.fill(inputValue);
  await expect(elementControl).toHaveText(inputValue);
}

/**
 * Click a Material Design tab by its text label
 * Handles Material tabs with dynamic IDs (e.g., #mat-tab-label-1-2)
 * @param page - The page object
 * @param tabText - The text of the tab to click
 * @example
 * await clickTabByText(page, 'Global Settings');
 * await clickTabByText(page, 'SLA');
 */
export async function clickTabByText(
  page: Page,
  tabText: string,
): Promise<void> {
  // Material Design tabs have dynamic IDs like #mat-tab-label-0-2, #mat-tab-label-1-2, etc.
  // Use attribute starts-with selector to match any mat-tab-label ID
  const tab = page
    .locator('[id^="mat-tab-label"]')
    .getByText(tabText, { exact: true });
  await assertVisibleAndEnabled(tab);
  await clickElement(tab);
  logger.info(`Clicked tab: ${tabText}`);
}

/**
 * Escapes special characters in a string to use in a regular expression
 * @param s - String to escape
 * @returns Escaped string safe for regex
 */
export function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// Re-export extractPattern for backward compatibility
// The implementation has been moved to src/utils/string-utils.ts
export { extractPattern } from "./string-utils";

// ===========================================
// LOCATOR FACTORY FUNCTIONS
// ===========================================

/**
 * Creates a link locator by name using role selector
 * @param page - The Playwright page instance
 * @param name - The accessible name of the link
 * @returns Locator for the link element
 */
export function getLinkByName(page: Page, name: string): Locator {
  return page.getByRole("link", { name });
}

/**
 * Creates a button locator by name using role selector
 * @param page - The Playwright page instance
 * @param name - The accessible name of the button
 * @returns Locator for the button element
 */
export function getButtonByName(page: Page, name: string): Locator {
  return page.getByRole("button", { name, exact: true });
}

/**
 * Creates a checkbox locator by name using role selector
 * @param page - The Playwright page instance
 * @param name - The accessible name of the checkbox
 * @returns Locator for the checkbox element
 */
export function getCheckboxByName(page: Page, name: string): Locator {
  return page.getByRole("checkbox", { name });
}

/**
 * Creates a checkbox locator by exact name using role selector
 *
 * Use when one checkbox's label is a prefix of another's (e.g. 'Supplier' vs 'Supplier Root').
 * @param page - The Playwright page instance
 * @param name - The exact accessible name of the checkbox
 * @returns Locator for the checkbox element with exact name match
 */
export function getCheckboxByExactName(page: Page, name: string): Locator {
  return page.getByRole("checkbox", { name, exact: true });
}

/**
 * Creates a radio button locator by name using role selector
 * @param page - The Playwright page instance
 * @param name - The accessible name of the radio button
 * @returns Locator for the radio button element
 */
export function getRadioByName(page: Page, name: string): Locator {
  return page.getByRole("radio", { name });
}

/**
 * Creates a locator for the native control inside an Angular Material radio host.
 *
 * A `<mat-radio-button>` host carries its selection only as a `mat-mdc-radio-checked` class — no
 * role, no `aria-checked` — so `check()` and `toBeChecked()` both reject it with 'Not a checkbox or
 * radio button'. The state lives on the native input nested inside, so this is what gets asserted
 * while {@link getRadioClickTarget} is what gets clicked. Exactly one native input exists per host.
 * @param radioHost - Locator for the `mat-radio-button` host, however it was addressed
 * @returns Locator for that host's native radio input
 */
export function getNativeRadioInput(radioHost: Locator): Locator {
  return radioHost.locator('input[type="radio"]');
}

/**
 * Creates a locator for the clickable label inside an Angular Material radio host.
 *
 * The host must NOT be clicked directly. It lays out as a block and stretches to its container's
 * width, while the only interactive surfaces inside — the radio circle and its `<label for>` — stay
 * at the left edge. Playwright clicks an element's centre, so on a wide host the click lands on dead
 * space: it succeeds, and it selects nothing. The label is only ever as wide as its own text, so its
 * centre is always on target. Nothing detects the silent miss on a radio that is already the
 * default, which is why it surfaced only on the first radio a test had to genuinely change. See §15
 * of `create-test-reports/2026-09-21-MEXV-16918-resolver-fix-parked-checks-and-template-guards.md`.
 * @param radioHost - Locator for the `mat-radio-button` host, however it was addressed
 * @returns Locator for that host's label
 */
export function getRadioClickTarget(radioHost: Locator): Locator {
  return radioHost.locator("label");
}

/**
 * Creates a textbox locator by name using role selector
 * @param page - The Playwright page instance
 * @param name - The accessible name of the textbox
 * @returns Locator for the textbox element
 */
export function getTextboxByName(page: Page, name: string): Locator {
  return page.getByRole("textbox", { name });
}

/**
 * Creates a textbox locator by exact name using role selector
 * Use this when there are multiple textboxes with similar names (e.g., "Address", "Address 2", "Address 3")
 * @param page - The Playwright page instance
 * @param name - The exact accessible name of the textbox
 * @returns Locator for the textbox element with exact name match
 */
export function getTextboxByExactName(page: Page, name: string): Locator {
  return page.getByRole("textbox", { name, exact: true });
}

/**
 * Creates a searchbox locator by name using role selector
 * @param page - The Playwright page instance
 * @param name - The accessible name of the searchbox
 * @returns Locator for the searchbox element
 */
export function getSearchboxByName(page: Page, name: string): Locator {
  return page.getByRole("searchbox", { name });
}

/**
 * Creates a combobox locator by name using role selector
 * For select dropdowns, autocomplete inputs, or elements with role="combobox"
 * @param page - The Playwright page instance
 * @param name - The accessible name of the combobox
 * @returns Locator for the combobox element
 * @example
 * // Standard combobox
 * const statusSel = getComboboxByName(page, 'Status');
 */
export function getComboboxByName(page: Page, name: string): Locator {
  return page.getByRole("combobox", { name });
}

/**
 * Creates a combobox locator by exact name using role selector
 * Use when you need exact name matching to avoid collisions (e.g., 'Type' vs 'Sub Type')
 * @param page - The Playwright page instance
 * @param name - The exact accessible name of the combobox
 * @returns Locator for the combobox element
 * @example
 * // Exact match to avoid collision with "Sub Type"
 * const typeSel = getComboboxByExactName(page, 'Type');
 */
export function getComboboxByExactName(page: Page, name: string): Locator {
  return page.getByRole("combobox", { name, exact: true });
}

/**
 * Creates a combobox locator within a container locator
 * Useful for complex scenarios where combobox is nested in a specific container
 * @param containerLocator - Parent locator to search within
 * @returns Locator for the combobox element within the container
 * @example
 * // Combobox within a specific div
 * const container = page.locator('div[ng-switch="someCondition"]');
 * const comboboxSel = getComboboxInContainer(container);
 */
export function getComboboxInContainer(containerLocator: Locator): Locator {
  return containerLocator.getByRole("combobox");
}

/**
 * Creates a tab locator by name using role selector
 * @param page - The Playwright page instance
 * @param name - The accessible name of the tab
 * @returns Locator for the tab element
 */
export function getTabByName(page: Page, name: string): Locator {
  return page.getByRole("tab", { name });
}

/**
 * Creates a button locator matching any of the provided names (case-insensitive substring).
 *
 * OR-combines per-name locators via `Locator.or()`. `getByRole('button', { name })` already
 * matches case-insensitive substrings when `name` is a string, so this preserves the previous
 * `RegExp('a|b|c', 'i')` semantics without constructing a dynamic regex (avoids ReDoS surface —
 * Wiz WS-I011-JAVASCRIPT-00003).
 *
 * @param page - The Playwright page instance
 * @param names - Array of button names to match (e.g., ['Cancel', 'Close'])
 * @returns Locator for the button element
 * @throws Error if `names` is empty
 */
export function getButtonByNames(page: Page, names: string[]): Locator {
  if (names.length === 0) {
    throw new Error(
      "getButtonByNames: `names` array must contain at least one name",
    );
  }
  const [first, ...rest] = names;
  return rest.reduce(
    (combined, name) => combined.or(page.getByRole("button", { name })),
    page.getByRole("button", { name: first }),
  );
}

/**
 * Like `getButtonByNames` but anchored — matches only when the accessible name equals one of
 * the supplied strings exactly. Use when a substring match would risk hitting a different button.
 *
 * OR-combines per-name locators via `Locator.or()`, each using `exact: true`, instead of an
 * anchored `RegExp('^(?:a|b|c)$', 'i')` construction (Wiz WS-I011-JAVASCRIPT-00003).
 *
 * @throws Error if `names` is empty
 */
export function getButtonByExactNames(page: Page, names: string[]): Locator {
  if (names.length === 0) {
    throw new Error(
      "getButtonByExactNames: `names` array must contain at least one name",
    );
  }
  const [first, ...rest] = names;
  return rest.reduce(
    (combined, name) =>
      combined.or(page.getByRole("button", { name, exact: true })),
    page.getByRole("button", { name: first, exact: true }),
  );
}

/**
 * Creates a link locator matching any of the provided names (case-insensitive substring).
 *
 * OR-combines per-name locators via `Locator.or()`; see `getButtonByNames` for the same
 * rationale (avoids a dynamic-regex ReDoS surface — Wiz WS-I011-JAVASCRIPT-00003).
 *
 * @param page - The Playwright page instance
 * @param names - Array of link names to match
 * @returns Locator for the link element
 * @throws Error if `names` is empty
 */
export function getLinkByNames(page: Page, names: string[]): Locator {
  if (names.length === 0) {
    throw new Error(
      "getLinkByNames: `names` array must contain at least one name",
    );
  }
  const [first, ...rest] = names;
  return rest.reduce(
    (combined, name) => combined.or(page.getByRole("link", { name })),
    page.getByRole("link", { name: first }),
  );
}

/**
 * Creates a locator based on type and pattern/names.
 *
 * Supports ARIA roles ('button', 'link', 'menuitem', etc.), as well as
 * 'text', 'label', and 'cell' (for ui-grid cell contents).
 *
 * @param scope - The Playwright Page or Locator to search within
 * @param type - The type: ARIA role ('button', 'link', 'menuitem', etc.), 'text', 'label', or 'cell'
 * @param pattern - Array of names (for roles) or RegExp/string pattern (for text/label/cell)
 * @returns Locator for the element
 *
 * @example
 * // Role-based with multiple names (page scope)
 * getElementByNames(page, 'button', ['Save', 'Submit']);
 *
 * // Menuitem role (for dropdown menu items)
 * getElementByNames(page, 'menuitem', 'Export to PDF');
 *
 * // Text-based with regex (page scope)
 * getElementByNames(page, 'text', /Total Records:\s*\d+/);
 *
 * // Label-based with regex (page scope)
 * getElementByNames(page, 'label', /Notification Name/);
 *
 * // Cell-based within a row (locator scope) — targets ui-grid cell contents
 * getElementByNames(row, 'cell', /^Email$/);
 */
export function getElementByNames(
  scope: Page | Locator,
  type:
    | "button"
    | "link"
    | "checkbox"
    | "radio"
    | "textbox"
    | "tab"
    | "menuitem"
    | "text"
    | "label"
    | "cell",
  pattern: string[] | RegExp | string,
): Locator {
  if (type === "text") {
    return scope.getByText(pattern as RegExp | string);
  }
  if (type === "label") {
    return scope.getByLabel(pattern as RegExp | string);
  }
  if (type === "cell") {
    // Exact-string match uses :text-is() so 'Email' does not also match 'Email Address'
    if (typeof pattern === "string") {
      return scope.locator(`.ui-grid-cell-contents:text-is("${pattern}")`);
    }
    return scope.locator(".ui-grid-cell-contents", {
      hasText: pattern as RegExp,
    });
  }
  // Role-based locator
  if (Array.isArray(pattern)) {
    if (pattern.length === 0) {
      throw new Error(
        "getElementByNames: `pattern` array must contain at least one name",
      );
    }
    /*
     * OR-combine per-name locators via Playwright's Locator.or() instead of
     * building a dynamic RegExp from caller-supplied strings. Playwright's
     * `getByRole({ name })` already matches case-insensitive substrings when
     * `name` is a string, so this preserves the previous
     * `RegExp('a|b|c', 'i')` semantics with zero dynamic-regex surface.
     * Addresses Wiz WS-I011-JAVASCRIPT-00003 (non-literal regex / ReDoS).
     */
    const [first, ...rest] = pattern;
    return rest.reduce(
      (combined, name) => combined.or(scope.getByRole(type, { name })),
      scope.getByRole(type, { name: first }),
    );
  }
  return scope.getByRole(type, { name: pattern as RegExp | string });
}

/**
 * Creates a locator for elements by their label text.
 *
 * OR-combines per-label locators via `Locator.or()` — Playwright's
 * `getByLabel(name)` already matches case-insensitive substrings when `name`
 * is a string, preserving the OR-of-labels semantics without building a
 * dynamic regex from caller-supplied strings (avoids ReDoS surface — Wiz
 * WS-I011-JAVASCRIPT-00003).
 *
 * @param scope - The Playwright Page or Locator to search within
 * @param labels - Array of label strings to match (OR logic, case-insensitive)
 * @returns Locator for the element
 * @throws Error if `labels` is empty
 *
 * @example
 * getElementByLabels(page, ['Notification Name']);
 * getElementByLabels(page, ['Save', 'Submit']); // matches either label
 */
export function getElementByLabels(
  scope: Page | Locator,
  labels: string[],
): Locator {
  if (labels.length === 0) {
    throw new Error(
      "getElementByLabels: `labels` array must contain at least one label",
    );
  }
  const [first, ...rest] = labels;
  return rest.reduce(
    (combined, label) => combined.or(scope.getByLabel(label)),
    scope.getByLabel(first),
  );
}

/**
 * Creates an option locator by exact accessible name
 * @param page - The Playwright page instance
 * @param name - The option text/name
 * @returns Locator for the option element
 */
export function getOptionByName(page: Page, name: string): Locator {
  return page.getByRole("option", { name, exact: true });
}

/**
 * Creates a locator by exact visible text
 * @param page - The Playwright page instance
 * @param text - Exact text content to match
 * @returns Locator matching exact text
 */
export function getByExactText(page: Page, text: string): Locator {
  return page.getByText(text, { exact: true });
}

/**
 * Creates a list item locator filtered by text
 * @param page - The Playwright page instance
 * @param text - Text to filter list items
 * @returns Locator for matching list item
 */
export function getListItemByText(page: Page, text: string): Locator {
  return page.getByRole("listitem").filter({ hasText: text });
}

/**
 * Creates a span locator filtered by text
 * @param page - The Playwright page instance
 * @param text - Text to filter span elements
 * @returns Locator for matching span element
 */
export function getSpanByText(page: Page, text: string): Locator {
  return page.locator("span").filter({ hasText: text });
}

// ===========================================
// UNIFIED SELECT/OPTION FUNCTIONS
// ===========================================

/**
 * Strategy type for select option detection
 * - 'auto': Auto-detect based on DOM structure (default)
 * - 'native': HTML native <select> element
 * - 'aria': ARIA role-based listbox/option
 * - 'material': Angular Material mat-select/mat-option
 * - 'select2': Select2 jQuery plugin dropdowns
 */
export type SelectStrategy =
  | "auto"
  | "native"
  | "aria"
  | "material"
  | "select2";

/**
 * Detects the type of select/dropdown element
 * @param page - The page object
 * @param triggerLocator - The trigger element locator
 * @returns The detected strategy type
 */
/**
 * Wait for a native select dropdown to have options populated and determine the correct value format
 * Handles cascading/dynamic dropdowns that load options after previous selections
 * @param triggerLocator - The select element
 * @param optionText - The option we're looking for (by label or value)
 * @param timeout - Maximum time to wait in milliseconds
 * @returns object with { found: boolean, matchedValue?: string } where matchedValue is the actual option value to use
 */
async function waitForNativeSelectOption(
  triggerLocator: Locator,
  optionText: string,
  timeout: number = 5000,
): Promise<{ found: boolean; matchedValue?: string }> {
  const startTime = Date.now();

  while (Date.now() - startTime < timeout) {
    const result = await triggerLocator.evaluate(
      (select: HTMLSelectElement, text: string) => {
        // Check if select has any options (not just the placeholder)
        if (select.options.length <= 1) {
          return { found: false };
        }

        // Find the option by label and return its actual value
        for (let i = 0; i < select.options.length; i++) {
          const option = select.options[i];
          // Match by label text (most reliable)
          if (option.text === text) {
            return { found: true, matchedValue: option.value };
          }
        }

        // If not found by label, try matching by value directly
        for (let i = 0; i < select.options.length; i++) {
          const option = select.options[i];
          if (
            option.value === text ||
            option.value === `string:${text}` ||
            option.value === `number:${text}` ||
            option.value === `boolean:${text}`
          ) {
            return { found: true, matchedValue: option.value };
          }
        }

        return { found: false };
      },
      optionText,
    );

    if (result.found) {
      return result;
    }

    // Wait 100ms before checking again
    await new Promise((resolve) => setTimeout(resolve, 100));
  }

  logger.debug(
    `Timeout waiting for option '${optionText}' to appear in select dropdown`,
  );
  return { found: false };
}

async function detectSelectStrategy(
  page: Page,
  triggerLocator: Locator,
): Promise<SelectStrategy> {
  const tagName = await triggerLocator.evaluate((el) =>
    el.tagName.toLowerCase(),
  );

  // Native HTML select (but check if it's Select2-enhanced first)
  if (tagName === "select") {
    // Check if this select is enhanced by Select2
    const isSelect2 = await triggerLocator.evaluate((el) => {
      return (
        el.classList.contains("select2-hidden-accessible") ||
        el.classList.contains("select2-offscreen")
      );
    });

    if (isSelect2) {
      return "select2";
    }

    return "native";
  }

  // Select2 detection - check for Select2 classes or data attributes
  const isSelect2 = await triggerLocator.evaluate((el) => {
    // Check for Select2 container classes
    if (
      el.classList.contains("select2-container") ||
      el.closest(".select2-container")
    ) {
      return true;
    }

    // Check for Select2 link/trigger (common pattern: id starts with 's2id_')
    if (el.id && el.id.startsWith("s2id_")) {
      return true;
    }

    // Check for Select2 search input
    if (
      el.classList.contains("select2-input") ||
      el.classList.contains("select2-search__field")
    ) {
      return true;
    }

    // Check for Select2 choice container
    if (
      el.classList.contains("select2-choice") ||
      el.classList.contains("select2-choices")
    ) {
      return true;
    }

    return false;
  });

  if (isSelect2) {
    return "select2";
  }

  // Angular Material mat-select
  if (
    tagName === "mat-select" ||
    (await triggerLocator.evaluate((el) => el.closest("mat-select") !== null))
  ) {
    return "material";
  }

  // Check for ARIA listbox pattern
  const hasAriaHaspopup = await triggerLocator.getAttribute("aria-haspopup");
  if (hasAriaHaspopup === "listbox") {
    return "aria";
  }

  // If we get here and nothing matched, log a warning
  logger.warn(
    `⚠️  Unknown dropdown type detected. Element tag: ${tagName}. ` +
      `Defaulting to 'material' strategy. Consider adding support for this dropdown type.`,
  );

  // Default to material for Angular apps (most common case)
  return "material";
}

/**
 * Unified select option function with auto-detection
 * Supports native HTML select, ARIA listbox, Angular Material mat-select, and Select2
 * @param page - The page object
 * @param triggerLocator - The trigger element locator (dropdown/select)
 * @param optionText - Text of the option to select
 * @param strategy - Strategy to use ('auto' | 'native' | 'aria' | 'material' | 'select2'), defaults to 'auto'
 * @param searchable - Whether the dropdown has a search/filter input (primarily for Select2), defaults to false
 */
export async function selectOption(
  page: Page,
  triggerLocator: Locator,
  optionText: string,
  strategy: SelectStrategy = "auto",
  searchable: boolean = false,
): Promise<void> {
  const resolvedStrategy =
    strategy === "auto"
      ? await detectSelectStrategy(page, triggerLocator)
      : strategy;
  logger.debug(
    `Using select strategy: ${resolvedStrategy} for option: ${optionText}${searchable ? " (searchable)" : ""}`,
  );

  switch (resolvedStrategy) {
    case "native": {
      // Wait for the option to be available and detect its actual value format
      logger.debug(
        `Waiting for option '${optionText}' to be available in native select...`,
      );
      const optionResult = await waitForNativeSelectOption(
        triggerLocator,
        optionText,
      );

      if (!optionResult.found) {
        logger.warn(
          `Option '${optionText}' not found after waiting. Attempting selection by label as fallback.`,
        );
        await triggerLocator.selectOption(
          { label: optionText },
          { timeout: 2000 },
        );
        break;
      }

      // We found the option and know its actual value - select it directly
      try {
        await triggerLocator.selectOption(
          { value: optionResult.matchedValue },
          { timeout: 1000 },
        );
        logger.debug(
          `Selected native option by value: ${optionResult.matchedValue}`,
        );
      } catch {
        // If value selection fails, fall back to label (shouldn't happen, but safety net)
        logger.debug(
          `Value selection failed, falling back to label: ${optionText}`,
        );
        await triggerLocator.selectOption(
          { label: optionText },
          { timeout: 1000 },
        );
      }
      break;
    }

    case "aria":
      await clickElement(triggerLocator);
      await page.getByRole("option", { name: optionText, exact: true }).click();
      break;

    case "select2": {
      // Click the trigger to open the dropdown
      await clickElement(triggerLocator);

      if (searchable) {
        // Select2 with search - type to filter options
        const searchInputSelectors = [
          ".select2-search input",
          ".select2-input",
          ".select2-search__field",
          "input.select2-search__field",
        ];

        let searchInput: Locator | null = null;
        for (const selector of searchInputSelectors) {
          const input = page.locator(selector);
          const isVisible = await input
            .isVisible({ timeout: 1000 })
            .catch(() => false);
          if (isVisible) {
            searchInput = input;
            break;
          }
        }

        if (searchInput) {
          await searchInput.fill(optionText);
          await page.waitForTimeout(500); // Wait for search results to filter
          logger.debug("Filled Select2 search input");
        } else {
          logger.warn(
            "Select2 marked as searchable but search input not found, proceeding without search",
          );
        }
      }

      // Click the matching option - try multiple selectors
      const optionLocators = [
        page
          .locator(".select2-results .select2-result-label")
          .filter({ hasText: optionText }),
        page.locator(".select2-result").filter({ hasText: optionText }),
        page
          .locator(".select2-results__option")
          .filter({ hasText: optionText }),
        page.locator('[role="option"]').filter({ hasText: optionText }),
        page.getByText(optionText, { exact: true }),
      ];

      for (const locator of optionLocators) {
        const count = await locator.count();
        if (count > 0) {
          const isVisible = await locator
            .first()
            .isVisible({ timeout: 1000 })
            .catch(() => false);
          if (isVisible) {
            await locator.first().click();
            logger.debug(`Selected Select2 option: ${optionText}`);
            return;
          }
        }
      }

      throw new Error(`Could not find Select2 option with text: ${optionText}`);
    }

    case "material":
    default:
      await clickElement(triggerLocator);
      /*
       * Playwright's `getByText(text, { exact: true })` matches exact text with whitespace
       * normalisation, so the leading/trailing whitespace Angular templates commonly render
       * inside mat-option (e.g. "<mat-option> {{ label }} </mat-option>") is handled without
       * a dynamic regex (avoids ReDoS surface — Wiz WS-I011-JAVASCRIPT-00003).
       */
      await page
        .locator(LOCATORS.matOptionSel)
        .filter({ has: page.getByText(optionText, { exact: true }) })
        .click();
      break;
  }
}

/**
 * Unified select option by text when dropdown is already open
 * Supports ARIA option, Angular Material mat-option, and Select2
 * @param page - The page object
 * @param optionText - Text of the option to select
 * @param strategy - Strategy to use ('auto' | 'aria' | 'material' | 'select2'), defaults to 'auto'
 */
export async function selectOptionByText(
  page: Page,
  optionText: string,
  strategy: Exclude<SelectStrategy, "native"> = "auto",
): Promise<void> {
  // Try material first (most common), then Select2, then ARIA
  if (strategy === "auto" || strategy === "material") {
    const matOption = page
      .locator(LOCATORS.matOptionSel)
      .filter({ hasText: optionText });
    const isMaterialVisible = await matOption
      .first()
      .isVisible({ timeout: 1000 })
      .catch(() => false);

    if (isMaterialVisible) {
      await assertVisibleAndEnabled(matOption.first());
      await clickElement(matOption.first());
      return;
    }
  }

  if (strategy === "auto" || strategy === "select2") {
    // Try Select2 option selectors
    const select2Locators = [
      page
        .locator(".select2-results .select2-result-label")
        .filter({ hasText: optionText }),
      page.locator(".select2-result").filter({ hasText: optionText }),
      page.locator(".select2-results__option").filter({ hasText: optionText }),
    ];

    for (const locator of select2Locators) {
      const count = await locator.count();
      if (count > 0) {
        const isVisible = await locator
          .first()
          .isVisible({ timeout: 1000 })
          .catch(() => false);
        if (isVisible) {
          await assertVisibleAndEnabled(locator.first());
          await clickElement(locator.first());
          logger.debug(`Selected Select2 option: ${optionText}`);
          return;
        }
      }
    }

    // If strategy is explicitly 'select2' and we didn't find it, throw error
    if (strategy === "select2") {
      throw new Error(`Could not find Select2 option with text: ${optionText}`);
    }
  }

  if (strategy === "auto" || strategy === "aria") {
    const ariaOption = page.getByRole("option", { name: optionText });
    await assertVisibleAndEnabled(ariaOption);
    await clickElement(ariaOption);
  }
}

/**
 * Select multiple options from a multi-select dropdown
 * @param page - The page object
 * @param triggerLocator - The trigger element locator
 * @param optionTexts - Array of option texts to select
 * @param strategy - Strategy to use ('auto' | 'native' | 'aria' | 'material' | 'select2'), defaults to 'auto'
 */
export async function selectOptions(
  page: Page,
  triggerLocator: Locator,
  optionTexts: string[],
  strategy: SelectStrategy = "auto",
): Promise<void> {
  const resolvedStrategy =
    strategy === "auto"
      ? await detectSelectStrategy(page, triggerLocator)
      : strategy;
  logger.debug(
    `Using multi-select strategy: ${resolvedStrategy} for options: ${optionTexts.join(", ")}`,
  );

  switch (resolvedStrategy) {
    case "native":
      await triggerLocator.selectOption(
        optionTexts.map((label) => ({ label })),
      );
      break;

    case "aria":
      await clickElement(triggerLocator);
      for (const optionText of optionTexts) {
        await page
          .getByRole("option", { name: optionText, exact: true })
          .click();
      }
      // Press Escape to close if needed
      await page.keyboard.press("Escape");
      break;

    case "select2":
      await clickElement(triggerLocator);
      for (const optionText of optionTexts) {
        // Try to find and click each option
        const optionLocators = [
          page
            .locator(".select2-results .select2-result-label")
            .filter({ hasText: optionText }),
          page.locator(".select2-result").filter({ hasText: optionText }),
          page
            .locator(".select2-results__option")
            .filter({ hasText: optionText }),
        ];

        let optionFound = false;
        for (const locator of optionLocators) {
          const count = await locator.count();
          if (count > 0) {
            const isVisible = await locator
              .first()
              .isVisible({ timeout: 1000 })
              .catch(() => false);
            if (isVisible) {
              await locator.first().click();
              optionFound = true;
              logger.debug(`Selected Select2 multi-option: ${optionText}`);
              break;
            }
          }
        }

        if (!optionFound) {
          throw new Error(
            `Could not find Select2 option with text: ${optionText}`,
          );
        }
      }
      // Press Escape to close the dropdown
      await page.keyboard.press("Escape");
      break;

    case "material":
    default:
      await clickElement(triggerLocator);
      for (const optionText of optionTexts) {
        /*
         * Playwright's `getByText(text, { exact: true })` normalises whitespace and matches
         * exactly, replacing the previous anchored-regex construction so the input option
         * text is never fed into `new RegExp(...)` (Wiz WS-I011-JAVASCRIPT-00003).
         */
        await page
          .locator(LOCATORS.matOptionSel)
          .filter({ has: page.getByText(optionText, { exact: true }) })
          .click();
      }
      // Click outside or press Escape to close the dropdown
      await page.keyboard.press("Escape");
      break;
  }
}

// ===========================================
// BACKWARD-COMPATIBLE WRAPPERS (DEPRECATED)
// ===========================================

/**
 * @deprecated Use selectOption() instead. This wrapper will be removed in a future version.
 * Select Material Design option
 * @param page - The page object
 * @param triggerLocator - The trigger element locator
 * @param optionText - Text of the option to select
 */
export async function selectMatOption(
  page: Page,
  triggerLocator: Locator,
  optionText: string,
): Promise<void> {
  await selectOption(page, triggerLocator, optionText, "material");
}

/**
 * Use selectOptionByText() instead. This wrapper will be removed in a future version.
 * Select Material Design option by text (assumes dropdown is already open)
 * @param page - The page object
 * @param optionText - Text of the option to select
 */
export async function selectMatOptionByText(
  page: Page,
  optionText: string,
): Promise<void> {
  await selectOptionByText(page, optionText, "material");
}

/**
 * Wait for element to become invisible/hidden
 * @param locator - The locator to wait for
 * @param timeout - Timeout in milliseconds (default: 10000)
 */
export async function waitForInvisible(
  locator: Locator,
  timeout: number = 10000,
): Promise<void> {
  await expect(locator).toBeHidden({ timeout });
}
/**
 * Auto-dismiss the app's session expiry dialog for the lifetime of a page.
 *
 * Long-running tests outlive the app's idle session window. When the warning dialog appears it
 * overlays the page and intercepts every click, so it cannot be handled at a single known step -
 * it can surface at any await. This registers a Playwright locator handler, which the framework
 * runs automatically whenever the dialog becomes visible and blocks an action, then resumes the
 * interrupted action once the dialog is gone.
 *
 * This covers actions only. Playwright runs locator handlers as part of an action's actionability
 * check, so a code path that navigates and then asserts - without clicking anything - never gives the
 * handler a chance to fire. Pair it with dismissSessionExpiryDialogIfPresent() at those points; see
 * that function for the run this cost.
 * @param page - The page to register the handler on
 */
export async function handleSessionExpiryDialog(page: Page): Promise<void> {
  const extendSessionBtn = page.locator(LOCATORS.extendSessionBtn);
  await page.addLocatorHandler(
    extendSessionBtn,
    async () => {
      logger.info("Session expiry dialog appeared - clicking Extend Session");
      // Bounded well below actionTimeout, and failure is swallowed rather than thrown, because the
      // cost of a click that cannot land here is paid many times over and is charged to nobody.
      // Playwright re-invokes a locator handler before each actionability retry of the action it
      // blocked, and time spent inside the handler is not deducted from that action's own timeout -
      // so N invocations of a failing click cost N x its timeout on top of the caller's budget, with
      // no ceiling. On 2026-09-08 the dialog was animating while being clicked ("element is not
      // stable", then "element was detached from the DOM, retrying"); each invocation burned the full
      // 60s actionTimeout, and a 60s grid waitFor sat behind roughly two dozen of them for 24 minutes
      // until the beforeAll hook spent its whole 30 minute budget and the run died in setup, before a
      // single step had run. 10s keeps a transient dialog (the observed case - it takes the click on a
      // later invocation) cheap, and if the dialog is genuinely stuck, returning lets the real action
      // carry on and fail on its own terms instead of stalling behind an unattributable retry loop.
      await extendSessionBtn
        .click({ timeout: EXTEND_SESSION_CLICK_TIMEOUT })
        .catch(() => {});
    },
    { noWaitAfter: true },
  );
  logger.info("Registered session expiry dialog handler");
}

/**
 * Dismiss the session expiry dialog right now, if it happens to be on screen.
 *
 * handleSessionExpiryDialog() is the general mechanism and should stay registered; this is for the
 * gap it cannot cover. A locator handler only runs during an action's actionability check, so a
 * navigate-then-assert path fires no action and the dialog stays up - and a dialog left up is not
 * merely a blocked click: on 2026-09-08 a two-session spec left its provider page idle for three
 * minutes, the warning appeared, and the next thing that page did was visit() + assert the Orders
 * header. Nothing dismissed the dialog, nothing surfaced a failure either, and the run sat silent for
 * 25 minutes until the test timeout - then hung again in teardown.
 *
 * Deliberately bounded and silent when absent: the common case is no dialog, and this runs on paths
 * that are already slow, so it must cost a bounded probe rather than an assertion budget.
 * @param page - The page to check
 * @param timeoutMs - How long to look for the dialog before assuming it is not there
 */
export async function dismissSessionExpiryDialogIfPresent(
  page: Page,
  timeoutMs: number = 2000,
): Promise<void> {
  const extendSessionBtn = page.locator(LOCATORS.extendSessionBtn);
  if (await waitForElementVisible(extendSessionBtn, timeoutMs)) {
    await extendSessionBtn
      .click({ timeout: EXTEND_SESSION_CLICK_TIMEOUT })
      .catch(() => {});
    await extendSessionBtn
      .waitFor({ state: "hidden", timeout: 10000 })
      .catch(() => {});
    logger.info("Session expiry dialog was open - clicked Extend Session");
  }
}

/**
 * Verify and close toast notification
 *
 * Toasts stack. A toast raised by a previous action is often still on screen when the next one
 * arrives - stopping a PO line and then releasing the PO leaves "Line stopped" and "Releasing
 * selected purchase order(s)" up together - and the container selector also matches the same toast
 * through more than one of its alternatives. An unfiltered locator therefore resolves to several
 * elements and every assertion on it fails on strict mode rather than on anything being wrong with
 * the app. Narrowing to the toast carrying the expected message checks the message the caller asked
 * about and ignores whatever else happens to be on screen.
 * @param page - The page object
 * @param expectedMessage - Expected toast message
 * @param toastLocator - Optional specific toast locator
 */
export async function verifyAndCloseToast(
  page: Page,
  expectedMessage: string,
  toastLocator?: Locator,
): Promise<void> {
  const toast =
    toastLocator ||
    page
      .locator(LOCATORS.toastPopUp)
      .filter({ hasText: expectedMessage })
      // @index-exception: repeating an action raises identical toasts, so any one of them satisfies
      // the assertion - they are interchangeable rather than positional
      .first();
  await expect(toast).toBeVisible({ timeout: 10000 });
  await expect(toast).toContainText(expectedMessage);

  // Try multiple close button locators (different toast implementations)
  const closeButtonSelectors = [
    LOCATORS.closeBtn,
    LOCATORS.angularToastCloseBtn,
  ];

  for (const selector of closeButtonSelectors) {
    const closeButton = toast.locator(selector);
    try {
      if (await closeButton.isVisible({ timeout: 2000 })) {
        await clickElement(closeButton);
        logger.info(`Closed toast using selector: ${selector}`);
        return;
      }
    } catch {
      // Continue to next selector if current one not found
      continue;
    }
  }

  logger.info("No close button found, toast may auto-dismiss");
}

/**
 * Scroll to element and click it
 * @param locator - The locator to scroll to and click
 */
export async function scrollAndClick(locator: Locator): Promise<void> {
  await locator.scrollIntoViewIfNeeded();
  await assertVisible(locator);
  await assertEnabled(locator);
  await clickElement(locator);
}

/**
 * Retry action with exponential backoff
 * @param page - The page object
 * @param action - Async function to retry
 * @param maxRetries - Maximum number of retries (default: 3)
 * @param baseDelay - Base delay in milliseconds (default: 1000)
 */
export async function retryWithBackoff(
  page: Page,
  action: () => Promise<void>,
  maxRetries: number = 3,
  baseDelay: number = 1000,
  operationName: string = "Action",
): Promise<void> {
  let lastError: Error | undefined;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      await action();
      return;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));

      if (attempt === maxRetries - 1) {
        throw new RetryExhaustedError(operationName, maxRetries, lastError, {
          url: page.url(),
          attempt: attempt + 1,
        });
      }

      const delay = baseDelay * Math.pow(2, attempt);
      logger.debug(
        `Retry attempt ${attempt + 1}/${maxRetries} failed, retrying in ${delay}ms`,
        {
          operation: operationName,
          error: lastError.message,
        },
      );
      await page.waitForTimeout(delay);
    }
  }
}

/**
 * Navigate to a specific URL
 * @param URL - The URL to navigate to
 * @param page - The page object
 * @throws Error if URL is not provided
 */
export async function visit(page: Page, URL: string): Promise<void> {
  if (!URL) {
    throw new ConfigurationError("URL", { providedUrl: URL });
  }

  try {
    await page.goto(URL, { timeout: 300000, waitUntil: "domcontentloaded" });
  } catch (error) {
    throw new NavigationError(
      URL,
      error instanceof Error ? error : new Error(String(error)),
    );
  }
}

/**
 * Open a popup window by performing an action that triggers a new window/tab
 * Uses the correct Promise.all() pattern for TypeScript compatibility and race condition prevention
 *
 * @param page - The main page object
 * @param action - Async function that triggers the popup (e.g., clicking a link that opens a new window)
 * @returns Promise that resolves to the popup Page object
 *
 * @example
 * // Open Exchange Support product in popup
 * const exchangeSupportPopup = await openPopup(page, async () => {
 *   await page.getByText('Exchange Support').click();
 * });
 *
 * @example
 * // Open document in new tab
 * const documentPopup = await openPopup(page, async () => {
 *   await page.getByRole('link', { name: 'View Details' }).click();
 * });
 */
export async function openPopup(
  page: Page,
  action: () => Promise<void>,
  timeoutMs: number = 60000,
): Promise<Page> {
  const [popup] = await Promise.all([
    page.waitForEvent("popup", { timeout: timeoutMs }),
    action(),
  ]);
  return popup;
}

/**
 * Wait for loader to appear and then disappear
 * @param loaderIcn - The loader locator element
 * @description Waits for loader to become visible (3s timeout) then waits for it to become hidden (10s timeout)
 * Uses .first() to handle pages with multiple spinners
 */
export async function assertLoader(page: Page): Promise<void> {
  const loaderIcn = page.locator(LOCATORS.loaderIcn).first();
  await loaderIcn.waitFor({ state: "visible", timeout: 3000 }).catch(() => {});
  await loaderIcn.waitFor({ state: "hidden", timeout: 10000 });
}

/**
 * Wait for spinner to appear and then disappear
 * @param spinnerIcn - The spinner locator element
 * @description Waits for spinner to become visible (3s timeout) then waits for it to become hidden (60s timeout)
 */
export async function assertSpinner(page: Page): Promise<void> {
  const spinnerIcn = page.locator(LOCATORS.spinnerIcn);
  await spinnerIcn.waitFor({ state: "visible", timeout: 3000 }).catch(() => {});
  await spinnerIcn.waitFor({ state: "hidden", timeout: 60000 });
}

/**
 * Reloads the entire page and waits for spinner
 * @param page - The page object
 * @description Reloads the page and waits for the spinner to complete
 */
export async function reloadPage(page: Page): Promise<void> {
  await page.reload();
  await assertSpinner(page);
}

/**
 * Wait for page to fully load including DOM mutations
 * @param page - The page object
 * @param maxTimeoutMs - Maximum timeout in milliseconds (default: 300000ms)
 * @description Waits for document.readyState to be 'complete' and monitors DOM mutations using MutationObserver
 * to ensure the page is fully stabilized before proceeding
 */
export async function waitForPageLoad(
  page: Page,
  maxTimeoutMs: number = 300000,
): Promise<void> {
  await page.waitForFunction(
    () => document.readyState === "complete",
    undefined,
    {
      timeout: maxTimeoutMs,
    },
  );

  const observeMutations = (maxMs: number) =>
    page.evaluate((innerMaxMs) => {
      return new Promise<void>((resolve) => {
        const startTime = Date.now();
        let timeout: ReturnType<typeof setTimeout>;

        const observer = new MutationObserver(() => {
          clearTimeout(timeout);
          if (Date.now() - startTime > innerMaxMs - 1000) {
            observer.disconnect();
            resolve();
            return;
          }
          timeout = setTimeout(() => {
            observer.disconnect();
            resolve();
          }, 500);
        });

        observer.observe(document.body, { childList: true, subtree: true });
        timeout = setTimeout(() => {
          observer.disconnect();
          resolve();
        }, 500);
      });
    }, maxMs);

  try {
    await observeMutations(maxTimeoutMs);
  } catch (error) {
    // A navigation landing between the readyState check and the evaluate() call above
    // tears down the execution context mid-flight (e.g. clicking "stop impersonation"
    // triggers a redirect). That's not a real failure - wait for the new document to
    // settle and retry the mutation observer once against it.
    if (
      error instanceof Error &&
      error.message.includes("Execution context was destroyed")
    ) {
      await page.waitForFunction(
        () => document.readyState === "complete",
        undefined,
        {
          timeout: maxTimeoutMs,
        },
      );
      await observeMutations(maxTimeoutMs);
      return;
    }
    throw error;
  }
}

/**
 * Assert that the current page URL contains a specific substring
 * @param page - The page object
 * @param expectedSubstring - The substring that should be present in the URL
 * @description Waits for page to load completely, then checks if current URL contains the expected substring.
 * Normalizes the expected substring by removing spaces and trimming whitespace.
 */
export async function assertUrlContains(
  page: Page,
  expectedSubstring: string,
): Promise<void> {
  await waitForPageLoad(page);
  const url = page.url();
  const normalizedExpected = expectedSubstring.replace(/\s+/g, "").trim();
  expect(url).toContain(normalizedExpected);
  logger.info(`URL asserted successfully: contains "${normalizedExpected}"`);
}

/**
 * Clicks an element and captures the resulting popup/new tab
 * @param page - The page object
 * @param triggerClick - Function that triggers the click action to open popup
 * @returns Promise that resolves to the popup page object
 * @description Executes the trigger click action while simultaneously waiting for a popup event,
 * then waits for the popup to load its DOM content before returning the popup page
 */
export async function openPopupByClicking(
  page: Page,
  triggerClick: () => Promise<void>,
  timeoutMs: number = 60000,
): Promise<Page> {
  const [popup] = await Promise.all([
    page.waitForEvent("popup", { timeout: timeoutMs }),
    triggerClick(),
  ]);
  await popup.waitForLoadState("domcontentloaded", { timeout: timeoutMs });
  return popup;
}

/**
 * Safely closes a page/window without throwing errors
 * @param page - The page object to close
 * @description Attempts to close the page, but silently handles errors if the page is already closed
 */
export async function safeClosePage(page: Page | undefined): Promise<void> {
  if (page && !page.isClosed()) {
    await page.close().catch(() => {
      // Page might already be closed, ignore error
    });
  }
}

/**
 * Wait with polling logic for a specific duration
 * @param pageContext - The page context to use for waiting
 * @param timeoutMs - Total timeout in milliseconds (default: 2000)
 * @param pollMs - Polling interval in milliseconds (default: 2000)
 */
export async function waitForTimePollingLogic(
  pageContext: Page,
  timeoutMs: number = 2000,
  pollMs: number = 2000,
): Promise<void> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    await pageContext.waitForTimeout(pollMs);
  }
  await pageContext.waitForTimeout(timeoutMs);
}

/**
 * Verify modal header text is displayed
 * @param page - The page object
 * @param headingText - The heading text to verify (e.g., "Address", "Confirmation", "Select New Default Address")
 */
export async function verifyModalHeaderText(
  page: Page,
  headingText: string,
): Promise<void> {
  const heading = page.getByRole("heading", { name: headingText });
  await assertVisible(heading);
  logger.info(`Verified heading: ${headingText}`);
}

export async function waitForDomStability(
  page: Page,
  selector: string,
  pollIntervalMs: number = 500,
  stableCyclesRequired: number = 30,
  timeoutMs: number = 200000,
): Promise<void> {
  const start = Date.now();
  let stableCycles = 0;
  let previousHtml = "";

  while (Date.now() - start < timeoutMs) {
    const currentHtml = await page.$eval(selector, (el) => el.innerHTML);

    if (currentHtml === previousHtml) {
      stableCycles++;
      if (stableCycles >= stableCyclesRequired) {
        const duration = Date.now() - start;
        console.log(`✅ DOM stabilized in ${duration}ms`);
        return;
      }
    } else {
      stableCycles = 0;
      previousHtml = currentHtml;
    }

    await page.waitForTimeout(pollIntervalMs);
  }

  const duration = Date.now() - start;
  console.warn(
    `❌ DOM did not stabilize within ${timeoutMs}ms (waited ${duration}ms)`,
  );
  throw new Error(`DOM did not stabilize within ${timeoutMs}ms`);
}

export async function waitForEnabledOrVisible(
  pageContext: any,
  selector: Locator,
  timeoutMs: number = 5000,
  intervalMs: number = 150,
): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    await pageContext.waitForTimeout(intervalMs);
  }
  // Final check
  try {
    const loc = selector.first();
    return (
      (await loc.isVisible().catch(() => false)) &&
      (await loc.isEnabled().catch(() => false))
    );
  } catch {
    return false;
  }
}

/**
 * Generic polling utility that waits for a condition to be met
 * Uses Playwright's evaluate polling instead of waitForTimeout for proper async waiting
 *
 * @param page - The page object
 * @param conditionFn - Async function that returns the value to check
 * @param predicateFn - Function to test the condition (returns true when condition is met)
 * @param options - Configuration options
 * @returns The final value when condition is met
 *
 * @example
 * // Wait for scroll position to reach 250px
 * await waitForCondition(
 *   page,
 *   async () => {
 *     const scrollTop = await page.evaluate(() => document.querySelector('.modal')?.scrollTop ?? 0);
 *     return scrollTop;
 *   },
 *   (value) => value >= 250,
 *   { timeout: 3000, pollingInterval: 100 }
 * );
 *
 * @example
 * // Wait for element count to be greater than 0
 * await waitForCondition(
 *   page,
 *   async () => await page.locator('.item').count(),
 *   (count) => count > 0,
 *   { timeout: 5000 }
 * );
 */
export async function waitForCondition<T>(
  page: Page,
  conditionFn: () => Promise<T>,
  predicateFn: (value: T) => boolean,
  options: {
    timeout?: number;
    pollingInterval?: number;
    errorMessage?: string;
  } = {},
): Promise<T> {
  const {
    timeout = 5000,
    pollingInterval = 100,
    errorMessage = "Condition not met within timeout",
  } = options;
  const startTime = Date.now();
  let lastValue: T | undefined;

  while (Date.now() - startTime < timeout) {
    try {
      const value = await conditionFn();
      lastValue = value;

      if (predicateFn(value)) {
        return value;
      }

      // Use Promise-based delay instead of waitForTimeout
      await new Promise((resolve) => setTimeout(resolve, pollingInterval));
    } catch {
      // Continue polling even if condition function throws
      await new Promise((resolve) => setTimeout(resolve, pollingInterval));
    }
  }

  const elapsed = Date.now() - startTime;
  throw new Error(
    `${errorMessage} after ${elapsed}ms. Last value: ${JSON.stringify(lastValue)}`,
  );
}

/**
 * Assert that an element contains the expected text
 *
 * Pass `timeout` whenever the assertion can legitimately fail (a value derived from a date, a count,
 * or anything else the test computes). Left unset, the expect inherits the project-wide
 * `expect.timeout`, which equals the per-test timeout — so a genuinely wrong value stops the test as
 * a bare "Test timeout exceeded" and the expected-vs-actual text never reaches the failure message.
 *
 * Measured on ATM 2026-09-15 (MEXV-16919 finding 1c): a call with no `timeout` consumed the whole 90s
 * budget and the run was reported as a test timeout, naming neither the element nor the text expected.
 * The `message` passed to `expect` below is the mitigation available without changing that budget: it
 * becomes the assertion's step title, so the expected text is recorded in the step list and the trace
 * even on the runs where the timeout swallows the matcher's own diff. It does NOT bound the wait —
 * pass `timeout` for that.
 *
 * @param locator - The locator to check
 * @param text - The text that should be contained in the element
 * @param timeout - Optional timeout in milliseconds for both the visibility and the text check
 */
export async function assertContainsText(
  locator: Locator,
  text: string,
  timeout?: number,
): Promise<void> {
  await assertVisible(locator, timeout);
  await expect(
    locator,
    `expected element to contain text '${text}'`,
  ).toContainText(text, timeout === undefined ? undefined : { timeout });
}

/**
 * Assert that an element contains the expected text or matches a pattern
 * Supports both string and RegExp patterns with custom error messages
 * @param locator - The locator to check
 * @param expected - String or RegExp pattern to match
 * @param errorMessage - Custom error message if assertion fails
 */
export async function assertLocatorContainsText(
  locator: Locator,
  expected: string | RegExp,
  errorMessage?: string,
): Promise<void> {
  const actualText = await readJoinedTextContent(locator);
  const isMatch =
    typeof expected === "string"
      ? actualText.includes(expected)
      : expected.test(actualText);

  if (!isMatch) {
    const message = errorMessage
      ? `${errorMessage}. Actual text: ${actualText}`
      : `Expected text not found. Actual: ${actualText}`;
    throw new Error(message);
  }
}

/**
 * Waits for the element to be attached and returns the joined, trimmed text of every match.
 * Shared by the contains-text assertions so they all read the DOM the same way.
 */
async function readJoinedTextContent(locator: Locator): Promise<string> {
  await locator.waitFor({ state: "attached", timeout: 30000 });
  const allTexts = await locator.allTextContents().catch(() => []);
  return (
    allTexts.length > 0
      ? allTexts.join(" ")
      : (await locator.textContent().catch(() => "")) || ""
  ).trim();
}

/**
 * True when `actual` contains `expected` once both are lowercased and stripped of every whitespace
 * character. Tolerates line breaks, indentation and text split across child elements with no
 * separating space - the situations page objects previously covered with a dynamically built
 * `new RegExp(escapeRegExp(expected).replace(/\s+/g, '\\s*'), 'i')`. A plain string comparison
 * keeps the same tolerance without feeding caller text into a regular expression, which SAST
 * scanners flag as a ReDoS surface (Wiz WS-I011-JAVASCRIPT-00003 / WS-I013-JAVASCRIPT-00092,
 * CWE-185 / CWE-1333).
 * @param actual - Text read from the page
 * @param expected - Text that must appear in it
 */
export function textIncludesIgnoringCaseAndWhitespace(
  actual: string,
  expected: string,
): boolean {
  const normalize = (value: string): string =>
    value.replace(/\s+/g, "").toLowerCase();
  return normalize(actual).includes(normalize(expected));
}

/**
 * Assert that an element's text contains the expected text, ignoring case and every whitespace
 * difference (see textIncludesIgnoringCaseAndWhitespace for the exact rule and why it is a plain
 * string comparison rather than a regular expression).
 * @param locator - The locator to check
 * @param expected - Text the element must contain
 * @param errorMessage - Custom error message if assertion fails
 */
export async function assertLocatorContainsTextIgnoringCaseAndWhitespace(
  locator: Locator,
  expected: string,
  errorMessage?: string,
): Promise<void> {
  const actualText = await readJoinedTextContent(locator);
  if (!textIncludesIgnoringCaseAndWhitespace(actualText, expected)) {
    const message = errorMessage
      ? `${errorMessage}. Actual text: ${actualText}`
      : `Expected text "${expected}" not found (ignoring case and whitespace). Actual: ${actualText}`;
    throw new Error(message);
  }
}

/**
 * Assert that an element has the expected text
 *
 * Accepts a RegExp as well as a string so a caller can assert one of several acceptable values, or
 * tolerate surrounding whitespace, and still get `toHaveText`'s auto-retry — which a one-shot
 * `textContent()` read does not provide when the value settles asynchronously.
 *
 * @param locator - The locator to check
 * @param text - The text that should be present in the element, or a pattern it must match
 * @param timeout - Optional cap on the retry window. Worth setting when the caller has its own
 * retry loop around this assertion, so a value that will never arrive fails fast enough for that
 * loop to do something about it instead of consuming the whole project-level expect timeout.
 */
export async function assertHaveText(
  locator: Locator,
  text: string | RegExp,
  timeout?: number,
): Promise<void> {
  await assertVisible(locator, timeout);
  await expect(locator).toHaveText(
    text,
    timeout === undefined ? undefined : { timeout },
  );
}

/**
 * Assert that an element's attribute has the expected value
 *
 * Use for contracts that are invisible to a text assertion but still part of what the user gets —
 * a link's href and target, an input's placeholder, an aria state.
 * @param locator - The locator to check
 * @param attribute - Attribute name (e.g. 'href', 'target')
 * @param value - Expected attribute value, or a pattern to match it against
 */
export async function assertHaveAttribute(
  locator: Locator,
  attribute: string,
  value: string | RegExp,
): Promise<void> {
  await assertVisible(locator);
  await expect(locator).toHaveAttribute(attribute, value);
}

/**
 * Helper function to generate random N-digit number
 * @param digits - Number of digits to generate (e.g., 4 for 4-digit, 5 for 5-digit)
 * @returns Random number as string with specified digits
 * @example
 * getRandomDigits(4)  // Returns "7492" (random 4-digit number: 1000-9999)
 * getRandomDigits(5)  // Returns "54821" (random 5-digit number: 10000-99999)
 * getRandomDigits(6)  // Returns "783456" (random 6-digit number: 100000-999999)
 */
export const getRandomDigits = (digits: number): string => {
  const min = Math.pow(10, digits - 1); // e.g., 10^3 = 1000 for 4 digits
  const max = Math.pow(10, digits) - 1; // e.g., 10^4 - 1 = 9999 for 4 digits
  return Math.floor(min + Math.random() * (max - min + 1)).toString();
};

/**
 * Helper function to encode password to Base64
 * @param password - Plain text password to encode
 * @returns Base64 encoded password string
 * @example
 * encodePassword('MyPassword123')  // Returns "TXlQYXNzd29yZDEyMw=="
 * encodePassword('test@123')       // Returns "dGVzdEAxMjM="
 */
export const encodePassword = (password: string): string => {
  const bytes = new TextEncoder().encode(password);
  let binary = "";

  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });

  return btoa(binary);
};

/**
 * Assert that an element is not empty
 * @param locator - The locator to check
 */
export async function assertNotToBeEmpty(locator: Locator): Promise<void> {
  await assertVisible(locator);
  await expect(locator).not.toBeEmpty();
}

/**
 * Assert that an actual numeric value is greater than the expected minimum
 * @param actualValue - The actual number to check
 * @param expectedMinValue - The minimum value the actual number should exceed
 */
export async function assertGreaterThan(
  actualValue: number,
  expectedMinValue: number,
): Promise<void> {
  await expect(actualValue).toBeGreaterThan(expectedMinValue);
}

/**
 * Assert that an actual numeric value equals the expected value
 * @param actualValue - The actual number to check
 * @param expectedValue - The value the actual number should equal
 * @param message - Optional custom error message
 */
export async function assertNumberEquals(
  actualValue: number,
  expectedValue: number,
  message?: string,
): Promise<void> {
  await expect(actualValue, message).toBe(expectedValue);
}

/**
 * Assert that an actual numeric value is greater than or equal to the expected minimum
 * @param actualValue - The actual number to check
 * @param expectedMinValue - The minimum value the actual number should meet or exceed
 * @param message - Optional custom error message
 */
export async function assertGreaterThanOrEqual(
  actualValue: number,
  expectedMinValue: number,
  message?: string,
): Promise<void> {
  await expect(actualValue, message).toBeGreaterThanOrEqual(expectedMinValue);
}

/**
 * Assert that an actual numeric value is less than or equal to the expected maximum
 * @param actualValue - The actual number to check
 * @param expectedMaxValue - The maximum value the actual number should meet or not exceed
 * @param message - Optional custom error message
 */
export async function assertLessThanOrEqual(
  actualValue: number,
  expectedMaxValue: number,
  message?: string,
): Promise<void> {
  await expect(actualValue, message).toBeLessThanOrEqual(expectedMaxValue);
}

/**
 * Assert that a string contains the expected substring
 * @param actualText - The actual text to check
 * @param expectedSubstring - The substring that should be contained
 */
export function assertStringContains(
  actualText: string,
  expectedSubstring: string,
): void {
  expect(actualText).toContain(expectedSubstring);
}

/**
 * Assert that a string matches a regular expression pattern
 * @param actualText - The actual text to check
 * @param pattern - The regex pattern to match against
 */
export function assertStringMatches(actualText: string, pattern: RegExp): void {
  expect(actualText).toMatch(pattern);
}

/**
 * Wait for Material Design options to be visible
 * @param page - The page object
 * @param timeout - Timeout in milliseconds (default: 5000)
 */
export async function waitForMatOptions(
  page: Page,
  timeout: number = 5000,
): Promise<void> {
  await page.waitForSelector(LOCATORS.matOptionSel, {
    state: "visible",
    timeout,
  });
}

/**
 * Wait until a locator matches at least the expected count
 * @param locator - The locator to poll
 * @param minCount - Minimum number of elements expected (default: 1)
 * @param timeout - Timeout in milliseconds (default: 15000)
 */
export async function waitForLocatorCount(
  locator: Locator,
  minCount: number = 1,
  timeout: number = 15000,
): Promise<void> {
  await expect
    .poll(() => locator.count(), { timeout })
    .toBeGreaterThanOrEqual(minCount);
}

/**
 * Assert that a locator matches exactly the expected number of elements.
 * Use this when the count itself is the assertion - waitForLocatorCount only guarantees a
 * minimum, so it cannot detect a grid returning more results than expected
 * @param locator - The locator to count
 * @param expectedCount - Exact number of elements expected
 * @param timeout - Timeout in milliseconds (default: 15000)
 */
export async function assertLocatorCountEquals(
  locator: Locator,
  expectedCount: number,
  timeout: number = 15000,
): Promise<void> {
  await expect(locator).toHaveCount(expectedCount, { timeout });
}

/**
 * Generic wait for grid/table results to load
 * Waits for row locator count to be greater than 0
 * @param rowLocator - The locator for grid/table rows
 * @param options - Configuration options
 * @returns The number of rows found
 *
 * @example
 * // Wait for Nexus catalog results
 * await waitForGridResults(page.locator('.nexus-grid .ag-row'));
 *
 * @example
 * // Wait for order results with custom timeout
 * await waitForGridResults(page.locator('[role="row"]'), { timeout: 60000 });
 */
export async function waitForGridResults(
  rowLocator: Locator,
  options: {
    timeout?: number;
    minCount?: number;
    errorMessage?: string;
  } = {},
): Promise<number> {
  const {
    timeout = 30000,
    minCount = 1,
    errorMessage = "Grid results did not load within timeout",
  } = options;

  const rowCount = await waitForCondition(
    rowLocator.page(),
    async () => await rowLocator.count(),
    (count) => count >= minCount,
    { timeout, pollingInterval: 250, errorMessage },
  );

  logger.info(`Grid results loaded: ${rowCount} row(s) found`);
  return rowCount;
}

/**
 * Wait for element to be visible with timeout, returns true if found, false if not
 * @param locator - The locator to wait for
 * @param timeout - Timeout in milliseconds (default: 5000)
 * @returns true if element becomes visible, false if timeout
 */
export async function waitForElementVisible(
  locator: Locator,
  timeout: number = 5000,
): Promise<boolean> {
  return await locator
    .waitFor({ state: "visible", timeout })
    .then(() => true)
    .catch(() => false);
}

/**
 * Asserts that an API response completed successfully (HTTP 2xx status).
 * Use this instead of raw `expect(result.ok).toBeTruthy()` for clearer
 * failure messages that include the status code and response URL.
 * @param response - The API response object (e.g., from `page.request` or `fetch`)
 * @param description - Optional context describing the API call (e.g., "disable validation rule")
 */
export function assertResponseOk(
  response: { ok: boolean; status: number; url?: string },
  description?: string,
): void {
  const context = description ? ` [${description}]` : "";
  const urlInfo = response.url ? ` from ${response.url}` : "";
  expect(
    response.ok,
    `API response failed${context}: status ${response.status}${urlInfo}`,
  ).toBeTruthy();
}

/**
 * Assert element is attached to the DOM (does not require visibility)
 * Use for elements clipped or hidden by virtual scroll containers
 * @param locator - The locator to check
 */
export async function assertAttached(
  locator: Locator,
  timeout?: number,
): Promise<void> {
  if (timeout) {
    await expect(locator).toBeAttached({ timeout });
  } else {
    await expect(locator).toBeAttached();
  }
}

/**
 * Assert that two arrays are equal
 * @param actualArray - The actual array to check
 * @param expectedArray - The expected array to match
 */
export async function assertArraysEqual(
  actualArray: string[],
  expectedArray: string[],
): Promise<void> {
  await expect(actualArray).toEqual(expectedArray);
}

/**
 * Assert that a checkbox or radio button is checked
 * @param locator - The locator to check
 * @param timeout - Optional timeout in milliseconds
 */
export async function assertChecked(
  locator: Locator,
  timeout?: number,
): Promise<void> {
  await expect(locator).toBeChecked(
    timeout === undefined ? undefined : { timeout },
  );
}

/**
 * Assert that a value is truthy
 * @param actualValue - The value to check
 * @param message - Optional custom error message
 */
export async function assertTruthy(
  actualValue: boolean,
  message?: string,
): Promise<void> {
  await expect(actualValue, message).toBe(true);
}

/**
 * Assert that a value is falsy
 * @param actualValue - The value to check
 * @param message - Optional custom error message
 */
export async function assertFalsy(
  actualValue: boolean,
  message?: string,
): Promise<void> {
  await expect(actualValue, message).toBe(false);
}

/**
 * Assert that a checkbox or radio button is NOT checked
 * @param locator - The locator to check
 * @param timeout - Optional timeout in milliseconds
 */
export async function assertNotChecked(
  locator: Locator,
  timeout?: number,
): Promise<void> {
  await expect(locator).not.toBeChecked(
    timeout === undefined ? undefined : { timeout },
  );
}

/**
 * Assert that an input element has a non-empty value
 * @param locator - The input locator to check
 */
export async function assertValueNotEmpty(locator: Locator): Promise<void> {
  await assertVisible(locator);
  const value = await locator.inputValue();
  await expect(value.trim()).not.toBe("");
}

/**
 * Assert element is visible with retry logic
 * Useful when verifying post-conditions where DOM might still be updating
 * @param locator - The locator to check
 * @param label - Optional label for logging
 * @param maxRetries - Maximum number of retry attempts (default: 3)
 * @param retryDelay - Delay between retries in ms (default: 1000)
 */
export async function assertVisibleWithRetry(
  locator: Locator,
  label?: string,
  maxRetries: number = 3,
  retryDelay: number = 1000,
): Promise<void> {
  let lastError: Error | null = null;
  const logLabel = label ? ` "${label}"` : "";

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      await assertVisible(locator);
      logger.info(
        `Verified${logLabel} is visible (attempt ${attempt}/${maxRetries})`,
      );
      return; // Success
    } catch (error) {
      lastError = error as Error;
      logger.warn(
        `Verification failed${logLabel} (attempt ${attempt}/${maxRetries}): ${error}`,
      );

      if (attempt < maxRetries) {
        await locator.page().waitForTimeout(retryDelay);
      }
    }
  }

  const error = new Error(
    `Failed to verify${logLabel} is visible after ${maxRetries} attempts`,
  );
  (error as Error & { cause?: unknown }).cause = lastError;
  throw error;
}

/**
 * Assert that an input element has the expected value
 * @param locator - The input locator to check
 * @param value - The value that should be present in the input
 */
export async function assertInputValue(
  locator: Locator,
  value: string,
): Promise<void> {
  await assertVisible(locator);
  await expect(locator).toHaveValue(value);
}

/**
 * Wait for Angular Material toggle to reach expected state
 * @param toggleBtn - Toggle button locator (button[role="switch"])
 * @param expectedState - true for checked, false for unchecked
 * @param timeout - Maximum wait time
 */
export async function waitForToggleState(
  toggleBtn: Locator,
  expectedState: boolean,
  timeout = 3000,
): Promise<void> {
  await toggleBtn.waitFor({ state: "visible", timeout: 2000 }).catch(() => {
    logger.warn("Toggle button not visible");
  });

  // Poll for expected aria-checked state
  await expect
    .poll(
      async () => {
        const checked = await toggleBtn.getAttribute("aria-checked");
        return checked === expectedState.toString();
      },
      { timeout },
    )
    .toBeTruthy();

  logger.debug(`Toggle reached expected state: ${expectedState}`);
}

/**
 * Wait for Angular field blur event to complete and validation to be applied.
 * Uses intelligent waiting instead of a hard timeout.
 *
 * Does NOT use `window.getAllAngularTestabilities()` (Angular's zone-stability API). Verified
 * empirically (EGXC-54167) that on this app the API exists and returns a real testability
 * instance, but that instance's `isStable()` never reports true at this point in the flow -
 * some persistent recurring activity inside Angular's zone (a poller, a websocket, an interval)
 * keeps it permanently pending. Waiting on it here would always burn the full timeout for no
 * signal. See FRAMEWORK-STANDARDS.md for the general guidance this informed.
 *
 * @param field - Input field locator
 * @param validationIndicator - Optional validation indicator (error label, checkmark, etc.)
 * @param timeout - Maximum wait time (default 5000ms)
 */
export async function waitForAngularFieldBlur(
  field: Locator,
  validationIndicator?: Locator,
  timeout = 5000,
): Promise<void> {
  const page = field.page();

  // Strategy 1: Wait for validation indicator (error message, checkmark, etc.)
  if (validationIndicator) {
    try {
      await waitForCondition(
        page,
        async () => {
          const isVisible = await validationIndicator
            .isVisible()
            .catch(() => false);
          const isHidden = await validationIndicator
            .isHidden()
            .catch(() => false);
          return { isVisible, isHidden };
        },
        ({ isVisible, isHidden }) => isVisible || isHidden,
        {
          timeout,
          pollingInterval: 50,
          errorMessage: "Validation indicator state unchanged",
        },
      );
      logger.debug("Angular field blur - validation indicator state detected");
      return;
    } catch {
      logger.debug(
        "Validation indicator did not change, trying attribute-based detection",
      );
    }
  }

  // Strategy 2: Wait for Angular validation classes or attributes to be applied
  try {
    await waitForCondition(
      page,
      async () => {
        const classes = (await field.getAttribute("class")) || "";
        const ariaInvalid = await field.getAttribute("aria-invalid");
        return { classes, ariaInvalid };
      },
      ({ classes, ariaInvalid }) => {
        // Wait until validation classes are applied (Angular typically adds these)
        return (
          classes.includes("ng-touched") ||
          classes.includes("ng-dirty") ||
          classes.includes("ng-invalid") ||
          classes.includes("ng-valid") ||
          ariaInvalid !== null
        );
      },
      {
        timeout,
        pollingInterval: 50,
        errorMessage: "Angular validation classes not applied",
      },
    );
    logger.debug("Angular field blur - validation classes detected");
    return;
  } catch {
    logger.warn(
      `Angular field blur - no validation state detected after ${timeout}ms, proceeding anyway`,
    );
  }
}

/**
 * Wait for element attribute to reach expected value
 * Useful for monitoring state changes like aria-expanded, aria-checked, etc.
 * @param locator - Element to monitor
 * @param attribute - Attribute name (e.g., 'aria-expanded')
 * @param expectedValue - Expected attribute value
 * @param timeout - Maximum wait time
 */
export async function waitForAttributeValue(
  locator: Locator,
  attribute: string,
  expectedValue: string,
  timeout = 3000,
): Promise<void> {
  await expect
    .poll(
      async () => {
        const value = await locator.getAttribute(attribute);
        return value === expectedValue;
      },
      {
        timeout,
        message: `Attribute ${attribute} should be "${expectedValue}"`,
      },
    )
    .toBeTruthy();

  logger.debug(
    `Attribute ${attribute} reached expected value: ${expectedValue}`,
  );
}
