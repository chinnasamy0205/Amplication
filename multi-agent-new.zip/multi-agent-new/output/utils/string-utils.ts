/**
 * String utility functions
 * Reusable string manipulation and pattern extraction utilities
 */

/**
 * Extracts a specific capture group from a regex pattern match
 *
 * @param text - The text to search in
 * @param pattern - The regular expression pattern with capture groups
 * @param groupIndex - The capture group index to extract (default: 1)
 * @returns The extracted value or null if no match found
 *
 * @example
 * // Extract ID from URL
 * extractPattern('https://example.com/users/123', /\/users\/(\d+)/, 1)
 * // returns '123'
 *
 * @example
 * // Extract base URL
 * extractPattern('https://example.com/path', /^(https?:\/\/[^\/]+)/, 1)
 * // returns 'https://example.com'
 *
 * @example
 * // Extract flowId from response text
 * extractPattern('Started ActivityFlow:abc123', /Started ActivityFlow:([a-f0-9]+)/i, 1)
 * // returns 'abc123'
 */
export function extractPattern(
  text: string,
  pattern: RegExp,
  groupIndex: number = 1,
): string | null {
  const match = text.match(pattern);
  return match && match[groupIndex] ? match[groupIndex] : null;
}

/**
 * Extracts multiple capture groups from a regex pattern match
 *
 * @param text - The text to search in
 * @param pattern - The regular expression pattern with capture groups
 * @returns Array of captured groups (excluding the full match at index 0), or null if no match
 *
 * @example
 * // Extract RGB values
 * extractPatternGroups('rgb(255, 128, 64)', /rgb\((\d+),\s*(\d+),\s*(\d+)\)/)
 * // returns ['255', '128', '64']
 */
export function extractPatternGroups(text: string, pattern: RegExp): string[] | null {
  const match = text.match(pattern);
  if (!match) {
    return null;
  }
  // Return all capture groups (excluding index 0 which is the full match)
  return match.slice(1);
}
