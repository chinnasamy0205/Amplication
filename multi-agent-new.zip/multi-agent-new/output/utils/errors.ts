/**
 * Error Handling Utilities
 * Comprehensive error classes and utilities for test framework
 *
 * This module provides:
 * - Custom error classes with context and timestamps
 * - Error handling utilities for safe execution
 * - Error formatting and reporting
 * - Environment variable validation
 */

import { test } from '@playwright/test';
import logger from './logger';

// ============================================
// CUSTOM ERROR CLASSES
// ============================================

/**
 * Base class for all custom test errors
 * Provides detailed error messages with context, timestamps, and stack traces
 */
export class BaseTestError extends Error {
  public readonly timestamp: Date;
  public readonly context?: Record<string, unknown>;

  constructor(message: string, context?: Record<string, unknown>) {
    super(message);
    this.name = this.constructor.name;
    this.timestamp = new Date();
    this.context = context;

    // Maintains proper stack trace for where our error was thrown
    Error.captureStackTrace(this, this.constructor);
  }

  /**
   * Returns formatted error message with context
   */
  getDetailedMessage(): string {
    let msg = `[${this.name}] ${this.message}`;
    if (this.context) {
      msg += `\nContext: ${JSON.stringify(this.context, null, 2)}`;
    }
    msg += `\nTimestamp: ${this.timestamp.toISOString()}`;
    return msg;
  }
}

/**
 * Thrown when test setup fails (login, navigation, etc.)
 */
export class TestSetupError extends BaseTestError {
  constructor(message: string, context?: Record<string, unknown>) {
    super(message, context);
  }
}

/**
 * Thrown when a page object action fails
 */
export class PageObjectError extends BaseTestError {
  constructor(
    pageName: string,
    action: string,
    originalError?: Error,
    context?: Record<string, unknown>,
  ) {
    const message = `Failed to ${action} on ${pageName}`;
    super(message, {
      ...context,
      pageName,
      action,
      originalError: originalError?.message,
      originalStack: originalError?.stack,
    });
  }
}

/**
 * Thrown when element interaction fails
 */
export class ElementInteractionError extends BaseTestError {
  constructor(
    elementName: string,
    action: string,
    originalError?: Error,
    context?: Record<string, unknown>,
  ) {
    const message = `Failed to ${action} on element "${elementName}"`;
    super(message, {
      ...context,
      elementName,
      action,
      originalError: originalError?.message,
    });
  }
}

/**
 * Thrown when assertion fails
 */
export class AssertionError extends BaseTestError {
  constructor(expected: unknown, actual: unknown, context?: Record<string, unknown>) {
    const message = `Assertion failed: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`;
    super(message, {
      ...context,
      expected,
      actual,
    });
  }
}

/**
 * Thrown when navigation fails
 */
export class NavigationError extends BaseTestError {
  constructor(url: string, originalError?: Error, context?: Record<string, unknown>) {
    const message = `Failed to navigate to ${url}`;
    super(message, {
      ...context,
      url,
      originalError: originalError?.message,
    });
  }
}

/**
 * Thrown when authentication fails
 */
export class AuthenticationError extends BaseTestError {
  constructor(
    loginType: string,
    username: string,
    originalError?: Error,
    context?: Record<string, unknown>,
  ) {
    const message = `Authentication failed for ${loginType} login with user ${username}`;
    super(message, {
      ...context,
      loginType,
      username,
      originalError: originalError?.message,
    });
  }
}

/**
 * Thrown when page load times out
 */
export class PageLoadTimeoutError extends BaseTestError {
  constructor(pageName: string, timeout: number, context?: Record<string, unknown>) {
    const message = `Page "${pageName}" failed to load within ${timeout}ms`;
    super(message, {
      ...context,
      pageName,
      timeout,
    });
  }
}

/**
 * Thrown when configuration is missing or invalid
 */
export class ConfigurationError extends BaseTestError {
  constructor(configKey: string, context?: Record<string, unknown>) {
    const message = `Missing or invalid configuration: ${configKey}`;
    super(message, {
      ...context,
      configKey,
    });
  }
}

/**
 * Thrown when a retry operation fails after max attempts
 */
export class RetryExhaustedError extends BaseTestError {
  constructor(
    operation: string,
    maxRetries: number,
    lastError?: Error,
    context?: Record<string, unknown>,
  ) {
    const message = `Operation "${operation}" failed after ${maxRetries} retries`;
    super(message, {
      ...context,
      operation,
      maxRetries,
      lastError: lastError?.message,
    });
  }
}

/**
 * Thrown when document building from template fails
 */
export class DocumentBuildError extends BaseTestError {
  constructor(templateName: string, cause: Error, context?: Record<string, unknown>) {
    const message = `Failed to build document from template "${templateName}": ${cause.message}`;
    super(message, {
      ...context,
      templateName,
      originalError: cause.message,
      originalStack: cause.stack,
    });
  }
}

/**
 * Thrown when posting document to Exchange fails
 */
export class ExchangePostError extends BaseTestError {
  constructor(operation: string, cause: Error, context?: Record<string, unknown>) {
    const message = `Failed to post document to Exchange: ${cause.message}`;
    super(message, {
      ...context,
      operation,
      originalError: cause.message,
      originalStack: cause.stack,
    });
  }
}

/**
 * Thrown when verification times out waiting for document processing
 */
export class VerificationTimeoutError extends BaseTestError {
  constructor(verificationType: string, timeout: number, context?: Record<string, unknown>) {
    const message = `${verificationType} verification timed out after ${timeout}ms`;
    super(message, {
      ...context,
      verificationType,
      timeout,
    });
  }
}

/**
 * Thrown when a two-leg G-Fax drop fails to correlate into the G-Fax channel.
 *
 * Correlation is provisioning-dependent: the fax AccountID must still be provisioned for the
 * supplier EID used as the correlation filename's middle token. When that pairing lapses, both
 * legs post successfully but the order lands in the Exchange channel instead. Carrying both flow
 * ids and the audit URL makes that distinguishable from a genuine export-filter defect.
 */
export class GFaxCorrelationError extends BaseTestError {
  constructor(
    stage: string,
    context: {
      poNumber: string;
      parentFlowId?: string;
      orderFlowId?: string;
      correlationFilename?: string;
      observedChannel?: string;
      auditUrl?: string;
      [key: string]: unknown;
    },
  ) {
    const message = `G-Fax correlation failed at ${stage} for PO "${context.poNumber}"`;
    super(message, {
      ...context,
      stage,
    });
  }
}

/**
 * Thrown when document is not found in MongoDB collection
 */
export class DocumentNotFoundError extends BaseTestError {
  constructor(collection: string, query: Record<string, unknown>) {
    const message = `Document not found in ${collection} collection`;
    super(message, {
      collection,
      query,
    });
  }
}

// ============================================
// ERROR HANDLING UTILITIES
// ============================================

/**
 * Utility function to wrap errors with context
 */
export function wrapError(error: Error, context: Record<string, unknown>): BaseTestError {
  if (error instanceof BaseTestError) {
    // If already a custom error, add context
    return new BaseTestError(error.message, {
      ...error.context,
      ...context,
    });
  }
  // Wrap generic errors
  return new BaseTestError(error.message, {
    ...context,
    originalError: error.message,
    originalStack: error.stack,
  });
}

/**
 * Safely executes an async operation with error handling
 * @param operation - The async operation to execute
 * @param operationName - Name of the operation for logging
 * @param context - Additional context for error logging
 * @returns Result of the operation or throws a properly formatted error
 */
export async function safeExecute<T>(
  operation: () => Promise<T>,
  operationName: string,
  _context?: Record<string, unknown>,
): Promise<T> {
  try {
    return await operation();
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logger.error(`Operation "${operationName}" failed`, error instanceof Error ? error : undefined);

    if (error instanceof BaseTestError) {
      throw error;
    }

    // Always attach cause to preserve error context
    throw new Error(`${operationName} failed: ${errorMessage}`, { cause: error });
  }
}

/**
 * Attaches error context to Playwright test info for Allure reports
 * @param testInfo - Playwright test info object
 * @param error - The error to attach
 */
export function attachErrorToReport(testInfo: any, error: Error | BaseTestError): void {
  try {
    const errorDetails = {
      name: error.name,
      message: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString(),
      ...(error instanceof BaseTestError && { context: error.context }),
    };

    testInfo.attach('Error Details', {
      body: JSON.stringify(errorDetails, null, 2),
      contentType: 'application/json',
    });

    if (error instanceof BaseTestError) {
      logger.error('Test error occurred', error);
    }
  } catch (attachError) {
    logger.warn(
      'Failed to attach error to report',
      attachError instanceof Error ? attachError : undefined,
    );
  }
}

/**
 * Wraps a test step with error handling and logging
 * @param stepName - Name of the test step
 * @param operation - The test step operation
 * @param context - Additional context for error logging
 */
export async function testStep<T>(
  stepName: string,
  operation: () => Promise<T>,
  context?: Record<string, unknown>,
): Promise<T> {
  return await test.step(stepName, async () => {
    try {
      logger.debug(`Starting step: ${stepName}`, context);
      const result = await operation();
      logger.debug(`Completed step: ${stepName}`);
      return result;
    } catch (error) {
      logger.error(`Step "${stepName}" failed`, error instanceof Error ? error : undefined);
      throw error;
    }
  });
}

/**
 * Creates a safe wrapper for page object methods with automatic error handling
 * @param target - The page object instance
 * @param methodName - Name of the method to wrap
 * @param originalMethod - The original method to wrap
 * @param context - Additional context for errors
 */
export function createSafeMethod<T extends (...args: any[]) => Promise<any>>(
  target: any,
  methodName: string,
  originalMethod: T,
  _context?: Record<string, unknown>,
): T {
  return (async (...args: any[]) => {
    try {
      return await originalMethod.apply(target, args);
    } catch (error) {
      logger.error(`Method "${methodName}" failed`, error instanceof Error ? error : undefined);

      if (error instanceof BaseTestError) {
        throw error;
      }

      throw new Error(
        `${methodName} failed: ${error instanceof Error ? error.message : String(error)}`,
        { cause: error },
      );
    }
  }) as T;
}

/**
 * Validates that required environment variables are set
 * @param variables - Array of environment variable names to check
 * @throws ConfigurationError if any variable is missing
 */
export function validateEnvironmentVariables(variables: string[]): void {
  const missing: string[] = [];

  for (const variable of variables) {
    if (!process.env[variable]) {
      missing.push(variable);
    }
  }

  if (missing.length > 0) {
    const errorMessage = `Missing required environment variables: ${missing.join(', ')}`;
    logger.error(errorMessage);
    throw new Error(errorMessage);
  }
}

/**
 * Formats error for display in test reports
 * @param error - The error to format
 * @returns Formatted error string
 */
export function formatErrorForReport(error: Error | BaseTestError): string {
  if (error instanceof BaseTestError) {
    return error.getDetailedMessage();
  }

  return `${error.name}: ${error.message}\n${error.stack || 'No stack trace available'}`;
}
