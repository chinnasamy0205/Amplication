import { Page, Locator } from '@playwright/test';
import { getButtonByName } from './abstract-page';
import * as fs from 'fs';
import * as path from 'path';

/**
 * Button profiling data structure
 */
export interface ButtonProfileData {
  timestamp: string;
  testFile: string;
  pageObject: string;
  buttonLabel: string;
  customLocator: string;
  customElementSnapshot?: {
    tagName: string;
    text: string;
    attributes: Record<string, string>;
    boundingBox: { x: number; y: number; width: number; height: number } | null;
  };
  genericLocator: string;
  genericElementSnapshot?: {
    tagName: string;
    text: string;
    attributes: Record<string, string>;
    boundingBox: { x: number; y: number; width: number; height: number } | null;
  };
  matchesGeneric: boolean;
  conflict: boolean;
  conflictCount?: number;
  recommendation: 'use-generic' | 'keep-custom' | 'needs-review';
  reason: string;
}

/**
 * Captures DOM snapshot of an element
 */
async function captureElementSnapshot(locator: Locator) {
  try {
    const element = await locator.elementHandle();
    if (!element) return undefined;

    const tagName = await element.evaluate((el) => el.tagName.toLowerCase());
    const text = await element.evaluate((el) => el.textContent?.trim() || '');
    const attributes = await element.evaluate((el) => {
      const attrs: Record<string, string> = {};
      for (let i = 0; i < el.attributes.length; i++) {
        const attr = el.attributes[i];
        attrs[attr.name] = attr.value;
      }
      return attrs;
    });
    const boundingBox = await element.boundingBox();

    return { tagName, text, attributes, boundingBox };
  } catch {
    return undefined;
  }
}

/**
 * Profiles a button click to determine if it can use generic locator
 *
 * @param page - Playwright page object
 * @param customLocator - The custom locator being used
 * @param buttonLabel - The button label (e.g., 'Save', 'Next')
 * @param metadata - Test context metadata
 */
export async function profileButtonClick(
  page: Page,
  customLocator: Locator,
  buttonLabel: string,
  metadata: { testFile: string; pageObject: string },
): Promise<ButtonProfileData> {
  // Create generic locator
  const genericLocator = getButtonByName(page, buttonLabel);

  // Capture snapshots before click
  const customSnapshot = await captureElementSnapshot(customLocator);
  const genericSnapshot = await captureElementSnapshot(genericLocator);

  // Check if they resolve to the same element
  let matchesGeneric = false;
  if (customSnapshot && genericSnapshot) {
    matchesGeneric =
      customSnapshot.tagName === genericSnapshot.tagName &&
      customSnapshot.text === genericSnapshot.text &&
      JSON.stringify(customSnapshot.boundingBox) === JSON.stringify(genericSnapshot.boundingBox);
  }

  // Detect conflicts (multiple buttons with same text)
  let conflictCount: number | undefined;
  try {
    const allButtons = await page.getByRole('button', { name: buttonLabel }).all();
    conflictCount = allButtons.length;
  } catch {
    // If we can't detect conflicts, assume no conflict
    conflictCount = undefined;
  }
  const conflict = conflictCount !== undefined && conflictCount > 1;

  // Determine recommendation
  let recommendation: 'use-generic' | 'keep-custom' | 'needs-review';
  let reason: string;

  if (!genericSnapshot) {
    recommendation = 'keep-custom';
    reason = 'Generic locator does not resolve to any element';
  } else if (conflict) {
    recommendation = 'needs-review';
    reason = `Multiple buttons with text "${buttonLabel}" found (${conflictCount} total) - ambiguous generic selector`;
  } else if (matchesGeneric) {
    recommendation = 'use-generic';
    reason =
      'Custom and generic locators resolve to the same element - safe to use BasePage locator';
  } else {
    recommendation = 'needs-review';
    reason = 'Custom and generic locators resolve to different elements - needs investigation';
  }

  const profileData: ButtonProfileData = {
    timestamp: new Date().toISOString(),
    testFile: metadata.testFile,
    pageObject: metadata.pageObject,
    buttonLabel,
    customLocator: customLocator.toString(),
    customElementSnapshot: customSnapshot,
    genericLocator: genericLocator.toString(),
    genericElementSnapshot: genericSnapshot,
    matchesGeneric,
    conflict,
    conflictCount,
    recommendation,
    reason,
  };

  // Save profile data
  await saveProfileData(profileData);

  return profileData;
}

/**
 * Saves profile data to JSON file
 */
async function saveProfileData(data: ButtonProfileData): Promise<void> {
  const outputDir = path.join(process.cwd(), 'test-results', 'button-profiles');

  // Ensure directory exists
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  // Generate filename based on test and timestamp
  const testName = path.basename(data.testFile, '.spec.ts');
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `${testName}_${data.buttonLabel}_${timestamp}.json`;
  const filePath = path.join(outputDir, filename);

  // Write data
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

/**
 * Checks if button profiling is enabled
 */
export function isProfilingEnabled(): boolean {
  return process.env.PROFILE_BUTTONS === 'true';
}
