// utils/logger.ts
import { configure, getLogger } from 'log4js';
configure({
  appenders: {
    file: {
      type: 'file',
      filename: 'logs/app.log',
      maxLogSize: 10485760,
      backups: 3,
      compress: true,
    },
    console: { type: 'console' },
  },
  categories: {
    default: { appenders: ['file', 'console'], level: 'debug' },
  },
});

const logger = getLogger();

export default logger;
