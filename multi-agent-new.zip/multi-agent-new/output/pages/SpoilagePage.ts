import { expect, Locator, Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { spoilagePageLocators } from '../locators/spoilage-page.locators';
import {
  assertVisible,
  clickElementHasBtnLnkLocator,
} from '../utils/abstract-page';
import logger from '../utils/logger';

export class SpoilagePage extends BasePage {
  private readonly iconBackArrow: Locator;
  private readonly lblSpoilageTitle: Locator;
  private readonly iconHelp: Locator;
  private readonly txtUpcInput: Locator;
  private readonly chkManualMode: Locator;
  private readonly rdoShrink: Locator;
  private readonly rdoCorrection: Locator;
  private readonly lblQuantitySign: Locator;
  private readonly txtQuantity: Locator;
  private readonly btnSubmit: Locator;

  constructor(page: Page) {
    super(page, spoilagePageLocators);
    this.iconBackArrow = this.page.locator(spoilagePageLocators.iconBackArrow);
    this.lblSpoilageTitle = this.page.locator(spoilagePageLocators.lblSpoilageTitle);
    this.iconHelp = this.page.locator(spoilagePageLocators.iconHelp);
    this.txtUpcInput = this.page.locator(spoilagePageLocators.txtUpcInput);
    this.chkManualMode = this.page.locator(spoilagePageLocators.chkManualMode);
    this.rdoShrink = this.page.locator(spoilagePageLocators.rdoShrink);
    this.rdoCorrection = this.page.locator(spoilagePageLocators.rdoCorrection);
    this.lblQuantitySign = this.page.locator(spoilagePageLocators.lblQuantitySign);
    this.txtQuantity = this.page.locator(spoilagePageLocators.txtQuantity);
    this.btnSubmit = this.page.locator(spoilagePageLocators.btnSubmit);
    logger.info('SpoilagePage initialized');
  }

  async assertBackArrowVisible(): Promise<void> {
    await assertVisible(this.iconBackArrow, 30000);
    logger.info('Spoilage back arrow is visible');
  }

  async assertTitleVisible(): Promise<void> {
    await assertVisible(this.lblSpoilageTitle, 30000);
    logger.info('Spoilage title is visible');
  }

  async assertHelpIconVisible(): Promise<void> {
    await assertVisible(this.iconHelp, 30000);
    logger.info('Spoilage help icon is visible');
  }

  async assertUpcInputVisible(): Promise<void> {
    await assertVisible(this.txtUpcInput, 30000);
    logger.info('Spoilage UPC input is visible');
  }

  async assertScanModeSwitchVisible(): Promise<void> {
    await assertVisible(this.chkManualMode, 30000);
    logger.info('Scan/Type switch is visible');
  }

  async assertScanModeSelected(): Promise<void> {
    await expect(this.chkManualMode).not.toBeChecked({ timeout: 30000 });
    logger.info('Scan mode is selected by default');
  }

  async assertUpcPlaceholder(expectedPlaceholder: string): Promise<void> {
    await expect(this.txtUpcInput).toHaveAttribute('placeholder', expectedPlaceholder, { timeout: 30000 });
    logger.info('UPC input placeholder verified');
  }

  async assertShrinkRadioVisible(): Promise<void> {
    await assertVisible(this.rdoShrink, 30000);
    logger.info('Shrink radio is visible');
  }

  async assertCorrectionRadioVisible(): Promise<void> {
    await assertVisible(this.rdoCorrection, 30000);
    logger.info('Correction radio is visible');
  }

  async assertShrinkSelected(): Promise<void> {
    await expect(this.rdoShrink).toBeChecked({ timeout: 30000 });
    logger.info('Shrink is selected');
  }

  async selectCorrection(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.rdoCorrection);
    logger.info('Correction selected');
  }

  async selectShrink(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.rdoShrink);
    logger.info('Shrink selected');
  }

  async assertQuantitySign(expectedSign: string): Promise<void> {
    await assertVisible(this.lblQuantitySign, 30000);
    await expect(this.lblQuantitySign).toHaveText(expectedSign, { timeout: 30000 });
    logger.info('Quantity sign verified');
  }

  async assertQuantityInputVisible(): Promise<void> {
    await assertVisible(this.txtQuantity, 30000);
    logger.info('Quantity input is visible');
  }

  async assertSubmitButtonVisible(): Promise<void> {
    await assertVisible(this.btnSubmit, 30000);
    logger.info('Submit button is visible');
  }

  async assertSubmitButtonTeal(classPattern: string): Promise<void> {
    await expect(this.btnSubmit).toHaveClass(new RegExp(classPattern), { timeout: 30000 });
    logger.info('Submit button class verified');
  }

  async assertSubmitButtonDisabled(): Promise<void> {
    await expect(this.btnSubmit).toBeDisabled({ timeout: 30000 });
    logger.info('Submit button is disabled');
  }

  async assertShrinkAccessibleName(expectedName: string): Promise<void> {
    await expect(this.rdoShrink).toHaveAccessibleName(expectedName, { timeout: 30000 });
    logger.info('Shrink radio accessible name verified');
  }

  async assertCorrectionAccessibleName(expectedName: string): Promise<void> {
    await expect(this.rdoCorrection).toHaveAccessibleName(expectedName, { timeout: 30000 });
    logger.info('Correction radio accessible name verified');
  }
}