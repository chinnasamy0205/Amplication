import { expect, Locator, Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { inventoryAdjustmentPageLocators } from '../locators/inventory-adjustment-page.locators';
import {
  assertElementState,
  clickElementHasBtnLnkLocator,
  fillElementTxtLocator,
} from '../utils/abstract-page';
import logger from '../utils/logger';
import { DEFAULT_TIMEOUT } from '../utils/timeout';

export class InventoryAdjustmentPage extends BasePage {
  private readonly spoilageBtn: Locator;
  private readonly theftBtn: Locator;
  private readonly scanTypeChk: Locator;
  private readonly upcTxt: Locator;
  private readonly itemDetailsLbl: Locator;
  private readonly upcErrorMessageLbl: Locator;
  private readonly theftAdjustmentBtn: Locator;
  private readonly quantityTxt: Locator;
  private readonly submitAdjustmentBtn: Locator;
  private readonly quantityInput: Locator;
  private readonly adjustmentSuccessMessage: Locator;

  constructor(page: Page) {
    super(page, inventoryAdjustmentPageLocators);
    this.spoilageBtn = this.page.locator(inventoryAdjustmentPageLocators.spoilageBtn);
    this.theftBtn = this.page.locator(inventoryAdjustmentPageLocators.theftBtn);
    this.scanTypeChk = this.page.locator(inventoryAdjustmentPageLocators.scanTypeChk);
    this.upcTxt = this.page.locator(inventoryAdjustmentPageLocators.upcTxt);
    this.itemDetailsLbl = this.page.locator(inventoryAdjustmentPageLocators.itemDetailsLbl);
    this.upcErrorMessageLbl = this.page.locator(inventoryAdjustmentPageLocators.upcErrorMessageLbl);
    this.theftAdjustmentBtn = this.page.locator(inventoryAdjustmentPageLocators.theftAdjustmentBtn);
    this.quantityTxt = this.page.locator(inventoryAdjustmentPageLocators.quantityTxt);
    this.submitAdjustmentBtn = this.page.locator(inventoryAdjustmentPageLocators.submitAdjustmentBtn);
    this.quantityInput = this.page.locator(inventoryAdjustmentPageLocators.quantityInput);
    this.adjustmentSuccessMessage = this.page.locator(inventoryAdjustmentPageLocators.adjustmentSuccessMessage);
    logger.info('InventoryAdjustmentPage initialized');
  }

  async clickSpoilage(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.spoilageBtn);
    logger.info('Spoilage option selected from inventory adjustment');
  }

  async selectTheftReason(): Promise<void> {
    await this.theftBtn.waitFor({ state: 'visible', timeout: 30000 });
    await clickElementHasBtnLnkLocator(this.theftBtn);
    logger.info('Theft reason selected');
  }

  async switchToTypeMode(): Promise<void> {
    if (!(await this.scanTypeChk.isChecked())) {
      await clickElementHasBtnLnkLocator(this.scanTypeChk);
    }
    await this.upcTxt.waitFor({ state: 'visible', timeout: 30000 });
    logger.info('Type mode enabled and UPC field is visible');
  }

  async fillUpc(upc: string): Promise<void> {
    await fillElementTxtLocator(this.upcTxt, upc);
    logger.info('UPC entered');
  }

  async submitUpcLookup(): Promise<void> {
    await this.upcTxt.press('Enter');
    await this.itemDetailsLbl.waitFor({ state: 'visible', timeout: 30000 });
    logger.info('UPC lookup completed with item details visible');
  }

  async verifyItemDetailsVisible(): Promise<void> {
    await assertElementState(this.itemDetailsLbl, 'visible', DEFAULT_TIMEOUT);
  }

  async fillUpcScenario2(upc: string): Promise<void> {
    await fillElementTxtLocator(this.upcTxt, upc);
    logger.info('Scenario 2 UPC entered');
  }

  async submitUpcLookupScenario2(): Promise<void> {
    await this.upcTxt.press('Enter');
    await this.upcErrorMessageLbl.waitFor({ state: 'visible', timeout: 30000 });
    logger.info('Invalid UPC error message is visible');
  }

  async waitForAdjustmentScreen(): Promise<void> {
    await this.theftAdjustmentBtn.waitFor({ state: 'visible', timeout: 30000 });
    logger.info('Adjustment screen is visible');
  }

  async waitForTheftForm(): Promise<void> {
    await this.scanTypeChk.waitFor({ state: 'visible', timeout: 30000 });
    logger.info('Theft form is visible');
  }

  async waitForTypedUpcField(): Promise<void> {
    await this.upcTxt.waitFor({ state: 'visible', timeout: 30000 });
    logger.info('Typed UPC field is visible');
  }

  async fillQuantity(quantity: string): Promise<void> {
    await fillElementTxtLocator(this.quantityTxt, quantity);
    logger.info('Adjustment quantity entered');
  }

  async submitAdjustment(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.submitAdjustmentBtn);
    logger.info('Inventory adjustment submitted');
  }

  async verifyQuantityAccepted(expectedQuantity: string): Promise<void> {
    await expect(this.quantityInput).toHaveValue(expectedQuantity, { timeout: 30000 });
    logger.info('Adjustment quantity accepted');
  }

  async verifySuccessMessage(expectedMessage: string): Promise<void> {
    await expect(this.adjustmentSuccessMessage).toContainText(expectedMessage, { timeout: 30000 });
    logger.info('Adjustment success message displayed');
  }
}
