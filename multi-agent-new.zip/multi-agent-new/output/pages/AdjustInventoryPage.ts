import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { adjustInventoryPageLocators } from '../locators/adjust-inventory-page.locators';
import { clickElementHasBtnLnkLocator } from '../utils/abstract-page';
import logger from '../utils/logger';

export class AdjustInventoryPage extends BasePage {
  private readonly spoilageBtn: Locator;

  constructor(page: Page) {
    super(page, adjustInventoryPageLocators);
    this.spoilageBtn = this.page.locator(adjustInventoryPageLocators.spoilageBtn);
    logger.info('AdjustInventoryPage initialized');
  }

  async clickSpoilage(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.spoilageBtn);
    logger.info('Spoilage option selected');
  }
}