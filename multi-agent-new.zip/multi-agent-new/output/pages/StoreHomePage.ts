import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { storeHomePageLocators } from '../locators/store-home-page.locators';
import { clickElementHasBtnLnkLocator } from '../utils/abstract-page';
import logger from '../utils/logger';

export class StoreHomePage extends BasePage {
	private readonly activeStoreNameTxt: Locator;
	private readonly adjustInventoryBtn: Locator;

	constructor(page: Page) {
		super(page, storeHomePageLocators);
		this.activeStoreNameTxt = this.page.locator(storeHomePageLocators.activeStoreNameTxt);
		this.adjustInventoryBtn = this.page.locator(storeHomePageLocators.adjustInventoryBtn);
		logger.info('StoreHomePage initialized');
	}

	async verifyActiveStore(): Promise<void> {
		await this.activeStoreNameTxt.waitFor({ state: 'visible', timeout: 30000 });
		logger.info('Active store is visible');
	}

	async openInventoryAdjustment(): Promise<void> {
	await clickElementHasBtnLnkLocator(this.adjustInventoryBtn);
		await this.page.waitForURL(/\/adjust-inventory/, { timeout: 30000 });
		logger.info('Adjust Inventory page opened from store home');
	}
}
