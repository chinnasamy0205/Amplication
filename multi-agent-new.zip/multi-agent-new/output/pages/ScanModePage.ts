import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { scanModeLocators } from '../locators/scan-mode.locators';
import { clickElementHasBtnLnkLocator } from '../utils/abstract-page';
import logger from '../utils/logger';

export class ScanModePage extends BasePage {
  private readonly scanTypeChk: Locator;

  constructor(page: Page) {
    super(page, scanModeLocators);
    this.scanTypeChk = this.page.locator(scanModeLocators.scanTypeChk);
    logger.info('ScanModePage initialized');
  }

  async ensureScanMode(): Promise<void> {
    if (await this.scanTypeChk.isChecked()) {
      await clickElementHasBtnLnkLocator(this.scanTypeChk);
    }
    logger.info('Scan mode ensured');
  }
}