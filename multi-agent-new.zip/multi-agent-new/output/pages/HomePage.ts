import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { homePageLocators } from '../locators/home-page.locators';
import { clickElementHasBtnLnkLocator } from '../utils/abstract-page';
import logger from '../utils/logger';

export class HomePage extends BasePage {
  private readonly chooseStoreCombobox: Locator;
  private readonly longBeachOption: Locator;
  private readonly adjustInventoryButton: Locator;

  constructor(page: Page) {
    super(page, homePageLocators);
    this.chooseStoreCombobox = this.page.locator(homePageLocators.chooseStoreCombobox);
    this.longBeachOption = this.page.locator(homePageLocators.longBeachOption);
    this.adjustInventoryButton = this.page.locator(homePageLocators.adjustInventoryButton);
    logger.info('HomePage initialized');
  }

  async openStoreDropdown(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.chooseStoreCombobox);
    logger.info('Store dropdown opened');
  }

  async selectLongBeachStore(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.longBeachOption);
    logger.info('Long Beach store selected');
  }

  async openAdjustInventory(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.adjustInventoryButton);
    await this.page.waitForURL(/\/adjust-inventory/, { timeout: 30000 });
    logger.info('Inventory adjustment page opened');
  }
}