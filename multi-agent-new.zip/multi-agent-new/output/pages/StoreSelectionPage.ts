import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { storeSelectionPageLocators } from '../locators/store-selection-page.locators';
import { clickElementHasBtnLnkLocator } from '../utils/abstract-page';
import logger from '../utils/logger';

export class StoreSelectionPage extends BasePage {
  private readonly storeDropdownSel: Locator;
  private readonly longBeachStoreOptn: Locator;
  private readonly storeSelectorSel: Locator;
  private readonly adjustInventoryBtn: Locator;

  constructor(page: Page) {
    super(page, storeSelectionPageLocators);
    this.storeDropdownSel = this.page.locator(storeSelectionPageLocators.storeDropdownSel);
    this.longBeachStoreOptn = this.page.locator(storeSelectionPageLocators.longBeachStoreOptn);
    this.storeSelectorSel = this.page.locator(storeSelectionPageLocators.storeSelectorSel);
    this.adjustInventoryBtn = this.page.locator(storeSelectionPageLocators.adjustInventoryBtn);
    logger.info('StoreSelectionPage initialized');
  }

  async openStoreDropdown(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.storeDropdownSel);
    logger.info('Store dropdown opened');
  }

  async selectLongBeachStore(): Promise<void> {
    await this.openStoreDropdown();
    await clickElementHasBtnLnkLocator(this.longBeachStoreOptn);
    logger.info('Long Beach store selected');
  }

  async waitForStoreSelection(): Promise<void> {
    await this.storeSelectorSel.waitFor({ state: 'visible', timeout: 30000 });
    logger.info('Store selection page is visible');
  }

  async openInventoryAdjustment(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.adjustInventoryBtn);
    await this.page.waitForURL(/\/adjust-inventory/, { timeout: 30000 });
    logger.info('Adjust Inventory page opened from store selection');
  }
}