import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { loginPageLocators } from '../locators/login-page.locators';
import {
  assertElementState,
  clickElementHasBtnLnkLocator,
  fillElementTxtLocator,
} from '../utils/abstract-page';
import logger from '../utils/logger';
import { DEFAULT_TIMEOUT } from '../utils/timeout';

export class LoginPage extends BasePage {
  private readonly employeeIdTxt: Locator;
  private readonly passcodeTxt: Locator;
  private readonly loginBtn: Locator;

  constructor(page: Page) {
    super(page, loginPageLocators);
    this.employeeIdTxt = this.page.locator(loginPageLocators.employeeIdTxt);
    this.passcodeTxt = this.page.locator(loginPageLocators.passcodeTxt);
    this.loginBtn = this.page.locator(loginPageLocators.loginBtn);
    logger.info('LoginPage initialized');
  }

  async fillEmployeeId(employeeId: string): Promise<void> {
    await fillElementTxtLocator(this.employeeIdTxt, employeeId);
    logger.info('Employee ID filled');
  }

  async fillPasscode(passcode: string): Promise<void> {
    await fillElementTxtLocator(this.passcodeTxt, passcode);
    logger.info('Passcode filled');
  }

  async clickLogin(): Promise<void> {
    await clickElementHasBtnLnkLocator(this.loginBtn);
    logger.info('Login submitted');
  }

  async waitForLoginForm(): Promise<void> {
    await this.employeeIdTxt.waitFor({ state: 'visible', timeout: 30000 });
    logger.info('Login form is visible');
  }

  async verifyEmployeeIdInputVisible(): Promise<void> {
    await assertElementState(this.employeeIdTxt, 'visible', DEFAULT_TIMEOUT);
  }

  async navigateToApp(url: string): Promise<void> {
    await this.page.goto(url, { waitUntil: 'domcontentloaded' });
    logger.info('Navigated to application');
  }

  async login(employeeId: string, passcode: string): Promise<void> {
    await fillElementTxtLocator(this.employeeIdTxt, employeeId);
    await fillElementTxtLocator(this.passcodeTxt, passcode);
    await this.clickLogin();
    logger.info('Login flow completed');
  }
}