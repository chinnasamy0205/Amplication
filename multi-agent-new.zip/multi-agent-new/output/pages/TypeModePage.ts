import { Page } from '@playwright/test';
import { BasePage } from '../core/base-page';
import { typeModeLocators } from '../locators/type-mode.locators';
import logger from '../utils/logger';

export class TypeModePage extends BasePage {
  constructor(page: Page) {
    super(page, typeModeLocators);
    logger.info('TypeModePage initialized');
  }
}