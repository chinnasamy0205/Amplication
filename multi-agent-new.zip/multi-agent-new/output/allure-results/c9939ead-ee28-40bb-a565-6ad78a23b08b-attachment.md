# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: web\goodfood-scenario-2.spec.ts >> Invalid UPC - Theft Inventory Adjustment >> Rejects an unknown UPC and keeps Submit disabled
- Location: tests\web\goodfood-scenario-2.spec.ts:10:7

# Error details

```
Error: locator.fill: value: expected string, got undefined
```

# Page snapshot

```yaml
- generic "Store IQ" [active] [ref=e1]:
  - region "Notifications alt+T"
  - alert [ref=e2]
  - generic [ref=e5]:
    - generic [ref=e10]: STOREIQ
    - generic [ref=e12]:
      - textbox "Employee Id" [ref=e14]
      - textbox "Passcode" [ref=e16]
      - generic [ref=e17]:
        - button "Log in" [ref=e18] [cursor=pointer]
        - generic [ref=e19]:
          - button "Forgot / Reset Passcode?" [ref=e20] [cursor=pointer]
          - img [ref=e21] [cursor=pointer]
```

# Test source

```ts
  1  | import { Page } from '@playwright/test';
  2  | import { BasePage } from '../core/base-page';
  3  | 
  4  | export class LoginPage extends BasePage {
  5  |   constructor(page: Page) {
  6  |     super(page, 'login-page.locators.json');
  7  |   }
  8  | 
  9  |   async fillEmployeeId(employeeId: string): Promise<void> {
  10 |     await this.page.locator(this.loc.get('employeeIdInput')).fill(employeeId);
  11 |   }
  12 | 
  13 |   async fillPasscode(passcode: string): Promise<void> {
  14 |     await this.page.locator(this.loc.get('passcodeInput')).fill(passcode);
  15 |   }
  16 | 
  17 |   async clickLogin(): Promise<void> {
  18 |     await this.page.locator(this.loc.get('loginButton')).click();
  19 |   }
  20 | 
  21 |   async waitForLoginForm(): Promise<void> {
  22 |     await this.page.locator(this.loc.get('employeeIdInput')).waitFor({ state: 'visible', timeout: 30000 });
  23 |   }
  24 | 
  25 |   async login(employeeId: string, passcode: string): Promise<void> {
> 26 |     await this.page.locator(this.loc.get('employeeIdInput')).fill(employeeId);
     |                                                              ^ Error: locator.fill: value: expected string, got undefined
  27 |     await this.page.locator(this.loc.get('passcodeInput')).fill(passcode);
  28 |     await this.clickLogin();
  29 |   }
  30 | }
```