# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: web\tc_inv_spoilage_001.spec.ts >> Verify Default UI of Inventory Spoilage Screen >> Verify default UI elements displayed on Inventory Spoilage screen
- Location: tests\web\tc_inv_spoilage_001.spec.ts:10:7

# Error details

```
Error: expect(locator).toBeChecked() failed

Locator:  locator('#r1')
Expected: checked
Received: unchecked
Timeout:  30000ms

Call log:
  - Expect "toBeChecked" with timeout 30000ms
  - waiting for locator('#r1')
    62 × locator resolved to <button id="r1" role="radio" type="button" tabindex="-1" aria-checked="false" data-state="unchecked" value="removeInventory" data-slot="radio-group-item" data-radix-collection-item="" class="border-slate-200 text-slate-900 focus-visible:border-slate-950 focus-visible:ring-slate-950/50 aria-invalid:ring-red-500/20 aria-invalid:border-red-500 dark:bg-slate-200/30 aspect-square size-4 shrink-0 rounded-full border shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:curso…></button>
       - unexpected value "unchecked"

```

```yaml
- radio "Shrink"
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | import { LoginPage } from '../../pages/LoginPage';
  3   | import { StoreSelectionPage } from '../../pages/StoreSelectionPage';
  4   | import { StoreHomePage } from '../../pages/StoreHomePage';
  5   | import { AdjustInventoryPage } from '../../pages/AdjustInventoryPage';
  6   | import { SpoilagePage } from '../../pages/SpoilagePage';
  7   | import testData from '../../test-data/web/tc_inv_spoilage_001.json';
  8   | 
  9   | test.describe('Verify Default UI of Inventory Spoilage Screen', () => {
  10  |   test('Verify default UI elements displayed on Inventory Spoilage screen', { tag: ['@web', '@P1', '@UI-validation', '@inventory-spoilage'] }, async ({ page }) => {
  11  |     test.skip(!process.env.GOODFOOD_EMPLOYEE_ID || !process.env.GOODFOOD_PASSCODE, 'USER FIX REQUIRED: EMPLOYEE_ID and PASSCODE must be set in output/.env; see executor report');
  12  |     const loginPage = new LoginPage(page);
  13  |     const storeSelectionPage = new StoreSelectionPage(page);
  14  |     const storeHomePage = new StoreHomePage(page);
  15  |     const adjustInventoryPage = new AdjustInventoryPage(page);
  16  |     const spoilagePage = new SpoilagePage(page);
  17  | 
  18  |     await test.step('Step 1 — Navigate to {{ENV.BASE_URL}}', async () => {
  19  |       console.log(`[${new Date().toISOString()}] Step 1 — Navigate to {{ENV.BASE_URL}}`);
  20  |       await loginPage.navigateToApp(process.env.BASE_URL!);
  21  |     });
  22  | 
  23  |     await test.step('Step 2 — Log in using Employee ID {{ENV.GOODFOOD_EMPLOYEE_ID}} and Passcode {{ENV.GOODFOOD_    PASSCODE}}', async () => {
  24  |       console.log(`[${new Date().toISOString()}] Step 2 — Log in using Employee ID and Passcode`);
  25  |       await loginPage.fillEmployeeId(process.env.GOODFOOD_EMPLOYEE_ID!);
  26  |       await loginPage.fillPasscode(process.env.GOODFOOD_PASSCODE!);
  27  |       await loginPage.clickLogin();
  28  |       await storeSelectionPage.waitForStoreSelection();
  29  |     });
  30  | 
  31  |     await test.step(`Step 3 — Select the ${testData.department} department`, async () => {
  32  |       console.log(`[${new Date().toISOString()}] Step 3 — Select the ${testData.department} department`);
  33  |       await storeSelectionPage.selectLongBeachStore();
  34  |     });
  35  | 
  36  |     await test.step('Step 4 — VERIFY: The department is selected and the dashboard/home screen is displayed', async () => {
  37  |       console.log(`[${new Date().toISOString()}] Step 4 — VERIFY: The department is selected and the dashboard/home screen is displayed`);
  38  |       await expect(storeHomePage.getLocator('activeStoreDisplay')).toBeVisible({ timeout: 30000 });
  39  |     });
  40  | 
  41  |     await test.step('Step 5 — Navigate to the Adjust Inventory menu', async () => {
  42  |       console.log(`[${new Date().toISOString()}] Step 5 — Navigate to the Adjust Inventory menu`);
  43  |       await storeHomePage.openInventoryAdjustment();
  44  |     });
  45  | 
  46  |     await test.step('Step 6 — VERIFY: Adjust Inventory options are displayed', async () => {
  47  |       console.log(`[${new Date().toISOString()}] Step 6 — VERIFY: Adjust Inventory options are displayed`);
  48  |       await expect(adjustInventoryPage.getLocator('theftButton')).toBeVisible({ timeout: 30000 });
  49  |     });
  50  | 
  51  |     await test.step('Step 7 — Select the Spoilage option', async () => {
  52  |       console.log(`[${new Date().toISOString()}] Step 7 — Select the Spoilage option`);
  53  |       await adjustInventoryPage.clickSpoilage();
  54  |     });
  55  | 
  56  |     await test.step('Step 8 — VERIFY: The Spoilage screen is opened', async () => {
  57  |       console.log(`[${new Date().toISOString()}] Step 8 — VERIFY: The Spoilage screen is opened`);
  58  |       await expect(spoilagePage.getLocator('spoilageScreenTitle')).toBeVisible({ timeout: 30000 });
  59  |     });
  60  | 
  61  |     await test.step('Step 9 — VERIFY: The title bar displays a Back Arrow button on the left, "Spoilage" text in the center, and a Help (Question Mark) icon on the right', async () => {
  62  |       console.log(`[${new Date().toISOString()}] Step 9 — VERIFY: The title bar displays a Back Arrow button, Spoilage text, and Help icon`);
  63  |       await expect(spoilagePage.getLocator('backArrowIcon')).toBeVisible({ timeout: 30000 });
  64  |       await expect(spoilagePage.getLocator('spoilageScreenTitle')).toBeVisible({ timeout: 30000 });
  65  |       await expect(spoilagePage.getLocator('helpIcon')).toBeVisible({ timeout: 30000 });
  66  |     });
  67  | 
  68  |     await test.step('Step 10 — VERIFY: The UPC text field is displayed with Scan and Type toggle options', async () => {
  69  |       console.log(`[${new Date().toISOString()}] Step 10 — VERIFY: The UPC text field is displayed with Scan and Type toggle options`);
  70  |       await expect(spoilagePage.getLocator('spoilageUpcInput')).toBeVisible({ timeout: 30000 });
  71  |       await expect(spoilagePage.getLocator('manualModeSwitch')).toBeVisible({ timeout: 30000 });
  72  |     });
  73  | 
  74  |     await test.step('Step 11 — VERIFY: Scan is selected by default', async () => {
  75  |       console.log(`[${new Date().toISOString()}] Step 11 — VERIFY: Scan is selected by default`);
  76  |       await expect(spoilagePage.getLocator('manualModeSwitch')).not.toBeChecked({ timeout: 30000 });
  77  |     });
  78  | 
  79  |     await test.step('Step 12 — VERIFY: The UPC field placeholder text is "Scan upc"', async () => {
  80  |       console.log(`[${new Date().toISOString()}] Step 12 — VERIFY: The UPC field placeholder text is "Scan upc"`);
  81  |       await expect(spoilagePage.getLocator('spoilageUpcInput')).toHaveAttribute('placeholder', 'Scan upc', { timeout: 30000 });
  82  |     });
  83  | 
  84  |     await test.step('Step 13 — VERIFY: Shrink and Correction radio buttons are displayed, if i Correction choose Minus (-) controls', async () => {
  85  |       console.log(`[${new Date().toISOString()}] Step 13 — VERIFY: Shrink and Correction radio buttons are displayed, if i Correction choose Minus (-) controls`);
  86  |       await expect(spoilagePage.getLocator('shrinkRadio')).toBeVisible({ timeout: 30000 });
  87  |       await expect(spoilagePage.getLocator('correctionRadio')).toBeVisible({ timeout: 30000 });
  88  |       await spoilagePage.click('correctionRadio');
  89  |       await expect(spoilagePage.getLocator('quantityMinusLabel')).toBeVisible({ timeout: 30000 });
  90  |     });
  91  | 
  92  |     await test.step('Step 14 — VERIFY: Shrink is selected by default', async () => {
  93  |       console.log(`[${new Date().toISOString()}] Step 14 — VERIFY: Shrink is selected by default`);
> 94  |       await expect(spoilagePage.getLocator('shrinkRadio')).toBeChecked({ timeout: 30000 });
      |                                                            ^ Error: expect(locator).toBeChecked() failed
  95  |     });
  96  | 
  97  |     await test.step('Step 15 — VERIFY: The quantity text box is displayed', async () => {
  98  |       console.log(`[${new Date().toISOString()}] Step 15 — VERIFY: The quantity text box is displayed`);
  99  |       await expect(spoilagePage.getLocator('quantityInput')).toBeVisible({ timeout: 30000 });
  100 |     });
  101 | 
  102 |     await test.step('Step 16 — VERIFY: Minus (-) controls are displayed along with the quantity field', async () => {
  103 |       console.log(`[${new Date().toISOString()}] Step 16 — VERIFY: Minus (-) controls are displayed along with the quantity field`);
  104 |       await expect(spoilagePage.getLocator('quantityMinusLabel')).toBeVisible({ timeout: 30000 });
  105 |     });
  106 | 
  107 |     await test.step('Step 17 — VERIFY: The Submit button is displayed with a Tailwind teal-500 background and remains disabled by default', async () => {
  108 |       console.log(`[${new Date().toISOString()}] Step 17 — VERIFY: The Submit button is displayed with a Tailwind teal-500 background and remains disabled by default`);
  109 |       await expect(spoilagePage.getLocator('submitButton')).toBeVisible({ timeout: 30000 });
  110 |       await expect(spoilagePage.getLocator('submitButton')).toHaveClass(/bg-teal-500/, { timeout: 30000 });
  111 |       await expect(spoilagePage.getLocator('submitButton')).toBeDisabled({ timeout: 30000 });
  112 |     });
  113 | 
  114 |     await test.step('Step 18 — VERIFY: All specified UI elements are displayed and default selections and states match the requirements', async () => {
  115 |       console.log(`[${new Date().toISOString()}] Step 18 — VERIFY: All specified UI elements are displayed and default selections and states match the requirements`);
  116 |       await expect(spoilagePage.getLocator('backArrowIcon')).toBeVisible({ timeout: 30000 });
  117 |       await expect(spoilagePage.getLocator('spoilageScreenTitle')).toBeVisible({ timeout: 30000 });
  118 |       await expect(spoilagePage.getLocator('helpIcon')).toBeVisible({ timeout: 30000 });
  119 |       await expect(spoilagePage.getLocator('spoilageUpcInput')).toHaveAttribute('placeholder', 'Scan upc', { timeout: 30000 });
  120 |       await expect(spoilagePage.getLocator('manualModeSwitch')).not.toBeChecked({ timeout: 30000 });
  121 |       await expect(spoilagePage.getLocator('shrinkRadio')).toBeChecked({ timeout: 30000 });
  122 |       await expect(spoilagePage.getLocator('correctionRadio')).toBeVisible({ timeout: 30000 });
  123 |       await expect(spoilagePage.getLocator('quantityInput')).toBeVisible({ timeout: 30000 });
  124 |       await expect(spoilagePage.getLocator('quantityMinusLabel')).toBeVisible({ timeout: 30000 });
  125 |       await expect(spoilagePage.getLocator('submitButton')).toBeVisible({ timeout: 30000 });
  126 |       await expect(spoilagePage.getLocator('submitButton')).toHaveClass(/bg-teal-500/, { timeout: 30000 });
  127 |       await expect(spoilagePage.getLocator('submitButton')).toBeDisabled({ timeout: 30000 });
  128 |     });
  129 | 
  130 |     await test.step('Step 19 — VERIFY: No UI component is missing or incorrectly displayed or labeled, and no default selection or state differs from the expected behavior', async () => {
  131 |       console.log(`[${new Date().toISOString()}] Step 19 — VERIFY: No UI component is missing or incorrectly displayed or labeled, and no default selection or state differs from the expected behavior`);
  132 |       await expect(spoilagePage.getLocator('shrinkRadio')).toHaveAccessibleName('Shrink', { timeout: 30000 });
  133 |       await expect(spoilagePage.getLocator('correctionRadio')).toHaveAccessibleName('Correction', { timeout: 30000 });
  134 |       await expect(spoilagePage.getLocator('spoilageUpcInput')).toHaveAttribute('placeholder', 'Scan upc', { timeout: 30000 });
  135 |       await expect(spoilagePage.getLocator('manualModeSwitch')).not.toBeChecked({ timeout: 30000 });
  136 |       await expect(spoilagePage.getLocator('shrinkRadio')).toBeChecked({ timeout: 30000 });
  137 |       await expect(spoilagePage.getLocator('submitButton')).toBeDisabled({ timeout: 30000 });
  138 |     });
  139 |   });
  140 | });
```