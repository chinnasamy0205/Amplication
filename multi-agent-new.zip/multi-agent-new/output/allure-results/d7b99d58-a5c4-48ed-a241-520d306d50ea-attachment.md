# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: web\goodfood-scenario-1.spec.ts >> Create Inventory Adjustment - Theft - Manual Type Mode >> Create Theft inventory adjustment in Type Mode
- Location: tests\web\goodfood-scenario-1.spec.ts:7:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Theft')
Expected: visible
Error: strict mode violation: getByText('Theft') resolved to 3 elements:
    1) <span class="text-center grow-1">Theft</span> aka getByText('Theft').first()
    2) <span class="pl-5 text-left">Theft</span> aka getByText('Theft').nth(1)
    3) <span class="pl-5 text-left">Theft</span> aka getByText('Theft').nth(2)

Call log:
  - Expect "toBeVisible" with timeout 30000ms
  - waiting for getByText('Theft')

```

# Page snapshot

```yaml
- generic "Store IQ":
  - region "Notifications alt+T"
  - alert
  - menubar:
    - link:
      - /url: /
    - generic:
      - generic:
        - generic: STOREIQ
    - menuitem:
      - img
  - generic:
    - generic:
      - generic:
        - generic: Long Beach
        - generic: 02 - Grocery
      - generic:
        - generic:
          - img
        - generic: Theft
        - generic:
          - img
        - generic:
          - img
      - generic:
        - generic:
          - generic:
            - generic:
              - textbox:
                - /placeholder: Enter upc
              - generic:
                - generic: Scan
                - switch [checked]
                - generic: Type
            - generic:
              - radiogroup:
                - generic:
                  - generic:
                    - radio [checked]:
                      - img
                    - generic: Shrink
                  - generic:
                    - radio
                    - generic: Correction
              - button:
                - text: 10/22/2026
                - img
            - generic:
              - generic: (-)
              - textbox:
                - /placeholder: "0"
              - button [disabled]: Submit
        - generic:
          - generic:
            - generic: "000004900002891"
            - generic: COKE DIET FR 12 PK
          - generic:
            - generic: Recent Adjustments
            - generic:
              - generic:
                - button: Date
                - button: Reason
                - button: Qty
              - generic:
                - generic: Oct 22, 23:11:49
                - generic: Theft
                - generic: "-5"
              - generic:
                - generic: Oct 22, 22:27:17
                - generic: Theft
                - generic: "-5"
  - dialog "0" [ref=e2]:
    - generic [ref=e3]:
      - heading "0" [level=2] [ref=e4]:
        - generic [ref=e5]: "0"
      - paragraph [ref=e7]: Inventory adjustment added successfully
    - button "OK" [active] [ref=e9] [cursor=pointer]:
      - generic [ref=e10]: OK
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { LoginPage } from '../../pages/LoginPage';
  3  | import { StoreSelectionPage } from '../../pages/StoreSelectionPage';
  4  | import { InventoryAdjustmentPage } from '../../pages/InventoryAdjustmentPage';
  5  | 
  6  | test.describe('Create Inventory Adjustment - Theft - Manual Type Mode', () => {
  7  |   test('Create Theft inventory adjustment in Type Mode', { tag: ['@P1', '@inventory-adjustment'] }, async ({ page }) => {
  8  |     const loginPage = new LoginPage(page);
  9  |     const storeSelectionPage = new StoreSelectionPage(page);
  10 |     const inventoryAdjustmentPage = new InventoryAdjustmentPage(page);
  11 | 
  12 |     await test.step('Step 1 — Navigate to https://test.storeiq.goodfoodholdings.com/', async () => {
  13 |       console.log(`[${new Date().toISOString()}] Step 1 — Navigate to https://test.storeiq.goodfoodholdings.com/`);
  14 |       await page.goto(process.env.BASE_URL!, { waitUntil: 'domcontentloaded' });
  15 |     });
  16 | 
  17 |     await test.step('Step 2 — VERIFY the login page is displayed', async () => {
  18 |       console.log(`[${new Date().toISOString()}] Step 2 — VERIFY the login page is displayed`);
  19 |       await expect(loginPage.getLocator('employeeIdInput')).toBeVisible({ timeout: 30000 });
  20 |     });
  21 | 
  22 |     await test.step('Step 3 — Log in with Employee ID and passcode', async () => {
  23 |       console.log(`[${new Date().toISOString()}] Step 3 — Log in with Employee ID and passcode`);
  24 |       await loginPage.fillEmployeeId(process.env.GOODFOOD_EMPLOYEE_ID!);
  25 |       await loginPage.fillPasscode(process.env.GOODFOOD_PASSCODE!);
  26 |       await loginPage.clickLogin();
  27 |       await storeSelectionPage.getLocator('storeDropdown').waitFor({ state: 'visible', timeout: 30000 });
  28 |     });
  29 | 
  30 |     await test.step('Step 4 — Click Choose the Store dropdown list', async () => {
  31 |       console.log(`[${new Date().toISOString()}] Step 4 — Click Choose the Store dropdown list`);
  32 |       await storeSelectionPage.openStoreDropdown();
  33 |     });
  34 | 
  35 |     await test.step('Step 5 — Select the Department `000006 - Long Beach`', async () => {
  36 |       console.log(`[${new Date().toISOString()}] Step 5 — Select the Department 000006 - Long Beach`);
  37 |       await storeSelectionPage.selectLongBeachStore();
  38 |     });
  39 | 
  40 |     await test.step('Step 6 — Click the "Adjust Inventory" option', async () => {
  41 |       console.log(`[${new Date().toISOString()}] Step 6 — Click the "Adjust Inventory" option`);
  42 |       await storeSelectionPage.openInventoryAdjustment();
  43 |     });
  44 | 
  45 |     await test.step('Step 7 — Select "Theft"', async () => {
  46 |       console.log(`[${new Date().toISOString()}] Step 7 — Select "Theft"`);
  47 |       await inventoryAdjustmentPage.selectTheftReason();
  48 |     });
  49 | 
  50 |     await test.step('Step 8 — Switch to "Type Mode"', async () => {
  51 |       console.log(`[${new Date().toISOString()}] Step 8 — Switch to "Type Mode"`);
  52 |       await inventoryAdjustmentPage.switchToTypeMode();
  53 |     });
  54 | 
  55 |     await test.step('Step 9 — Enter a valid UPC', async () => {
  56 |       console.log(`[${new Date().toISOString()}] Step 9 — Enter a valid UPC`);
  57 |       await inventoryAdjustmentPage.fillUpc(process.env.GOODFOOD_UPC!);
  58 |     });
  59 | 
  60 |     await test.step('Step 10 — Press Enter or click Search', async () => {
  61 |       console.log(`[${new Date().toISOString()}] Step 10 — Press Enter or click Search`);
  62 |       await inventoryAdjustmentPage.submitUpcLookup();
  63 |     });
  64 | 
  65 |     await test.step('Step 11 — VERIFY the item details are displayed (item loaded correctly)', async () => {
  66 |       console.log(`[${new Date().toISOString()}] Step 11 — VERIFY the item details are displayed (item loaded correctly)`);
  67 |       await expect(inventoryAdjustmentPage.getLocator('itemDetails')).toBeVisible({ timeout: 30000 });
  68 |     });
  69 | 
  70 |     await test.step('Step 12 — Enter quantity `5`', async () => {
  71 |       console.log(`[${new Date().toISOString()}] Step 12 — Enter quantity 5`);
  72 |       await inventoryAdjustmentPage.fillQuantity('5');
  73 |     });
  74 | 
  75 |     await test.step('Step 13 — VERIFY the quantity is accepted', async () => {
  76 |       console.log(`[${new Date().toISOString()}] Step 13 — VERIFY the quantity is accepted`);
  77 |       await expect(inventoryAdjustmentPage.getLocator('quantityInput')).toHaveValue('5', { timeout: 30000 });
  78 |       await expect(inventoryAdjustmentPage.getLocator('submitAdjustmentButton')).toBeEnabled({ timeout: 30000 });
  79 |     });
  80 | 
  81 |     await test.step('Step 14 — Click the Submit button', async () => {
  82 |       console.log(`[${new Date().toISOString()}] Step 14 — Click the Submit button`);
  83 |       await inventoryAdjustmentPage.submitAdjustment();
  84 |     });
  85 | 
  86 |     await test.step('Step 15 — VERIFY the success modal/message is displayed', async () => {
  87 |       console.log(`[${new Date().toISOString()}] Step 15 — VERIFY the success modal/message is displayed`);
  88 |       await expect(inventoryAdjustmentPage.getLocator('adjustmentSuccessMessage')).toBeVisible({ timeout: 30000 });
  89 |     });
  90 | 
  91 |     await test.step('Step 16 — VERIFY the transaction is created in the database and the record is saved in the Inventory Adjustment table', async () => {
  92 |       console.log(`[${new Date().toISOString()}] Step 16 — VERIFY the transaction is created in the database and the record is saved in the Inventory Adjustment table`);
> 93 |       await expect(inventoryAdjustmentPage.getLocator('recentAdjustmentsRecord')).toBeVisible({ timeout: 30000 });
     |                                                                                   ^ Error: expect(locator).toBeVisible() failed
  94 |       test.fixme(true, 'BLOCKED: Recent Adjustments is visible, but this browser scenario has no independent database verification path.');
  95 |     });
  96 |   });
  97 | });
```