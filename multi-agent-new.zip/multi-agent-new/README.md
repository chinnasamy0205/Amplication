# Agentic AI Quality Engineering Automation Framework

> **Enterprise multi-agent Quality Engineering framework for converting requirements into traceable, executable, reviewed, and governed Playwright automation.**

This repository demonstrates an **Agentic AI–driven Quality Engineering (QE) framework** that combines specialized AI agents, deterministic automation utilities, Playwright browser execution, reusable QE knowledge, quality gates, self-healing, reporting, and observability.

Instead of using a single AI prompt to generate test code, the framework separates the software-testing lifecycle into specialist responsibilities and coordinates them through a governed pipeline:

```text
Requirement / Natural Language / Gherkin / OpenAPI
                      │
                      ▼
               Scenario Enrichment
                      │
                      ▼
          Live Application Exploration
                      │
                      ▼
             Automation Generation
                      │
                      ▼
                 Execution
                      │
                      ▼
           Independent QE Review
                      │
             ┌────────┴────────┐
             │                 │
          APPROVED         NEEDS FIXES
                               │
                               ▼
                         Controlled Healing
                               │
                               ▼
                            Re-review
                               │
                               ▼
                      Final Pipeline Verdict
```

The result is a framework designed to make AI-assisted automation more **traceable, deterministic, reviewable, maintainable, and enterprise-ready**.

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Why This Framework Exists](#why-this-framework-exists)
3. [Key Capabilities](#key-capabilities)
4. [Architecture](#architecture)
5. [End-to-End Pipeline](#end-to-end-pipeline)
6. [Agent Catalog](#agent-catalog)
7. [Reusable Skill Library](#reusable-skill-library)
8. [Supported Inputs](#supported-inputs)
9. [BDD and Requirements-to-Automation Flow](#bdd-and-requirements-to-automation-flow)
10. [Quality Gates and Review Model](#quality-gates-and-review-model)
11. [Controlled Self-Healing](#controlled-self-healing)
12. [Project Structure](#project-structure)
13. [Prerequisites](#prerequisites)
14. [Quick Start](#quick-start)
15. [Visual Studio Code + GitHub Copilot Agent Mode](#visual-studio-code--github-copilot-agent-mode)
16. [Framework Configuration](#framework-configuration)
17. [Environment Configuration](#environment-configuration)
18. [Creating Scenarios](#creating-scenarios)
19. [Running the Agentic Pipeline](#running-the-agentic-pipeline)
20. [Generated Artifacts](#generated-artifacts)
21. [Locator Architecture](#locator-architecture)
22. [Incremental Automation](#incremental-automation)
23. [Reporting and Observability](#reporting-and-observability)
24. [MCP Integrations](#mcp-integrations)
25. [IDE Support](#ide-support)
26. [Security and Governance](#security-and-governance)
27. [CI/CD Guidance](#cicd-guidance)
28. [Demo Applications Observed in This Repository](#demo-applications-observed-in-this-repository)
29. [Troubleshooting](#troubleshooting)
30. [Repository Packaging Guidance](#repository-packaging-guidance)
31. [Current Scope and Limitations](#current-scope-and-limitations)
32. [Recommended Enterprise Adoption Model](#recommended-enterprise-adoption-model)
33. [Glossary](#glossary)
34. [FAQ](#faq)

---

# Executive Summary

Traditional automation frameworks require engineers to manually translate requirements into scenarios, inspect the target application, discover selectors, build Page Objects, implement tests, execute them, diagnose failures, maintain selectors, review quality, and produce reports.

This framework distributes those responsibilities across **specialized AI agents** while keeping execution and validation controlled by deterministic tooling and explicit quality gates.

The architecture follows a simple principle:

> **AI reasons and proposes. Deterministic tools execute. Independent agents review. Quality gates decide whether the pipeline can progress.**

The framework currently contains:

- **9 specialized AI agents**
- **37 reusable QE skills / knowledge modules**
- Playwright-based browser automation
- Natural-language, Gherkin, requirement-tracker, and OpenAPI inputs
- Externalized locators
- Page Object generation
- Data-driven testing support
- Incremental automation updates
- Bounded execution repair cycles
- Selector healing
- Independent enterprise QE review
- Scenario-to-code traceability
- Allure-compatible execution evidence
- Token, context-window, and duration observability
- Jira, Azure DevOps, and Figma integration through MCP
- Cross-platform support for Windows, Linux, and macOS

All current agent definitions in this repository are configured to use **Claude Sonnet 4.6**.

---

# Why This Framework Exists

AI can generate automation code quickly, but enterprise QE requires much more than code generation.

A production-quality solution must answer questions such as:

- Did the generated automation preserve the original requirement?
- Were selectors discovered from the actual running application?
- Are waits stable and deterministic?
- Is test data externalized correctly?
- Are secrets protected?
- Did the generated test actually execute successfully?
- Did AI silently change an expected assertion?
- Can a reviewer independently verify what happened?
- Can failures be repaired without changing business intent?
- Can every generated artifact be traced back to the original scenario?
- Can AI usage, duration, and pipeline behavior be observed?

This framework addresses those concerns by separating responsibilities and enforcing deterministic handoffs between agents.

---

# Key Capabilities

| Capability | Description |
|---|---|
| **Agentic orchestration** | Specialist agents collaborate through a governed pipeline rather than one monolithic prompt. |
| **Requirement-to-test automation** | Converts natural language, approved Gherkin, specifications, tracker requirements, and OpenAPI documents into automation assets. |
| **Live application grounding** | Explorer Agent interacts with the running application to validate steps and discover real UI elements. |
| **Playwright automation** | Generates and executes Playwright-based automation using a reusable core architecture. |
| **Externalized locators** | Selectors are stored outside test code in structured JSON locator repositories. |
| **Page Object generation** | Builder Agent creates reusable Page Objects from discovered application structure. |
| **Incremental updates** | Existing automation can be preserved and updated when scenarios change. |
| **Bounded repair** | Execution repair is controlled by a configurable cycle budget. |
| **Selector healing** | Failed or stale selectors can be repaired using deterministic evidence and browser probing. |
| **Independent review** | Reviewer Agent audits generated automation across 9 enterprise QE dimensions. |
| **Fidelity gate** | Scenario-to-code fidelity is treated as a non-negotiable hard gate. |
| **Controlled healing** | Healer Agent fixes only reviewer-identified issues and must preserve business intent. |
| **BDD support** | Converts specifications or Jira/ADO requirements into reviewable Gherkin feature files. |
| **OpenAPI support** | Converts Swagger/OpenAPI definitions into structured API scenarios. |
| **Traceability** | Acceptance criteria, scenarios, generated artifacts, execution evidence, and review outputs can be linked. |
| **Observability** | Tracks token usage, context-window consumption, execution duration, and stage-level metrics. |
| **Reporting** | Produces stage reports, metrics JSON, pipeline summaries, screenshots, traces, logs, and Allure results. |
| **MCP integration** | Supports Jira, Azure DevOps, and Figma as external requirement/design sources. |
| **Cross-platform execution** | Designed for Windows, Linux, and macOS. |

---

# Architecture

## High-Level Architecture

```mermaid
flowchart LR
    A[Requirements] --> B[BDD Scenario Author]
    A2[Natural Language] --> C[Enrichment Agent]
    A3[OpenAPI / Swagger] --> C
    B --> D[Approved Gherkin]
    D --> C

    C --> E[Structured Scenario]
    E --> F[Pipeline Orchestrator]

    F --> G[Explorer Agent]
    G --> H[Live Application]
    G --> I[Enriched Scenario + Selector Evidence]

    I --> J[Builder Agent]
    J --> K[Locators]
    J --> L[Page Objects]
    J --> M[Test Data]
    J --> N[Playwright Specs]

    N --> O[Executor Agent]
    O --> P[Playwright CLI]
    P --> H
    O --> Q[Execution Evidence]

    Q --> R[Reviewer Agent]
    R --> S{Quality Gate}
    S -->|Approved| T[Pipeline Summary]
    S -->|Needs Fixes| U[Healer Agent]
    U --> O
    O --> R

    T --> V[Reports / Metrics / Allure]
```

## Design Principles

### 1. Separation of responsibilities

Each agent has a narrow role. The Pipeline Orchestrator coordinates the workflow but is explicitly prohibited from doing specialist work itself.

### 2. Deterministic gates

A stage cannot simply claim success. Expected files and evidence must exist before the pipeline progresses.

### 3. Requirement fidelity

Generated automation must preserve original business behavior. Test code that executes successfully but changes the scenario is not considered correct.

### 4. Human-reviewable artifacts

BDD feature files, structured scenarios, locators, tests, reports, and scorecards remain inspectable by QE engineers.

### 5. Bounded autonomy

Agents may explore, generate, execute, diagnose, and heal within explicit limits. They are not given unrestricted authority to change business expectations.

---

# End-to-End Pipeline

The primary orchestration flow is:

```text
Stage 0     Enrichment
Stage 1a    Explorer
Stage 1b    Builder
Stage 2     Executor
Stage 3     Reviewer
Stage 4     Healer — conditional
Stage 3b    Re-review — conditional
Final       Pipeline Summary + Metrics
```

## Stage 0 — Enrichment

The Enrichment Agent converts supported input into a structured scenario contract.

Supported input modes include:

- Natural-language scenarios
- Existing structured scenario Markdown
- Approved Gherkin `.feature` files
- Swagger/OpenAPI specifications

The Enrichment Agent is governed by a **faithful translation** rule: it must not invent conditional logic, validations, or behavior that the source did not state.

## Stage 1a — Explorer

The Explorer Agent validates the scenario against the **running application**.

Its responsibilities include:

- Navigating the live application
- Performing scenario steps
- Discovering actual elements
- Capturing selector evidence
- Verifying that the described flow exists
- Producing enriched application-grounded information
- Flagging potential application defects or uncertain behavior

For browser interaction, the framework uses **Playwright CLI**, not Playwright MCP.

## Stage 1b — Builder

The Builder Agent converts grounded scenario information into automation assets such as:

- Locator JSON files
- Page Objects
- Test-data JSON
- Playwright test specifications

The Builder supports incremental updates and is configured to preserve healed code and pacing comments.

## Stage 2 — Executor

The Executor Agent runs the generated tests and performs bounded remediation.

Current configuration:

```json
{
  "maxCycles": 3,
  "preFlightEnabled": true,
  "healProbeHeaded": false
}
```

A failed test cannot be reported as approved simply because the pipeline progressed.

## Stage 3 — Reviewer

The Reviewer Agent independently audits generated automation using the enterprise QE review rubric.

The Reviewer is a **read-only auditor** except for writing its scorecard.

## Stage 4 — Healer

The Healer runs only when the review verdict is **NEEDS FIXES**.

It receives explicit findings from the Reviewer and performs targeted remediation.

## Final Stage — Pipeline Summary

The Pipeline Orchestrator writes a final summary and orchestrator metrics containing:

- Stage boundaries
- Start/end timestamps
- Completed stages
- Skipped stages
- Failed stages
- Pipeline duration
- Final verdict

If a mandatory agent fails or expected evidence is missing, the correct pipeline outcome is **INCOMPLETE**, not fabricated success.

---

# Agent Catalog

The repository contains **9 specialist agents** under `.github/agents/`.

| Agent | Primary Responsibility | Key Output |
|---|---|---|
| **Pipeline Orchestrator** | Coordinates the complete QE pipeline and applies validation gates | Pipeline summary and orchestration metrics |
| **BDD Scenario Author** | Converts requirements into business-readable, automation-ready Gherkin | `.feature` files and AC coverage |
| **Enrichment Agent** | Converts NL, Gherkin, or OpenAPI into structured QE scenarios | Scenario `.md`, enrichment report, metrics |
| **Explorer Agent** | Validates the flow against the real application and captures element evidence | Enriched scenario, explorer report, selector evidence |
| **Builder Agent** | Generates locators, Page Objects, test data, and Playwright specs | Executable automation assets |
| **Executor Agent** | Runs automation and performs bounded execution repair | Test results and executor report |
| **Reviewer Agent** | Audits generated automation against enterprise QE standards | Review scorecard and verdict |
| **Healer Agent** | Repairs reviewer-identified issues while preserving intent | Corrected automation and healer report |
| **Setup Agent** | Bootstraps and validates framework runtime/configuration | Project structure and setup report |

## Agent Model

All recovered agent definitions currently declare:

```yaml
model: Claude Sonnet 4.6
```

The model declaration is part of the agent configuration and can be governed independently from deterministic runtime behavior.

---

# Reusable Skill Library

The framework contains **37 reusable QE skill/knowledge modules** under `.github/skills/`.

Instead of placing all behavior into oversized agent prompts, specialized knowledge is modularized into focused skills.

## API Skills

- `api-capture`
- `api-request`
- `api-validate-schema`

## QE Knowledge and Governance Skills

- `knowledge-INDEX`
- `knowledge-agent-reporting`
- `knowledge-app-context`
- `knowledge-bug-detection`
- `knowledge-enriched-md-contract`
- `knowledge-fix-discipline`
- `knowledge-guardrails`
- `knowledge-heal-discipline`
- `knowledge-path-resolution`
- `knowledge-pipeline-plan`
- `knowledge-quality-gates`
- `knowledge-review-dimensions`
- `knowledge-scenario-handling`
- `knowledge-type-registry`

## Web Automation Skills

- `web-codegen-locators`
- `web-codegen-pageobject`
- `web-codegen-spec`
- `web-dialog`
- `web-drag-drop`
- `web-element-capture`
- `web-extract`
- `web-failure-diagnosis`
- `web-file-transfer`
- `web-frame`
- `web-interact`
- `web-keyboard`
- `web-multi-tab`
- `web-navigate`
- `web-network`
- `web-pacing`
- `web-scroll`
- `web-selector-healing`
- `web-verify`
- `web-wait`

This modular design allows agents to load only the knowledge required for a specific task, reducing context pressure and improving maintainability.

---

# Supported Inputs

The framework can start from several enterprise testing inputs.

## 1. Natural Language

Example:

```text
Login as a valid user, add Backpack to the cart, open the cart,
verify the product name and price, and complete checkout.
```

The Enrichment Agent converts the description into the framework's structured scenario format.

## 2. Structured Scenario Markdown

A pre-authored framework scenario can bypass initial natural-language enrichment.

Typical location:

```text
scenarios/{type}/{optional-folder}/{scenario}.md
```

## 3. Gherkin / BDD

Approved `.feature` files can be converted by the Enrichment Agent into executable scenario contracts.

## 4. Jira or Azure DevOps

The BDD Scenario Author can use Jira or Azure DevOps as the requirement source when no local specification exists.

## 5. Local Specification

The preferred BDD requirement source is:

```text
docs/{ticket}/spec.md
```

Acceptance criteria and edge cases are treated as the testing source of truth.

## 6. Figma / Design Specification

Design validation can use:

```text
docs/{ticket}/design-spec.md
```

or a configured Figma MCP server.

## 7. Swagger / OpenAPI

The Enrichment Agent can generate API scenarios from OpenAPI definitions, including:

- CRUD happy paths
- Negative tests
- List/search/filter scenarios
- Edge cases
- Authentication setup where applicable

---

# BDD and Requirements-to-Automation Flow

The BDD path introduces a human-reviewable checkpoint before automation generation.

```mermaid
flowchart TD
    A[spec.md / Jira / Azure DevOps] --> B[BDD Scenario Author]
    C[design-spec.md / Figma] --> B
    B --> D[Gherkin .feature]
    D --> E[QE Lead Review / Approval]
    E --> F[Enrichment Agent]
    F --> G[Structured Scenario .md]
    G --> H[Explorer]
    H --> I[Builder]
    I --> J[Executor]
    J --> K[Reviewer]
```

## Requirement Source Precedence

For BDD generation, the framework prefers:

1. `docs/{ticket}/spec.md`
2. Jira or Azure DevOps work item

For design validation, it prefers:

1. `docs/{ticket}/design-spec.md`
2. Figma MCP
3. No design source

## Acceptance-Criteria Traceability

Each generated BDD scenario should carry an AC tag, for example:

```gherkin
@AC-001
Scenario: User successfully submits a valid application
```

Where `trace.json` exists, the BDD agent updates test coverage against acceptance criteria.

---

# Quality Gates and Review Model

Generating code is not sufficient for approval.

The Reviewer Agent evaluates automation across **9 enterprise QE dimensions**.

| # | Review Dimension | Weight / Importance |
|---:|---|---|
| 1 | Locator Quality | High |
| 2 | Wait Strategy | High |
| 3 | Test Architecture | Medium |
| 4 | Configuration | Medium |
| 5 | Code Quality | Low |
| 6 | Maintainability | Medium |
| 7 | Security | High |
| 8 | API Test Quality | Medium |
| 9 | **Scenario-to-Code Fidelity** | **High — most important / hard gate** |

The default configured minimum review score is:

```json
{
  "review": {
    "minScore": 80
  }
}
```

## Why Scenario-to-Code Fidelity Matters

An AI-generated test can technically pass while testing the wrong behavior.

Examples of unacceptable silent changes include:

- Replacing the required expected text with whatever the application currently displays
- Dropping a failed business validation
- Changing an expected status code to match an incorrect response
- Skipping a required scenario step
- Replacing a business assertion with a weaker technical assertion
- Changing the business flow merely to make the test pass

For this reason, **Dimension 9 is a hard gate**.

---

# Controlled Self-Healing

Self-healing is intentionally bounded.

The framework distinguishes between:

- Technical instability
- Selector drift
- Timing/sequencing problems
- Genuine application defects
- Requirement/application mismatches

## Executor Repair Budget

The configured execution-cycle limit is:

```json
"executor": {
  "maxCycles": 3
}
```

## Healer Discipline

The Healer Agent is expected to make **minimal, reviewer-driven corrections**.

It must not arbitrarily:

- Change expected business outcomes
- Rewrite the requirement
- Drop mandatory assertions
- Skip failed steps
- Hide defects
- Convert failures into passes by weakening validation
- Rewrite the entire automation when a targeted fix is sufficient

This makes the healing process a **governed remediation mechanism**, not unrestricted AI code mutation.

---

# Project Structure

The framework's intended structure is:

```text
qe-demo/
│
├── .github/
│   ├── agents/                         # 9 specialist agent definitions
│   └── skills/                         # 37 reusable QE skills / knowledge modules
│
├── docs/                               # Optional requirement/design artifacts
│   └── <ticket>/
│       ├── spec.md
│       ├── design-spec.md
│       └── trace.json
│
├── languages/                          # Language-specific profiles
│   ├── javascript.profile.json
│   ├── python.profile.json
│   └── typescript.profile.json
│
├── mcp/                                # External MCP configuration examples
│   ├── README.md
│   └── bdd-trackers.mcp.example.json
│
├── scenarios/
│   ├── web/
│   ├── api/
│   ├── hybrid/
│   ├── mobile/                         # Phase 2
│   └── app-contexts/                   # Learned per-application context
│
├── scripts/                            # Deterministic framework utilities
│
├── output/
│   ├── core/                           # Shared Playwright framework core
│   │   ├── base-page.ts
│   │   ├── locator-loader.ts
│   │   ├── shared-state.ts
│   │   └── test-data-loader.ts
│   │
│   ├── locators/                       # Externalized selector repositories
│   ├── pages/                          # Generated Page Objects
│   ├── test-data/                      # Scenario/shared/dataset test data
│   ├── tests/                          # Generated Playwright specs
│   ├── reports/                        # Agent + pipeline reports
│   │   └── metrics/                    # Per-agent and orchestration metrics
│   ├── test-results/                   # Parsed/raw execution results
│   ├── allure-results/                 # Allure execution evidence
│   ├── .playwright-cli/                # Browser snapshots/logs generated during execution
│   ├── .env                            # Local secrets — never commit
│   └── .env.example                    # Safe template
│
├── framework-config.json               # User-configurable framework behavior
├── package.json                        # npm scripts / project entry points
└── README.md
```

> `scripts/` is framework-managed deterministic runtime code. Agents should not arbitrarily rewrite those utilities.

---

# Prerequisites

Use a supported workstation with:

- **Node.js LTS**
- **npm**
- Git
- An AI-enabled development environment capable of using the repository's agent definitions
- Network access to the target application
- Required credentials for the application under test

Optional, depending on workflow:

- Jira MCP server
- Azure DevOps MCP server
- Figma MCP server
- Allure CLI/report tooling

The framework's browser runtime uses:

- `@playwright/cli`
- Chromium installed through Playwright

---

# Quick Start

## 1. Clone or unpack the repository

```bash
git clone <repository-url>
cd <repository-folder>
```

If working from an internal distribution package, extract it and open the project root in your supported IDE.

## 2. Verify framework setup

The Setup Agent validates or scaffolds:

- Required directories
- `framework-config.json`
- npm scripts
- environment templates
- deterministic utility scripts
- Playwright runtime prerequisites

## 3. Install runtime dependencies

From the **project root**:

```bash
npm run setup
```

The framework setup flow is designed to install the runtime required under `output/`, install the Chromium browser build, and make the Playwright CLI available.

Equivalent browser setup includes:

```bash
npm install -g @playwright/cli
npx playwright install chromium
```

Normally, use `npm run setup` rather than manually repeating these commands.

## 4. Configure environment variables

If `output/.env` does not exist:

```bash
cp output/.env.example output/.env
```

PowerShell:

```powershell
Copy-Item output/.env.example output/.env
```

Fill in local values without committing credentials.

## 5. Configure your application context

Update `framework-config.json` as required, particularly:

```json
"appContext": {
  "web": "",
  "api": "",
  "mobile": {
    "android": "",
    "ios": ""
  }
}
```

## 6. Add or generate a scenario

Place structured scenarios under:

```text
scenarios/web/
scenarios/api/
scenarios/hybrid/
```

or use the BDD / Enrichment agents to generate them from requirements.

## 7. Run the pipeline through the Pipeline Orchestrator

Invocation syntax differs slightly by IDE. A typical natural-language request is:

```text
Run the QE pipeline for scenario "login-and-checkout" using type "web".
```

For grouped scenarios:

```text
Run the QE pipeline for scenario "book-appointment" using type "web" and folder "vfs".
```


---

# Visual Studio Code + GitHub Copilot Agent Mode

This section provides a practical onboarding path for engineers who want to clone the framework, open it in **Visual Studio Code**, configure the runtime, and use **GitHub Copilot Agent Mode** to understand, troubleshoot, change, test, and validate the project.

> **Important:** GitHub Copilot Agent Mode is an engineering assistant, not a replacement for source control, code review, security review, or the framework's own Reviewer quality gate. Treat all AI-generated changes as proposed engineering changes that must be inspected and validated.

## Recommended onboarding flow

```mermaid
flowchart LR
    A[Clone Repository] --> B[Open Trusted Workspace in VS Code]
    B --> C[Verify Git / Node / npm / Copilot]
    C --> D[Create Feature Branch]
    D --> E[Install Dependencies]
    E --> F[Configure .env + framework-config.json]
    F --> G[Understand Project with Copilot Ask / Plan]
    G --> H[Use Agent Mode for Scoped Change]
    H --> I[Review Diff]
    I --> J[Run Build / Tests / QE Pipeline]
    J --> K[Reviewer + Security Validation]
    K --> L[Commit + Pull Request]
```

## 1. Install the workstation prerequisites

Install or obtain access to the following before cloning the project:

| Prerequisite | Why it is needed | Verification command / action |
|---|---|---|
| **Git** | Clone, branch, diff, commit, and pull-request workflow | `git --version` |
| **Visual Studio Code** | Recommended IDE for this guide | `code --version` |
| **Node.js LTS** | Runs npm, Playwright, TypeScript tooling, and framework utilities | `node --version` |
| **npm** | Installs and runs project dependencies/scripts | `npm --version` |
| **GitHub account with Copilot access** | Required for Copilot Chat / Agent Mode | Sign in from VS Code Accounts |
| **GitHub Copilot in VS Code** | Provides Ask, Plan, Agent, tools, custom agents, and code assistance | Open the Copilot Chat view |
| **Network/VPN access** | Required when the application under test is internal | Verify target URL manually |
| **Test credentials** | Required for authenticated flows | Store only in `output/.env` or an approved secret store |

For this framework, also install the Playwright CLI/browser runtime when setup does not do so automatically:

```bash
npm install -g @playwright/cli
npx playwright install chromium
```

The repository's preferred setup path remains:

```bash
npm run setup
```

### Recommended Node.js version

Use the Node.js version defined by the repository when an `.nvmrc`, `.node-version`, `engines` field, or team standard is present. Otherwise use a current supported **Node.js LTS** release. Avoid switching Node versions casually on an established project because Playwright and transitive dependencies can be version-sensitive.

## 2. Clone the repository

### Option A — Clone from the VS Code UI

1. Start Visual Studio Code.
2. Open the Command Palette with **Ctrl+Shift+P** on Windows/Linux or **Cmd+Shift+P** on macOS.
3. Run **Git: Clone**.
4. Paste the repository URL.
5. Select a local parent folder.
6. Open the cloned repository when VS Code prompts you.
7. Review the **Workspace Trust** prompt. Trust the workspace only when the repository/source is known and approved.

### Option B — Clone from the terminal using HTTPS

```bash
git clone https://github.com/<organization>/<repository>.git
cd <repository>
code .
```

### Option C — Clone using SSH

```bash
git clone git@github.com:<organization>/<repository>.git
cd <repository>
code .
```

If your organization uses GitHub Enterprise Server, replace `github.com` with the organization's GitHub hostname.

### Confirm that you are at the repository root

```bash
git status
```

You should also see core repository content such as:

```text
.github/
  agents/
  skills/
languages/
mcp/
framework-config.json
README.md
```

A complete source distribution is also expected to provide the runtime assets referenced by the framework, such as `package.json`, `scripts/`, scenarios, and generated/runtime directories as applicable.

## 3. Create a feature branch before making changes

Do not begin AI-assisted implementation directly on the protected/default branch.

```bash
git fetch --all --prune
git switch main
git pull --ff-only
git switch -c feature/<short-description>
```

Examples:

```bash
git switch -c feature/add-checkout-scenario
git switch -c fix/vfs-login-selector
git switch -c docs/copilot-agent-onboarding
```

If your repository uses `develop` or another integration branch, branch from that branch instead of `main`.

## 4. Inspect the repository before installing anything

Before asking Copilot to modify code, understand what is already present:

```bash
git status
node --version
npm --version
npm run
```

`npm run` is especially useful because it lists the scripts available in the actual repository version you cloned.

Useful files to inspect first:

```text
README.md
framework-config.json
package.json
package-lock.json
.github/agents/
.github/skills/
mcp/README.md
languages/
scenarios/
scripts/
output/.env.example
```

> Never invent a missing command. If a README says `npm run setup` but the cloned branch has no corresponding npm script, stop and resolve the repository/version mismatch or use the Setup Agent rather than guessing.

## 5. Install dependencies

### Preferred project setup

Run from the repository root:

```bash
npm run setup
```

The framework documentation expects setup to establish the deterministic runtime, required dependencies, Playwright CLI/browser prerequisites, and output structure.

### Standard npm dependency installation

When a normal root `package.json` and lock file are present, use the team's approved install method. For reproducible CI-like installation, this is normally:

```bash
npm ci
```

Use:

```bash
npm install
```

only when intentionally updating dependencies or when the project does not have a compatible lock file.

### Install the Playwright browser explicitly if required

```bash
npx playwright install chromium
```

Verify the CLI:

```bash
playwright-cli --help
```

### Do not commit dependencies

Never commit either of these:

```text
node_modules/
output/node_modules/
```

## 6. Configure local environment variables

Create a local environment file from the safe template:

**macOS/Linux:**

```bash
cp output/.env.example output/.env
```

**PowerShell:**

```powershell
Copy-Item output/.env.example output/.env
```

Populate values required by the application under test. Typical categories include:

```dotenv
BASE_URL=https://example.test
API_BASE_URL=https://api.example.test
TEST_USERNAME=<local-secret>
TEST_PASSWORD=<local-secret>
```

Use the variable names supplied by the project rather than introducing new names without a reason.

### Secret-handling rules

- Never paste production passwords, API keys, PATs, access tokens, cookies, private certificates, or connection strings into Copilot prompts.
- Never commit `output/.env`.
- Prefer dedicated lower-environment test identities.
- Use the CI/CD platform's secret store for pipelines.
- Check generated logs/reports before sharing them because screenshots, request bodies, headers, and traces can contain sensitive data.

Before continuing, run:

```bash
git status --short
```

and verify that the local `.env` does **not** appear as an untracked file intended for commit.

## 7. Configure the framework

Open:

```text
framework-config.json
```

At minimum, review:

```json
{
  "modality": "web",
  "language": "typescript",
  "appContext": {
    "web": "",
    "api": "",
    "mobile": {
      "android": "",
      "ios": ""
    }
  },
  "executor": {
    "maxCycles": 3,
    "preFlightEnabled": true,
    "healProbeHeaded": false
  },
  "review": {
    "minScore": 80
  }
}
```

For example, a local/demo web target might be configured as:

```json
"appContext": {
  "web": "https://www.saucedemo.com/",
  "api": "",
  "mobile": {
    "android": "",
    "ios": ""
  }
}
```

Do not weaken timeouts, reviewer thresholds, security rules, or quality gates merely to make a failing test appear green.

## 8. Configure optional MCP integrations in VS Code

The framework uses MCP for external enterprise systems such as Jira, Azure DevOps, and Figma. Core browser exploration uses **Playwright CLI**, not Playwright MCP.

VS Code project-level MCP configuration belongs at:

```text
.vscode/mcp.json
```

Use:

```text
mcp/bdd-trackers.mcp.example.json
```

as the source template and copy only the servers required for the task.

Examples of expected server identities are:

```text
atlassian-mcp-server
ado-mcp-server
figma-mcp-server
```

Important practices:

- Keep credentialed `.vscode/mcp.json` configuration out of Git when it contains machine-local secrets.
- Give Jira/ADO/Figma integrations the minimum permissions required.
- Do not add Playwright MCP merely because Copilot supports MCP; this framework intentionally drives web exploration through the Playwright CLI.
- Reload VS Code after changing MCP configuration.

See [`mcp/README.md`](mcp/README.md) for the project-specific MCP model.

## 9. Sign in to GitHub Copilot in Visual Studio Code

1. Open Visual Studio Code.
2. Sign in to GitHub from the **Accounts** menu.
3. Confirm that your account/organization provides GitHub Copilot access.
4. Open **GitHub Copilot Chat**.
5. Use the agent/mode selector in the Chat view.

Current VS Code/Copilot supports different interaction styles, commonly including:

| Mode | Recommended use |
|---|---|
| **Ask** | Understand code, architecture, errors, and behavior without asking for broad autonomous edits. |
| **Plan** | Ask Copilot to design an implementation approach before changing files. |
| **Agent** | Perform a well-scoped multi-step engineering task involving edits, terminal commands, tests, and iteration. |

For unfamiliar or high-impact work, use this sequence:

```text
Ask → Plan → Agent → Review Diff → Test → Review Again → Commit
```

## 10. Understand how this repository integrates with Copilot custom agents

VS Code can discover repository-level custom agents from:

```text
.github/agents/
```

This repository contains nine specialist agent definitions:

```text
bdd-scenario-author.agent.md
enrichment-agent.agent.md
explorer-agent.agent.md
builder-agent.agent.md
executor-agent.agent.md
reviewer-agent.agent.md
healer-agent.agent.md
setup-agent.agent.md
pipeline-orchestrator.agent.md
```

In VS Code, these repository custom agents can appear in the agents/customizations interface depending on the installed Copilot/VS Code version and organizational policy.

The framework also provides reusable agent skills in:

```text
.github/skills/
```

The 37 skills cover API behavior, web interaction, selector generation/healing, code generation, scenario handling, quality gates, reporting, path resolution, bug detection, and other QE knowledge.

### Recommended agent ownership model

Do not ask one agent to bypass the framework and perform every role. Use the intended specialization:

```text
Requirement → BDD Scenario Author / Enrichment
           → Pipeline Orchestrator
           → Explorer
           → Builder
           → Executor
           → Reviewer
           → Healer when required
           → Reviewer again
```

This preserves the framework's separation of duties and makes the result easier to audit.

## 11. Start by using Copilot to understand the codebase

Before requesting changes, use **Ask** or a read-only planning workflow to build context.

### Example — architecture orientation

```text
Analyze this repository without modifying any files.

Explain:
1. The purpose of the framework.
2. The role of each file under .github/agents.
3. How .github/skills is used by the agents.
4. How framework-config.json controls execution.
5. How a web scenario moves through enrichment, exploration, build, execution, review, and healing.
6. Which folders contain generated artifacts and which files are source-controlled.
7. Any missing prerequisites required to run the repository locally.

Cite the relevant repository file paths in your explanation.
```

### Example — trace one feature end to end

```text
Do not edit files. Trace the login scenario end to end through this repository.
Show the requirement/scenario source, enriched scenario, locators, Page Object, test data, Playwright spec, execution evidence, reviewer output, and healing artifacts where available.
Call out anything missing rather than guessing.
```

### Example — explain a specific agent

```text
Read .github/agents/pipeline-orchestrator.agent.md and the skills it references.
Explain its responsibilities, prohibited behavior, quality gates, inputs, outputs, and failure behavior.
Do not change the project.
```

## 12. Use Plan mode before non-trivial changes

For changes that affect multiple files, architecture, security, scenarios, or agent behavior, ask Copilot to plan first.

Example:

```text
Plan an implementation for adding a new password-reset web scenario.

Constraints:
- Preserve the current agent architecture.
- Reuse existing locator, Page Object, test-data, and reporting conventions.
- Do not modify shared framework utilities unless required.
- Keep credentials in environment variables.
- Include the exact files you expect to create or modify.
- Include test/validation steps.
- Identify risks and assumptions.

Do not edit files yet.
```

Review the plan. If the plan changes shared framework code unnecessarily, correct the scope before switching to Agent mode.

## 13. Use Agent Mode for a scoped implementation

Agent Mode is best used when the task is clear, bounded, and testable.

### Strong implementation prompt pattern

Use a prompt containing:

```text
Objective
Scope
Constraints
Relevant files/context
Acceptance criteria
Validation commands
Files that must not be changed
```

Example:

```text
Implement support for a new login-negative scenario.

Objective:
Add automation for invalid credentials and verify the approved error message.

Scope:
- Add/update only the scenario-specific artifacts needed for this flow.
- Reuse the existing login Page Object and locator repository where possible.
- Keep test data externalized.

Constraints:
- Do not hardcode credentials.
- Do not change expected text just to make the test pass.
- Do not modify scripts/ or shared framework core unless you can demonstrate a framework defect.
- Preserve existing tests.
- Follow the repository's TypeScript and Playwright conventions.

Acceptance criteria:
1. Invalid login is attempted using environment/test-data values.
2. The correct error message is asserted.
3. Existing valid-login tests still pass.
4. The Reviewer quality gate reports no scenario-fidelity issue.

Validation:
- Run the relevant Playwright spec first.
- Run the applicable broader suite afterward.
- Show me the final git diff and summarize every changed file.
```

## 14. Use Copilot Agent Mode for troubleshooting

Copilot is especially effective when you provide the failure evidence rather than only saying "fix the test."

### Example — failing Playwright test

```text
Investigate this Playwright failure. Do not change assertions or business expectations unless the requirement itself proves they are wrong.

Use the failing test, locator JSON, relevant Page Object, latest Playwright output, browser snapshot/trace, and framework quality rules.

Determine whether this is:
- a product defect,
- stale locator,
- wait/timing issue,
- bad test data,
- environment/configuration issue,
- authentication problem,
- or automation code defect.

Explain the evidence first. Then make the smallest safe fix if the evidence supports an automation change. Run the focused test and report the result.
```

### Example — dependency/setup failure

```text
Diagnose the latest setup failure from the terminal output.
First inspect package.json, the lock file, Node/npm versions, and existing setup documentation.
Do not upgrade dependencies unless necessary.
Prefer the smallest change that restores the documented setup path.
After the fix, rerun the failed setup/build command and show the result.
```

### Example — selector failure

```text
The checkout test can no longer locate the Continue button.
Use the existing locator hierarchy and framework selector-healing rules.
Do not use force:true and do not replace the business flow.
Confirm the current DOM using the project's approved Playwright CLI flow, propose the smallest locator update, run the test, and show the resulting diff.
```

## 15. Use Copilot to make changes safely

Before allowing an agent to change the repository, tell it what it **must not** change.

Useful constraints include:

```text
Do not:
- change expected values to make tests pass;
- disable or skip failing tests without approval;
- reduce reviewer thresholds;
- weaken security checks;
- introduce force:true as a shortcut;
- duplicate an existing Page Object;
- create hardcoded sleeps when deterministic waits exist;
- put credentials into source code;
- rewrite unrelated files;
- update dependencies unless required by the requested task;
- delete execution evidence needed to diagnose the issue.
```

This is especially important in Agent Mode because the agent can choose which files and terminal commands are needed to complete the task.

## 16. Review every generated change before accepting it

Never treat "Copilot completed the task" as equivalent to engineering approval.

Use both VS Code diff views and Git:

```bash
git status --short
git diff --stat
git diff
```

Review for:

- Unrequested files changed.
- Business assertions changed.
- Test cases silently skipped.
- Broad refactoring unrelated to the ticket.
- Secrets or PII introduced.
- Hardcoded URLs/credentials.
- Dependency/lock-file churn.
- Weakened timeouts or quality gates.
- `force: true` or brittle CSS/XPath selectors.
- Duplicate Page Objects, test data, or utilities.
- Lost comments/metadata required by the framework.
- Removed reviewer/healer evidence.

If the diff is larger than expected, ask Copilot to explain each change and revert anything outside the approved scope.

## 17. Build and validate the project

The exact npm scripts are defined by the cloned repository. Always inspect them first:

```bash
npm run
```

### Typical setup/build validation

```bash
npm run setup
```

If the repository defines a build script:

```bash
npm run build
```

For TypeScript repositories without a dedicated build script but with TypeScript configured, a useful static check is:

```bash
npx tsc --noEmit
```

Do not add a new build system solely because `npm run build` does not exist; first confirm whether the framework is intended to execute directly through TypeScript/Playwright tooling.

### Run Playwright tests

Run a focused test while developing:

```bash
npx playwright test <path-to-spec>
```

Run the complete Playwright test set when practical:

```bash
npx playwright test
```

Useful diagnostic modes include:

```bash
npx playwright test --headed
npx playwright test --debug
npx playwright test --ui
```

Use the modes supported by your installed Playwright version and team policy.

### Run the Agentic QE pipeline

For this repository, the primary framework workflow is invoked through the **Pipeline Orchestrator** with a scenario and modality.

Example Copilot request:

```text
Use the Pipeline Orchestrator to run the QE pipeline for scenario "login-and-checkout" using type "web".
Follow the repository's configured quality gates and stop with INCOMPLETE if a required stage or artifact cannot be produced.
```

Grouped scenario example:

```text
Use the Pipeline Orchestrator to run scenario "book-appointment" using type "web" and folder "vfs".
Run enrichment, exploration, builder, executor, reviewer, and any bounded healing/re-review required by the framework.
Summarize the generated artifacts and final verdict.
```

### Example: run `saucedemo-smoke.md` from GitHub Copilot Agent Mode

A user does not need to remember every internal agent or command. In **GitHub Copilot Chat → Agent Mode**, a simple project-oriented instruction can be used:

```text
Run scenario saucedemo-smoke.md
```

When the repository context and custom agents are available, Copilot should first locate the scenario file and determine the correct framework workflow instead of treating the request as a raw `npx playwright test` command.

For a more explicit and controlled enterprise prompt, use:

```text
Run the scenario `saucedemo-smoke.md` using this repository's Agentic QE pipeline.

Please:
1. Locate the scenario in the repository and confirm its scenario type and target application.
2. Use the Pipeline Orchestrator and the project's existing custom agents; do not bypass the framework architecture.
3. Preserve the business intent and expected results defined in the scenario.
4. Enrich the scenario if required.
5. Explore the live SauceDemo application using the framework's approved Playwright workflow and capture grounded selector evidence.
6. Generate or update only the required locators, Page Objects, test data, and Playwright test artifacts.
7. Execute the generated test.
8. If execution fails, diagnose the root cause. Apply only bounded fixes permitted by the framework; do not change expected business behavior merely to make the test pass.
9. Run the independent Reviewer quality gate.
10. If the Reviewer identifies approved repairable findings, run the Healer and re-review within the configured limits.
11. Stop with INCOMPLETE if a mandatory stage cannot be completed or required evidence is unavailable.
12. At the end, summarize:
   - stages executed,
   - files created or changed,
   - test execution result,
   - healing performed, if any,
   - Reviewer findings and score/verdict,
   - evidence/report locations, and
   - final PASS / FAIL / INCOMPLETE status.

Before making broad or shared-framework changes, explain why they are necessary. Keep the diff minimal.
```

#### What this prompt does

`Run scenario saucedemo-smoke.md` is intended to trigger the **complete Agentic Quality Engineering workflow for one SauceDemo smoke scenario**, not merely execute an existing Playwright spec. Conceptually, the request flows as follows:

```mermaid
flowchart LR
    A[Copilot Agent Mode Prompt] --> B[Locate saucedemo-smoke.md]
    B --> C[Pipeline Orchestrator]
    C --> D[Enrichment / Scenario Validation]
    D --> E[Explorer]
    E --> F[Builder]
    F --> G[Executor]
    G --> H[Reviewer]
    H -->|Repairable findings| I[Healer]
    I --> J[Re-execute / Re-review]
    H -->|Quality gates passed| K[Final Verdict]
    J --> K
```

The stages are expected to perform the following responsibilities:

| Stage | What happens for `saucedemo-smoke.md` | Typical output/evidence |
|---|---|---|
| **1. Scenario discovery** | Copilot searches the repository for `saucedemo-smoke.md`, reads it, and determines whether it is a web scenario and what SauceDemo flow it describes. | Located scenario path and resolved framework context |
| **2. Scenario enrichment** | The Enrichment Agent validates or converts the scenario into the canonical framework representation while preserving steps, test data, and expected behavior. | Enriched scenario / enrichment report |
| **3. Live exploration** | The Explorer Agent opens the configured SauceDemo environment, performs the scenario steps, confirms the UI is reachable, and discovers reliable elements/selectors from the real application. | Explorer evidence, annotated scenario, selector observations |
| **4. Automation build** | The Builder Agent creates or updates only the assets needed for the scenario: locator definitions, Page Objects, externalized test data, and Playwright test code. | Locator JSON, Page Object, data file, Playwright spec |
| **5. Execution** | The Executor Agent runs the generated test using the project's Playwright configuration and captures the test result and evidence. | PASS/FAIL result, console output, screenshots/traces/reports where configured |
| **6. Diagnosis / bounded repair** | If the run fails, the framework diagnoses whether the issue is selector, timing, sequencing, environment, or implementation related. Only permitted, minimal repair is attempted. | Diagnosis, repair record, changed files |
| **7. Independent review** | The Reviewer evaluates the resulting automation against the framework's quality dimensions, including locator quality, waits, architecture, maintainability, security, and scenario-to-code fidelity. | Reviewer scorecard / findings |
| **8. Healing and re-review** | When approved repairable findings exist, the Healer applies targeted changes and the affected test/review cycle is repeated within configured limits. | Healing report and updated review |
| **9. Final verdict** | The Pipeline Orchestrator consolidates execution and quality-gate results. A test is not considered successful only because Playwright returned green. | Final PASS, FAIL, or INCOMPLETE summary |

#### Example of what `saucedemo-smoke.md` may represent

The exact steps must always come from the repository's scenario file. A SauceDemo smoke scenario commonly validates a short critical-path flow such as:

```text
Open SauceDemo
→ Sign in with configured test credentials
→ Verify the inventory/products page is displayed
→ Validate one or more core UI elements
→ End the test and capture evidence
```

This is only an illustration. **Copilot and the QE agents must not invent, remove, or change steps if `saucedemo-smoke.md` defines a different flow. The scenario file remains the source of truth.**

#### What the user should see when the run completes

Ask Copilot to provide a concise execution summary similar to:

```text
Scenario: saucedemo-smoke.md
Type: web
Target: SauceDemo

Pipeline:
✓ Scenario located
✓ Enrichment completed
✓ Live exploration completed
✓ Automation artifacts generated/updated
✓ Playwright execution completed
✓ Reviewer completed
✓ Quality gates evaluated

Execution: PASS
Reviewer verdict: PASS
Healing: Not required

Changed/generated artifacts:
- <scenario/enrichment path>
- <locator path>
- <page-object path>
- <test-data path>
- <playwright-spec path>
- <execution-report path>
- <reviewer-report path>

Final pipeline status: PASS
```

If a stage cannot be completed, the summary should state the actual blocker instead of fabricating success, for example:

```text
Final pipeline status: INCOMPLETE
Reason: SauceDemo could not be reached from the current environment, so Explorer grounding and downstream automation validation could not be completed safely.
```

#### Recommended follow-up prompts

After running the scenario, users can continue in Copilot Agent Mode with focused prompts such as:

```text
Explain every file created or changed while running saucedemo-smoke.md and map each file back to the scenario step it supports.
```

```text
Show me why the Reviewer passed or failed saucedemo-smoke.md. Do not change any files. Cite the relevant scenario and generated code.
```

```text
The saucedemo-smoke.md execution failed. Diagnose the root cause using the test output, trace, screenshots, locator evidence, and generated code. Do not fix anything until you have separated application defects, environment issues, test-data issues, selector problems, and automation-code defects.
```

```text
Review the changes produced for saucedemo-smoke.md. Identify any modification outside the minimum scope required by this scenario and explain whether it should be reverted.
```

### Validate generated evidence

Check the relevant generated locations, commonly including:

```text
output/tests/
output/pages/
output/locators/
output/test-data/
output/test-results/
output/reports/
output/reports/metrics/
output/allure-results/
```

A green terminal command is not sufficient if the framework Reviewer reports a hard fidelity failure.

## 18. Ask Copilot to perform a pre-commit review

After implementation and tests pass, use a review-oriented prompt:

```text
Review my current uncommitted diff as a senior QE automation reviewer.

Focus on:
- scenario-to-code fidelity,
- locator quality,
- wait strategy,
- Page Object reuse,
- test-data externalization,
- maintainability,
- security/secrets,
- API test quality where applicable,
- unintended changes,
- regression risk.

Do not edit anything yet. List only evidence-based findings with file paths and severity.
```

Then, if findings are valid:

```text
Fix only the findings we agreed are valid. Keep the diff minimal. Rerun the affected checks and show the final diff summary.
```

This complements—rather than replaces—the repository's own Reviewer Agent.

## 19. Recommended Git workflow

A disciplined AI-assisted Git workflow looks like this:

```text
Update base branch
      ↓
Create feature branch
      ↓
Understand / plan
      ↓
Implement small change
      ↓
Review diff
      ↓
Run focused tests
      ↓
Run quality/security checks
      ↓
Commit meaningful unit of work
      ↓
Push branch
      ↓
Open pull request
      ↓
Human review + CI validation
      ↓
Merge through normal policy
```

### Before committing

```bash
git status
git diff --check
git diff
```

If configured by the repository, also run lint/build/test scripts, for example:

```bash
npm run lint
npm run build
npm test
npx playwright test
```

Only run scripts that actually exist in the cloned repository.

### Stage intentionally

Prefer deliberate staging over blindly staging everything:

```bash
git add README.md
git add scenarios/web/<scenario-file>
git add output/locators/<approved-locator-file>
```

Review the staged diff:

```bash
git diff --cached
```

### Use meaningful commits

Examples:

```bash
git commit -m "test: add invalid login scenario"
git commit -m "fix: update VFS appointment locator strategy"
git commit -m "docs: add Copilot Agent Mode onboarding guide"
```

Avoid messages such as:

```text
changes
fix stuff
copilot update
working version
```

The commit should describe the engineering outcome, not the fact that AI assisted with it.

## 20. Recommended Copilot Agent Mode best practices

### A. Give a precise objective

Weak:

```text
Improve this framework.
```

Better:

```text
Add retry-safe handling for the appointment-date selector in the VFS booking flow without changing business assertions or shared framework behavior. Run the focused test and show the diff.
```

### B. Provide sufficient context

Include:

- ticket/requirement identifier;
- target scenario;
- relevant file paths;
- expected behavior;
- actual error;
- logs/trace location;
- environmental constraints;
- acceptance criteria;
- what files or behavior must not change.

Do not attach unrelated files "just in case." More context is not automatically better; **relevant context** is better.

### C. Ask for evidence before fixes

For failures, prefer:

```text
Diagnose first. Cite the repository evidence supporting the diagnosis. Do not edit until the likely cause is identified.
```

This reduces random trial-and-error changes.

### D. Keep tasks small enough to review

Prefer one bounded change at a time:

```text
1. Add the scenario.
2. Validate exploration.
3. Generate/update automation.
4. Execute.
5. Review.
```

rather than asking for an unbounded repository rewrite.

### E. Follow the existing architecture

Tell Copilot to reuse:

- existing Page Objects;
- externalized locator JSON;
- environment variables;
- test-data loaders;
- shared-state conventions;
- framework reports;
- existing reusable skills;
- existing test organization.

Do not allow Agent Mode to create a parallel mini-framework because it did not inspect the existing architecture first.

### F. Review AI-generated code as third-party code

Check logic, error handling, types, security, concurrency, retries, assertions, selectors, waits, and cleanup. AI-generated code requires the same or greater scrutiny as any external contribution.

### G. Run the smallest useful test first

Use the test pyramid of feedback:

```text
Static/type check
   ↓
Focused scenario/spec
   ↓
Related feature suite
   ↓
Broader regression
   ↓
Full CI pipeline
```

This shortens troubleshooting loops without skipping final regression validation.

### H. Validate security-sensitive changes manually

Extra review is required for changes touching:

- authentication;
- authorization/RBAC;
- session/cookies/tokens;
- secrets;
- CI/CD permissions;
- network calls;
- MCP credentials/tools;
- environment files;
- logging/telemetry;
- file access;
- dependency updates;
- code execution or shell commands.

Never accept a security-sensitive change simply because the generated code compiles or the test passes.

### I. Avoid unnecessary modifications

Explicitly constrain the agent:

```text
Make the smallest change that satisfies the acceptance criteria. Do not reformat, rename, upgrade, or refactor unrelated code.
```

Small diffs are easier to understand, test, review, revert, and audit.

### J. Preserve requirement integrity

This framework has an explicit scenario-to-code fidelity gate. Never ask Copilot to:

- change expected values to match actual defects;
- delete failing assertions;
- skip required steps;
- mock away the behavior being tested;
- add arbitrary waits to hide instability;
- bypass authorization;
- reduce review thresholds solely to gain approval.

If the application contradicts the approved requirement, record it as a potential product defect instead of rewriting the test to hide it.

### K. Use least-privilege agent permissions

VS Code agent tools can edit files, execute terminal commands, and invoke external tools. Start new or unfamiliar tasks with conservative/manual approvals. Only grant broader automatic approval to commands/tools you understand and trust.

Particularly review commands that:

- install or publish packages;
- delete/move large file trees;
- change Git history;
- alter system configuration;
- connect to external systems;
- handle credentials;
- deploy artifacts;
- modify infrastructure.

### L. Keep humans in the release decision

For shared or production-bound changes:

- use pull requests;
- require CI;
- retain human review according to team policy;
- apply branch protection;
- require specialist/security review where appropriate;
- do not use Copilot output as the sole approval signal.

## 21. Practical prompt cookbook

### Understand the repository

```text
Map the repository architecture for a new engineer. Do not edit files. Explain source vs generated folders, the nine agents, reusable skills, configuration, execution entry points, and evidence/report locations. Finish with a recommended reading order.
```

### Explain a failure

```text
Explain the root cause of the latest failing Playwright test using the terminal output and related source files. Distinguish product defect, environment issue, test-data issue, selector issue, wait issue, and automation-code issue. Do not modify anything.
```

### Make a minimal fix

```text
Implement the smallest safe fix for the confirmed locator defect. Preserve the existing Page Object API and assertions. Update only the locator artifact unless another file is demonstrably required. Run the focused test and show the diff.
```

### Add a feature

```text
Implement the approved requirement <ID> using the existing QE framework. First inspect similar scenarios and reuse established patterns. Do not create new framework abstractions unless no existing one fits. Run relevant tests and Reviewer validation before finishing.
```

### Generate/update test automation

```text
Use the repository's existing agent workflow to generate or update Playwright automation for <scenario>. Preserve requirement fidelity, externalized locators and test data, and existing healed code. Execute and review the result instead of stopping after code generation.
```

### Security review

```text
Review the current diff for secrets, unsafe logging, excessive permissions, insecure network calls, hardcoded credentials, auth/session regressions, dependency risk, and MCP/CI privilege changes. Do not modify files. Report findings with file paths and evidence.
```

### Regression-impact review

```text
Analyze the current diff and identify which scenarios/tests are most likely to regress. Explain why, then propose the smallest meaningful regression set. Do not run unrelated tests unless they are needed.
```

### Documentation update

```text
Update the README only for the behavior introduced in this branch. Keep existing architecture terminology consistent. Do not claim a command or capability exists unless you can verify it from repository files.
```

## 22. Common Copilot Agent Mode mistakes to avoid

| Mistake | Why it is risky | Better approach |
|---|---|---|
| "Fix everything" prompt | Encourages broad uncontrolled edits | Define one outcome and acceptance criteria |
| Giving production secrets as context | Secrets can leak through logs/prompts/artifacts | Use local secret stores and placeholders |
| Accepting all edits without diff review | Can hide unintended changes | Review `git diff` file by file |
| Letting the agent change assertions to green | Masks product defects | Protect requirement fidelity |
| Automatically approving every terminal command | Expands blast radius | Start with manual/scoped approval |
| Upgrading dependencies during an unrelated fix | Introduces avoidable risk | Pin scope; update dependencies separately |
| Running only the changed test | Misses regression impact | Focused test, then relevant regression |
| Asking Copilot to bypass Reviewer/Healer | Breaks governance model | Use the intended agent pipeline |
| Committing generated `.env` or traces | Security/data exposure | Verify `.gitignore` and staged diff |
| Huge AI-generated commits | Hard to audit/revert | Commit cohesive, reviewable units |

## 23. Recommended team working agreement for Copilot

Teams adopting this framework should agree on at least the following:

1. **AI output is reviewed, not trusted by default.**
2. **Requirements and assertions are authoritative.** AI cannot silently rewrite expected behavior.
3. **The existing framework architecture is preferred over new abstractions.**
4. **Secrets never enter prompts or source control.**
5. **High-risk terminal/tool actions require explicit human approval.**
6. **Every code change has deterministic validation.**
7. **The repository Reviewer remains an independent quality gate.**
8. **Feature branches and pull requests are used for shared code.**
9. **Changes remain minimal and traceable to a requirement/defect.**
10. **Generated code receives the same security and quality review as handwritten code.**

## 24. Suggested first-day onboarding exercise

A new engineer can use the following safe exercise to learn the project:

### Step 1 — Understand

Ask Copilot:

```text
Explain the framework architecture without changing files. Give me a reading order for the top 10 files/folders I should understand first.
```

### Step 2 — Inspect one scenario

```text
Trace one existing SauceDemo login scenario from scenario input through locators, page object, test, execution evidence, and reviewer artifacts. Do not edit.
```

### Step 3 — Validate local runtime

```bash
npm run setup
npx playwright test --list
```

Run one known-safe existing spec when available:

```bash
npx playwright test <existing-spec>
```

### Step 4 — Make a documentation-only practice change

Create a branch and make a small README improvement. Review the diff and commit it.

### Step 5 — Make a small automation change

With a reviewer/mentor, change one low-risk test artifact using Plan → Agent → Diff Review → Focused Test → Reviewer.

This progression lets users learn Agent Mode without immediately giving it broad access to a sensitive end-to-end flow.

## 25. Troubleshooting Copilot in this repository

### Repository custom agents do not appear

Check:

- The project root opened in VS Code is the actual repository root.
- `.github/agents/` exists.
- Agent definition files are valid Markdown/agent profiles.
- GitHub Copilot Chat is enabled and signed in.
- Organization policies allow the feature.
- VS Code/Copilot is updated to a version that supports repository custom agents.

Reload the VS Code window after configuration changes.

### Agent suggests an unsafe or unrelated terminal command

Do not approve it. Ask:

```text
Explain why this command is necessary and propose a less destructive alternative. Do not run anything yet.
```

### Agent keeps modifying too many files

Stop the iteration and restate scope:

```text
Revert all changes outside <allowed paths>. Make the smallest change required. Do not refactor or reformat unrelated code.
```

Then inspect:

```bash
git diff --stat
git diff
```

### Copilot lacks enough project context

Point it to the relevant files instead of pasting the entire repository:

```text
Read framework-config.json, .github/agents/pipeline-orchestrator.agent.md, .github/skills/knowledge-quality-gates/, and the target scenario. Then reassess the plan.
```

### Copilot claims a command/file exists but it does not

Ask it to verify using repository search or the terminal before continuing. Do not allow invented commands or paths to become new architecture accidentally.

### Agent changes tests to hide a product issue

Revert the changes and ask for evidence-based classification using the framework's bug-detection and fidelity rules. A failing test can be the correct outcome when the application violates the approved requirement.

## 26. Official Copilot references

GitHub and VS Code evolve quickly. For current product behavior and UI labels, refer to:

- [GitHub Docs — Asking GitHub Copilot questions in your IDE](https://docs.github.com/en/copilot/how-tos/chat-with-copilot/chat-in-ide)
- [VS Code — Custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents)
- [VS Code — Tools used by agents](https://code.visualstudio.com/docs/copilot/concepts/tools)
- [VS Code — Manage approvals and permissions](https://code.visualstudio.com/docs/agents/run/approvals)
- [GitHub Docs — Copilot customization cheat sheet](https://docs.github.com/en/copilot/reference/customization-cheat-sheet)

---

# Framework Configuration

The primary user-configurable file is:

```text
framework-config.json
```

The recovered configuration is:

```json
{
  "$comment": "qe-automation — user-configurable settings. Agents read these keys instead of hardcoded values.",
  "modality": "web",
  "language": "typescript",
  "paths": {
    "scenarios": "scenarios",
    "output": "output",
    "testData": "output/test-data",
    "scripts": "scripts"
  },
  "exploration": {
    "maxAttemptsPerStep": 5,
    "snapshotTimeoutMs": 5000,
    "interactionTimeoutMs": 60000,
    "headed": true,
    "viewport": {
      "width": 1920,
      "height": 1080
    }
  },
  "executor": {
    "maxCycles": 3,
    "preFlightEnabled": true,
    "healProbeHeaded": false
  },
  "timeouts": {
    "testTimeoutMs": 180000,
    "actionTimeoutMs": 30000,
    "navigationTimeoutMs": 60000,
    "networkIdleTimeoutMs": 30000
  },
  "enrichedScenario": {
    "filenameSuffix": ".enriched",
    "createOnExploration": true,
    "neverModifyExisting": true
  },
  "bugDetection": {
    "uncertainVerdictEnabled": true,
    "flagDisabledElements": true,
    "flagEmptyValues": true
  },
  "builder": {
    "incrementalUpdate": true,
    "preserveHealedCode": true,
    "preservePacingComments": true
  },
  "chunking": {
    "maxStepsPerChunk": 15,
    "alwaysChunk": false
  },
  "appContext": {
    "web": "",
    "api": "",
    "mobile": {
      "android": "",
      "ios": ""
    }
  },
  "review": {
    "minScore": 80
  },
  "observability": {
    "trackTokens": true,
    "trackContextWindow": true,
    "trackDuration": true,
    "metricsVersion": "2.1.0"
  }
}
```

## Important Configuration Keys

| Key | Purpose |
|---|---|
| `modality` | Default automation modality |
| `language` | Generated automation language |
| `exploration.maxAttemptsPerStep` | Maximum Explorer retry attempts for a step |
| `exploration.headed` | Whether exploration uses a visible browser |
| `executor.maxCycles` | Maximum Executor repair/execution cycles |
| `timeouts.testTimeoutMs` | Overall test timeout |
| `timeouts.actionTimeoutMs` | Individual action timeout |
| `builder.incrementalUpdate` | Enables incremental generation behavior |
| `builder.preserveHealedCode` | Protects previously healed implementation |
| `review.minScore` | Minimum review score |
| `observability.trackTokens` | Tracks token usage |
| `observability.trackContextWindow` | Tracks context-window usage |
| `observability.trackDuration` | Tracks execution duration |

Configuration values should be changed here rather than hardcoded into agents or test implementation.

---

# Environment Configuration

Application-specific and secret values belong in:

```text
output/.env
```

A safe repository should provide:

```text
output/.env.example
output/.env.qa.example
output/.env.stg.example
```

Typical variables may include:

```dotenv
BASE_URL=
TEST_USERNAME=
TEST_PASSWORD=
API_BASE_URL=
```

Additional application-specific values can be added as required.

## Security Rules

- Never commit `output/.env`.
- Never include passwords, tokens, secrets, or access keys in scenarios.
- Never embed credentials in agent prompts.
- Never place secrets directly inside locator or test-data repositories.
- Use environment variables or an enterprise secret manager in CI/CD.

---

# Creating Scenarios

## Web Scenario

Suggested path:

```text
scenarios/web/<scenario>.md
```

or:

```text
scenarios/web/<folder>/<scenario>.md
```

## API Scenario

```text
scenarios/api/<scenario>.md
```

## Hybrid Scenario

Use hybrid when a business flow contains both UI and API behavior:

```text
scenarios/hybrid/<scenario>.md
```

## BDD Feature Files

The BDD Scenario Author writes approved-review artifacts to paths such as:

```text
scenarios/web/<folder>/featurefiles/<feature-name>.feature
scenarios/api/<folder>/featurefiles/<feature-name>.feature
scenarios/hybrid/<folder>/featurefiles/<feature-name>.feature
```

The Enrichment Agent then converts approved Gherkin into structured scenario Markdown for the automation pipeline.

---

# Running the Agentic Pipeline

The Pipeline Orchestrator expects parameters conceptually equivalent to:

| Parameter | Meaning |
|---|---|
| `scenario` | Scenario file name without extension |
| `type` | `web`, `api`, or `hybrid` |
| `folder` | Optional grouping folder |
| `input` | Existing scenario, NL input, Gherkin, or Swagger/OpenAPI |

## Example — Existing Web Scenario

```text
Run the Pipeline Orchestrator for scenario "inventory-checkout", type "web".
```

## Example — Grouped Scenario

```text
Run the Pipeline Orchestrator for scenario "create-booking", type "web", folder "vfs".
```

## Example — Natural Language

```text
Use the QE pipeline to automate this flow:
Login with a valid user, search for an appointment, select the earliest available slot,
submit the booking, and verify the confirmation reference.
```

## Example — OpenAPI

```text
Use the Enrichment Agent to generate API scenarios from openapi.json,
then execute the QE pipeline for the generated scenarios.
```

## Example — BDD Front Door

```text
Generate automation-ready BDD scenarios for Jira story ABC-123,
validate against the available design, and save the feature files.
```

After human review:

```text
Convert the approved feature file to a structured QE scenario and run the pipeline.
```

---

# Generated Artifacts

A successful pipeline can produce artifacts across the following categories.

## Scenario Artifacts

```text
scenarios/**
```

## Locator Repositories

```text
output/locators/*.locators.json
```

## Page Objects

```text
output/pages/**
```

## Test Data

```text
output/test-data/**
```

## Tests

```text
output/tests/**
```

## Stage Reports

```text
output/reports/**
```

Examples include:

- Enrichment report
- Explorer report
- Executor report
- Review scorecard
- Healer report
- Setup report
- Pipeline summary

## Metrics

```text
output/reports/metrics/**
```

## Test Evidence

```text
output/test-results/**
output/allure-results/**
output/.playwright-cli/**
```

Evidence may include:

- Screenshots
- Browser traces
- Console logs
- Text attachments
- Markdown evidence
- Raw execution results
- Allure result JSON

---

# Locator Architecture

Selectors are externalized from test code.

Observed locator files include:

```text
output/locators/login-page.locators.json
output/locators/inventory-page.locators.json
output/locators/vfs-login-page.locators.json
output/locators/vfs-dashboard-page.locators.json
output/locators/vfs-application-detail-page.locators.json
output/locators/vfs-your-details-page.locators.json
```

The locator approach supports concepts such as:

- Primary locator
- Fallback locators
- Element type
- Semantic description
- DOM evidence/fingerprint
- Healing metadata

This improves maintainability compared with embedding selectors directly throughout test specifications.

---

# Incremental Automation

The framework is designed to avoid regenerating everything for every requirement change.

Relevant configuration:

```json
"builder": {
  "incrementalUpdate": true,
  "preserveHealedCode": true,
  "preservePacingComments": true
}
```

Deterministic utility scripts referenced by the setup architecture include:

```text
scenario-diff.js
builder-incremental.js
cleanup-annotations.js
explorer-post-check.js
explorer-report-gen.js
executor-report-gen.js
review-precheck.js
test-results-parser.js
failure-classifier.js
swagger-parser.js
metrics-collector.js
eval-summary.js
setup.js
```

These utilities reduce the amount of reasoning that needs to be delegated to an LLM and help make behavior repeatable.

---

# Reporting and Observability

Agentic systems require observability beyond a simple test PASS/FAIL result.

The framework tracks:

- Token consumption
- Context-window usage
- Agent/stage duration
- Pipeline start and end time
- Stage boundaries
- Completed stages
- Skipped stages
- Failed stages
- Final pipeline verdict

Current metrics configuration:

```json
"observability": {
  "trackTokens": true,
  "trackContextWindow": true,
  "trackDuration": true,
  "metricsVersion": "2.1.0"
}
```

## Why This Matters

This information helps teams evaluate:

- AI execution cost
- Pipeline latency
- Expensive stages
- Excessive context usage
- Repeated repair cycles
- Agent efficiency
- Automation stability
- Quality versus cost trade-offs

---

# MCP Integrations

MCP is used for **external enterprise systems**, not for core Playwright browser execution.

## Current External MCP Use Cases

| MCP Server | Purpose | Required? |
|---|---|---|
| `atlassian-mcp-server` | Jira requirement retrieval | Required only when Jira is the requirement source |
| `ado-mcp-server` | Azure DevOps work-item retrieval | Required only when ADO is the requirement source |
| `figma-mcp-server` | Optional design validation | Optional |
| Appium MCP | Mobile automation | Phase 2 |

## Important Playwright Design Decision

The framework explicitly uses:

```text
Playwright CLI → Browser
```

for Explorer and browser-assisted healing.

It does **not** require Playwright MCP for normal web automation.

Install the CLI with:

```bash
npm install -g @playwright/cli
npx playwright install chromium
```

or use:

```bash
npm run setup
```

---

# IDE Support

The MCP guidance in the repository documents configurations for:

| IDE / Client | Typical MCP Configuration Location |
|---|---|
| VS Code / GitHub Copilot | `.vscode/mcp.json` |
| Claude Code | `.mcp.json` |
| Cursor | `.cursor/mcp.json` |
| Windsurf | `~/.codeium/windsurf/mcp_config.json` |
| Kiro | `.kiro/settings/mcp.json` |
| Codex | `~/.codex/config.toml` |

Project-specific MCP configuration should normally remain machine-local and be excluded from source control when it contains credentials.

---

# Security and Governance

Enterprise adoption should treat agentic test automation as a governed engineering system.

## Security Controls

### Secrets

- Keep `.env` files out of Git.
- Do not write real credentials into scenarios.
- Do not include secrets in generated reports.
- Use CI/CD secret stores in shared environments.

### Scope Boundaries

Agents should operate only within explicitly authorized project paths and connected systems.

### Requirement Integrity

The framework should never change expected business behavior simply to make a test pass.

### Evidence

Execution decisions should remain supported by:

- Source requirement
- Scenario definition
- Explorer evidence
- Generated code
- Test result
- Reviewer scorecard
- Healing report
- Pipeline summary

### Least Privilege

MCP credentials should receive only the access necessary for the requested workflow, for example read-only Jira/ADO access when the agent only needs requirement retrieval.

---

# CI/CD Guidance

The recovered project demonstrates the QE runtime and agent workflow. For enterprise CI/CD, use the following pattern.

```mermaid
flowchart LR
    A[Pull Request] --> B[Static Validation]
    B --> C[Generated / Approved Automation]
    C --> D[Playwright Execution]
    D --> E[Test Evidence]
    E --> F[Quality Gate]
    F -->|Pass| G[Merge / Promote]
    F -->|Fail| H[Block / Review]
```

Recommended controls:

- Run tests in clean build agents/containers.
- Install dependencies from lock files.
- Store secrets in platform-native secret stores.
- Publish Allure/HTML execution evidence.
- Retain pipeline metrics as artifacts.
- Fail builds when mandatory tests fail.
- Do not allow AI review scores to override actual execution failures.
- Add manual approval for high-risk generated changes where required.

Typical platforms include:

- GitHub Actions
- Jenkins
- Azure DevOps Pipelines
- GitLab CI

---

# Demo Applications Observed in This Repository

Recovered execution artifacts and locator repositories show examples for at least two application flows.

## SauceDemo

Examples include:

- Login
- Inventory/product interaction

Observed files include:

```text
output/locators/login-page.locators.json
output/locators/inventory-page.locators.json
```

## VFS Global Flow

Recovered locator/evidence artifacts include application areas such as:

- Login
- Dashboard
- Application details
- Applicant / user details
- Booking-related flow elements

Observed files include:

```text
output/locators/vfs-login-page.locators.json
output/locators/vfs-dashboard-page.locators.json
output/locators/vfs-application-detail-page.locators.json
output/locators/vfs-your-details-page.locators.json
```

These artifacts demonstrate that the framework has been exercised against both a simple demo application and a more involved multi-page workflow.

---

# Troubleshooting

## `npm run setup` is missing

Use the **Setup Agent**. Its responsibility includes ensuring `package.json` contains the required framework script entries.

## `scripts/` is missing

The framework supports two delivery patterns:

- **Standalone distribution** — deterministic runtime is already present.
- **AgentHub distribution** — agents may be installed first and the framework installer subsequently delivers the deterministic runtime.

The Setup Agent is responsible for detecting this situation and invoking the framework-owned installer where appropriate.

## Browser cannot start

Run:

```bash
npx playwright install chromium
```

Verify the Playwright CLI is available:

```bash
playwright-cli --help
```

## Explorer cannot reach the application

Check:

- `BASE_URL`
- VPN/network connectivity
- Authentication prerequisites
- Test account status
- Proxy/firewall settings
- Application environment availability

## Environment variables remain placeholders

Populate `output/.env` with valid local/test-environment values.

Do not modify framework code to bypass missing credentials.

## Test executes but Reviewer returns NEEDS FIXES

This is expected when automation is technically executable but violates QE quality rules.

Review:

```text
output/reports/**review**
```

Typical causes include:

- Weak locators
- Incorrect wait strategy
- Security issues
- Hardcoded data
- Maintainability problems
- Scenario-to-code mismatch

## Test passes but final pipeline is not APPROVED

Execution success and QE approval are separate gates.

Check the Reviewer scorecard and fidelity findings.

## Repeated selector failures

Inspect:

- Locator JSON
- Explorer evidence
- Browser snapshots
- DOM changes
- Selector-healing report

Do not immediately replace expected behavior simply because a UI changed.

## Allure output is very large

Trace ZIP files, screenshots, attachments, and historical results can become large. Treat generated evidence as build artifacts rather than long-lived source files unless retention is intentional.

---

# Repository Packaging Guidance

Do **not** distribute development packages containing the entire runtime dependency tree and historical execution evidence unless necessary.

A clean source package should normally exclude:

```text
node_modules/
output/node_modules/
output/allure-results/
output/test-results/
output/.playwright-cli/
.playwright-cli/
playwright-report/
*.trace.zip
.env
output/.env
```

Recommended `.gitignore` patterns:

```gitignore
# Dependencies
node_modules/
output/node_modules/

# Secrets
.env
output/.env
*.env.local

# Execution evidence
output/allure-results/
output/test-results/
output/.playwright-cli/
.playwright-cli/
playwright-report/

# OS / IDE
.DS_Store
Thumbs.db
```

Keep safe templates such as:

```text
output/.env.example
output/.env.qa.example
output/.env.stg.example
```

A clean repository should be reproducible by running:

```bash
npm run setup
```

rather than committing `node_modules`.

---

# Current Scope and Limitations

## Web

Primary supported modality in the recovered configuration.

## API

Supported through API skills, structured scenarios, and OpenAPI enrichment.

## Hybrid

Supported for flows combining browser and service/API behavior.

## Mobile

The agent documentation identifies mobile/mobile-hybrid support as **Phase 2** and references Appium-based integration.

## Human Oversight

Agentic automation does not eliminate the need for QE ownership.

Human review remains especially important for:

- New requirements
- Ambiguous acceptance criteria
- Security-sensitive flows
- Payment/financial operations
- Destructive actions
- Regulatory workflows
- Production-like data
- High-risk releases

---

# Recommended Enterprise Adoption Model

A practical adoption path is:

## Phase 1 — Controlled PoC

Use 5–10 representative scenarios covering:

- Basic web automation
- Data-driven flow
- Negative validations
- API flow
- One selector-change/healing example

Measure:

- Generation time
- Manual effort saved
- Execution pass rate
- Reviewer acceptance rate
- Healing success rate
- Token usage

## Phase 2 — Team Pilot

Introduce:

- Jira/ADO integration
- Shared Page Objects
- CI execution
- Allure reporting
- Controlled prompt/agent versioning
- Golden scenario regression suite

## Phase 3 — Enterprise Governance

Add:

- RBAC
- Audit logging
- Secrets management
- Agent/model governance
- Policy-as-code gates
- Centralized observability
- Cost analytics
- Approved model registry
- Data-retention policies

## Phase 4 — Scale

Expand across applications using:

- Reusable skill packs
- Application context libraries
- Standard review thresholds
- Shared CI templates
- Cross-project metrics
- Central governance dashboards

---

# Glossary

| Term | Meaning |
|---|---|
| **Agentic AI** | AI architecture in which specialized agents can reason, use tools, take actions, and collaborate toward a goal. |
| **BDD** | Behavior-Driven Development; business-readable behavior expressed using Gherkin. |
| **Enrichment** | Conversion of a raw requirement into a structured, automation-ready scenario contract. |
| **Explorer** | Agent responsible for grounding scenarios against the live application. |
| **Builder** | Agent responsible for generating automation assets. |
| **Executor** | Agent responsible for running tests and bounded technical remediation. |
| **Reviewer** | Independent agent responsible for quality assessment. |
| **Healer** | Agent responsible for targeted repair of reviewer-identified problems. |
| **MCP** | Model Context Protocol; used here to connect external systems such as Jira, ADO, and Figma. |
| **Scenario Fidelity** | Degree to which generated automation exactly preserves the intended requirement. |
| **Quality Gate** | A mandatory condition that must pass before the pipeline can continue or approve a result. |
| **Locator Healing** | Controlled repair of selectors after application DOM/UI changes. |
| **App Context** | Reusable knowledge about a specific application learned or configured for future scenarios. |

---

# FAQ

## Is this just a Playwright framework?

No. Playwright is the deterministic browser automation layer. The repository adds an agentic QE lifecycle around it: requirement analysis, exploration, generation, execution, review, healing, traceability, governance, and observability.

## Does one AI agent do everything?

No. Responsibilities are intentionally split among specialist agents.

## Can the Orchestrator generate code if Builder fails?

No. The Orchestrator is explicitly prohibited from completing specialist work itself. The correct result is **INCOMPLETE**.

## Does the framework use Playwright MCP?

Not for the normal web execution path. Explorer and browser-assisted healing use **Playwright CLI**.

## Where is MCP used?

Primarily for external systems such as Jira, Azure DevOps, and Figma. Mobile/Appium MCP is described as Phase 2.

## Can AI change assertions to make tests pass?

It should not. Scenario-to-code fidelity is a hard review gate, and healing must preserve business intent.

## What happens if the application appears to be wrong?

The framework's bug-detection approach allows uncertain or potential-defect outcomes to be surfaced rather than automatically changing the scenario.

## Is self-healing unlimited?

No. Execution repair is bounded by configuration, and Reviewer-driven healing is targeted.

## What is the default minimum review score?

`80` in the recovered `framework-config.json`.

## What observability is enabled?

Token usage, context-window consumption, duration, stage boundaries, and final orchestration metrics are enabled in the recovered configuration.

## What languages are represented?

The repository includes language profiles for:

- TypeScript
- JavaScript
- Python

The recovered framework configuration currently selects **TypeScript**.

---

# Summary

This framework demonstrates a shift from traditional test automation toward **Agentic Quality Engineering**.

Its distinguishing architecture is not simply that AI generates Playwright code. The value comes from the complete governed lifecycle:

```text
Requirement
   ↓
Reviewable Scenario
   ↓
Application-Grounded Exploration
   ↓
Structured Automation Generation
   ↓
Deterministic Execution
   ↓
Independent QE Review
   ↓
Controlled Healing
   ↓
Evidence + Metrics + Traceability
```

The framework is designed around an enterprise principle:

> **Automation should not be considered trustworthy merely because AI generated it or because a test happened to pass. It should be grounded, executable, independently reviewed, traceable to the requirement, and governed by explicit quality gates.**

---

## Maintainer Notes

Before publishing this repository internally or externally:

1. Remove real `.env` values.
2. Exclude `node_modules` from the package.
3. Exclude historical Allure attachments unless intentionally required.
4. Retain only safe `.env.example` templates.
5. Verify all generated example data is non-sensitive.
6. Run the framework from a clean clone using `npm run setup`.
7. Execute at least one representative scenario end-to-end.
8. Confirm the Pipeline Summary and Reviewer scorecard are generated correctly.
9. Confirm required MCP integrations are documented for the target IDE.
10. Version agent definitions, skills, deterministic scripts, and configuration together.

---

**Agentic AI Quality Engineering Automation Framework**  
*Requirements → Exploration → Automation → Execution → Review → Healing → Governed Quality Evidence*
