# MCP servers — per-IDE configuration

This folder holds example configs for the **external MCP servers** the qe-automation pipeline uses: the **BDD Scenario Author**'s trackers (Jira / Azure DevOps / Figma) today, and an **Appium** server for mobile in Phase 2. These are credentialed, external services you configure once per IDE.

> ⚙️ **Playwright is NOT an MCP server here.** The **Explorer** and the **Executor**'s Level-3 healing drive the browser through the **Playwright CLI** (`playwright-cli`) — a terminal tool, not an MCP server. Install it once (global, so the agents' bare `playwright-cli …` calls resolve on PATH):
>
> ```
> npm install -g @playwright/cli
> npx playwright install chromium      # shared browser build (also run by `npm run setup`)
> ```
>
> `npm run setup` does both for you. **There is no Playwright MCP to configure** — and if you previously set up `@playwright/mcp`, remove it: leaving it present can cause the agent to fall back to MCP instead of the deterministic CLI.

## Where MCP configs go (per IDE)

The example files below use the generic `mcpServers` key. Copy the server(s) you need into the destination for your IDE, renaming the top key to match:

| IDE | Destination | Servers key |
|-----|-------------|-------------|
| **VS Code (Copilot)** | `.vscode/mcp.json` (project) | `servers` |
| **Claude Code** | `.mcp.json` (project root) | `mcpServers` |
| **Cursor** | `.cursor/mcp.json` (project) | `mcpServers` |
| **Windsurf** | `~/.codeium/windsurf/mcp_config.json` (global) | `mcpServers` |
| **kiro** | `.kiro/settings/mcp.json` (project) | `mcpServers` |
| **Codex** | `~/.codex/config.toml` (global) | `[mcp_servers.*]` |

The project-level configs (`.vscode/mcp.json`, `.mcp.json`, `.cursor/mcp.json`, `.kiro/settings/mcp.json`) should be gitignored — they're machine-local. Reload your IDE after editing so it picks up the server.

---

## BDD Scenario Author — tracker & design MCP (`bdd-trackers.mcp.example.json`)

The **BDD Scenario Author** reads requirements from **Jira** (`atlassian-mcp-server`) or **Azure DevOps** (`ado-mcp-server`), and (optionally) validates against **Figma** (`figma-mcp-server`). These are **external, credentialed** cloud/desktop services — they are **NOT installed by `npm run setup`**. Configure the one(s) you need from **`bdd-trackers.mcp.example.json`**.

| Server (key) | Used for | Required? |
|---|---|---|
| `atlassian-mcp-server` | Jira Story/Feature as requirement source | one of Jira/ADO is **required** when there is no `spec.md` |
| `ado-mcp-server` | Azure DevOps Work Item as requirement source | one of Jira/ADO is **required** when there is no `spec.md` |
| `figma-mcp-server` | Figma design validation (or use `figma-design-interpreter`'s `design-spec.md`) | optional |

**How to configure:** open `bdd-trackers.mcp.example.json`, copy the server(s) you need into your IDE's MCP config — same per-IDE destinations + key (`servers` vs `mcpServers` vs `[mcp_servers.*]`) as the per-IDE table above. **The server key MUST match the agent's token name** (`atlassian-mcp-server` / `ado-mcp-server` / `figma-mcp-server`). Replace the example commands + credentials with your actual server (the same one you used in v2). Within AgentHub you can instead run `agent-hub mcp`.

> **Already have them globally?** If these MCP servers are configured at the IDE/global level (e.g. your VS Code Copilot setup from v2), the agent uses those automatically — you don't need this file. That is why the v2 agent "just worked" without per-project MCP config.
>
> **Standalone (no AgentHub) ⇒ no `spec.md`** (the Spec Author is an AgentHub shared agent). The BDD Scenario Author then always falls back to the tracker — so **`atlassian-mcp-server` or `ado-mcp-server` is effectively required** for it to function standalone (Figma optional).

---

## Mobile (Phase 2)

mobile/mobile-hybrid scenarios additionally need an `appium-mcp` server (Appium on `localhost:4723`, `ANDROID_HOME` set). That block ships with the Phase-2 mobile packs and slots into the same per-IDE destinations above.
